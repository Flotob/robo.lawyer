﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using EPostBusinessApi;
using IEPostBusinessApi;
using IEPostBusinessApi.EPostException;

namespace Testversand
{
    using IEPostBusinessApi.JSON.PrintOptions;

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeApi();
        }

        private IEPostSession _ePostSession;

        private bool _isElectronic = false;

        /// <summary>
        /// Initialisiert die APi zum Versand eines E-POSTBRIEFS
        /// </summary>
        private void InitializeApi()
        {
            // Die EPostSession ist das zentrale Objekt, dass die Kommunikation mit E-POST übernimmt.
            // An dieser Stelle wird es initialisiert.
            _ePostSession = new EPostSession();

            // Hier wird festgelegt, ob sich gegen die Integrations- und Testumgebung (ITU) oder die Produktion verbunden wird.
            _ePostSession.Login.SystemType = SystemType.Itu;

            // Hier geben Sie die Client Id an, die sie von der E-POST erhalten haben.
            // Sie muss zum SystemType passen.
            _ePostSession.Login.ClientId = "Hier bitte Ihre Client Id eintragen";

            // Hier geben Sie die RedirectUri an, die sie mit der E-POST abgesprochen haben.
            _ePostSession.Login.RedirectUri = new Uri("Hier bitte Ihre Redirect-Uri eintragen");

            // Hier geben sie den Inhalt der LIF-Datei an.
            _ePostSession.Login.LifContent = "Hier bitte Ihr LIF eintragen";

            // Hier können Sie einen eigene beliebigen Status angeben. Wer wird von E-POST ignoriert.
            _ePostSession.Login.State = "1";

            // Weiterhin besteht die Möglichkeit sich an den Events der EPostSession zu registrieren
            _ePostSession.LoginStatusChanged += EPostSessionOnLoginStatusChanged;
            _ePostSession.WorkStatusChanged += EPostSessionOnWorkStatusChanged;
        }

        private void EPostSessionOnLoginStatusChanged(object sender, LoginStatusEventArgs loginStatusEventArgs)
        {
            this.SetLabel(this.toolStripStatusLabelLogin, loginStatusEventArgs.LoginStatus.GetLocalizedName());
        }

        private void EPostSessionOnWorkStatusChanged(object sender, WorkStatusEventArgs workStatusEventArgs)
        {
            this.SetLabel(this.toolStripStatusLabelWorkStatus, workStatusEventArgs.WorkStatus.GetLocalizedName());
        }

        private void SetLabel(ToolStripStatusLabel label, string text)
        {
            if (label == null)
            {
                throw new ArgumentNullException("label");
            }

            label.Text = text;
            Application.DoEvents();
        }

        /// <summary>
        /// Hier wird das Login durchgeführt
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonLogin_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxBenutzername.Text) && !string.IsNullOrEmpty(textBoxPasswort.Text))
            {
                try
                {
                    // Setzen von Benutzername und Passwort
                    _ePostSession.Login.Username = textBoxBenutzername.Text;
                    _ePostSession.Login.Password = textBoxPasswort.Text;

                    // Wechseln in den eingeloggten Status
                    _ePostSession.LoginStateMachine.GoToLoggedInLowState();

                    MessageBox.Show("Login erfolgreich");
                }
                catch (EPostBusinessApiException ex)
                {
                    MessageBox.Show(ex.LocalizedDescription, "Es ist ein Fehler beim Login aufgetreten");
                }
            }
        }

        /// <summary>
        /// Hier wird ein klassischer Entwurf angelegt.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonEntwurfKlassisch_Click(object sender, EventArgs e)
        {
            try
            {
                _ePostSession.CreatePrintDraft(
                    // Absender, z.B. max.mustermann@epost-gka.de, Domain muss zu "SystemType" passen.
                    "Hier bitte den Absender eintragen",
                    // Betreff
                    "Betreff",
                    // Text des E-POSTBRIEFS in HTML
                    "Sehr gehrter Herr Mustermann,<br/><br/>" + "dies ist ein E-POSTBRIEF.<br/>" + "Viele Grüße<br/>"
                    + "Der Absender",
                    // Firma
                    "",
                    // Anrede
                    "Herr",
                    // Titel
                    "Dr.",
                    // Vorname
                    "Max",
                    // Nachname
                    "Mustermann",
                    // Postfach
                    "",
                    // Straße
                    "Musterstraße",
                    // Hausnummer
                    "11",
                    // Adresszusatz
                    "",
                    // Postleitzahl
                    "12345",
                    // Ort
                    "Musterstadt",
                    // Liste von Anhängen
                    new List<string> { @"..\..\..\..\Testdokument\test.pdf" });
                _isElectronic = false;

                MessageBox.Show("Der klassische Entwurf wurde erfolgreich erstellt");
            }
            catch (EPostBusinessApiException ex)
            {
                MessageBox.Show(ex.LocalizedDescription, "Es ist ein Fehler beim Anlegen eines klassischen Entwurfs aufgetreten");
            }
        }

        private void buttonEntwurfElektronisch_Click(object sender, EventArgs e)
        {
            try
            {
                _ePostSession.CreateElectronicalDraft(
                    // Absender, z.B. max.mustermann@epost-gka.de
                    "Hier bitte den Absender eintragen",
                    // Betreff
                    "Betreff",
                    // Text des E-POSTBRIEFS
                    "Sehr gehrter Herr Mustermann,<br/><br/>" + "dies ist ein E-POSTBRIEF.<br/>" + "Viele Grüße<br/>"
                    + "Der Absender",
                    // Empfänger, z.B. a.b@epost-gka.de
                    "Hier bitte den Empfänger eintragen",
                    // Liste von Anhängen
                    new List<string> { @"..\..\..\..\Testdokument\test.pdf" });
                _isElectronic = true;

                MessageBox.Show("Der elektronische Entwurf wurde erfolgreich erstellt");
            }
            catch (EPostBusinessApiException ex)
            {
                MessageBox.Show(ex.LocalizedDescription, "Es ist ein Fehler beim Anlegen eines elektronischen Entwurfs aufgetreten");
            }
        }

        private void buttonPreisinfoKlassisch_Click(object sender, EventArgs e)
        {
            try
            {
                // Falls es sich um einen elektronischen E-POSTBRIEF handelt, müssen wir ins hohe Authentifizierungsniveau wechseln
                if (_isElectronic)
                {
                    _ePostSession.LoginStateMachine.GoToLoggedInHighStateWithCredentialManagerAuthentication();
                }

                // Diese Variable beinhaltet die Optionen für den Versand des E-POSTBRIEFs
                var printOptionsRequest = new PrintOptionsRequest
                                              {
                                                  Options =
                                                      new Options
                                                          {
                                                              // Gibt an, ob der Brief farbig oder grau gedruckt werden soll.
                                                              Color = ColorEnum.grayscale,
                                                              // Gibt an, ob ein Deckblatt enthalten ist, oder nicht.
                                                              CoverLetter =
                                                                  CoverLetterEnum.included,
                                                              // Gibt die Einschreibenoption an
                                                              Registered = RegisteredEnum.no
                                                          }
                                              };
                
                // Abfrage des Preises des aktuellen Entwurfs in Abhängigkeit der Print Optionen.
                var totalPrice = _ePostSession.GetPostageInfoForActualDraft(printOptionsRequest);
                MessageBox.Show("Der Preis beträgt " + totalPrice.GrossAmount + " EUR");
            }
            catch (EPostBusinessApiException ex)
            {
                MessageBox.Show(ex.LocalizedDescription, "Es ist ein Fehler bei der Preisabfrage aufgetreten");
            }
        }

        private void buttonSendKlassisch_Click(object sender, EventArgs e)
        {
            try
            {
                // Falls es sich um einen elektronischen E-POSTBRIEF handelt, müssen wir ins hohe Authentifizierungsniveau wechseln
                if (_isElectronic)
                {
                    _ePostSession.LoginStateMachine.GoToLoggedInHighStateWithCredentialManagerAuthentication();
                }

                // Diese Variable beinhaltet die Optionen für den Versand des E-POSTBRIEFs
                var printOptionsRequest = new PrintOptionsRequest
                                              {
                                                  Options =
                                                      new Options
                                                          {
                                                              // Gibt an, ob der Brief farbig oder grau gedruckt werden soll.
                                                              Color = ColorEnum.grayscale,
                                                              // Gibt an, ob ein Deckblatt enthalten ist, oder nicht.
                                                              CoverLetter =
                                                                  CoverLetterEnum.included,
                                                              // Gibt die Einschreibenoption an
                                                              Registered = RegisteredEnum.no
                                                          }
                                              };

                // Versand mit den Standardoptionen
                //_ePostSession.SendDraft();

                // Versand mit den oben angegebenen Optionen
                _ePostSession.SendDraft(printOptionsRequest);

                MessageBox.Show("Der Versand war erfolgreich");
            }
            catch (EPostBusinessApiException ex)
            {
                MessageBox.Show(ex.LocalizedDescription, "Es ist ein Fehler beim Versand aufgetreten");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (_ePostSession != null)
            {
                try
                {
                    _ePostSession.LoginStateMachine.GoToLoggedOutState();
                    MessageBox.Show("Logout erfolgreich");
                }
                catch (EPostBusinessApiException ex)
                {
                    MessageBox.Show(ex.LocalizedDescription, "Es ist ein Fehler beim Logout aufgetreten");    
                }
            }
        }
    }
}