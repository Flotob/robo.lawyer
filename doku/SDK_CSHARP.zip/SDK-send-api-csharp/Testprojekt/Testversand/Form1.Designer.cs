﻿namespace Testversand
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxBenutzername = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxPasswort = new System.Windows.Forms.TextBox();
            this.buttonLogin = new System.Windows.Forms.Button();
            this.buttonEntwurfKlassisch = new System.Windows.Forms.Button();
            this.buttonEntwurfElektronisch = new System.Windows.Forms.Button();
            this.buttonSendKlassisch = new System.Windows.Forms.Button();
            this.buttonPreisinfoKlassisch = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelLogin = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelWorkStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBoxBenutzername
            // 
            this.textBoxBenutzername.Location = new System.Drawing.Point(206, 36);
            this.textBoxBenutzername.Name = "textBoxBenutzername";
            this.textBoxBenutzername.Size = new System.Drawing.Size(356, 31);
            this.textBoxBenutzername.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Benutzername";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Passwort";
            // 
            // textBoxPasswort
            // 
            this.textBoxPasswort.Location = new System.Drawing.Point(206, 88);
            this.textBoxPasswort.Name = "textBoxPasswort";
            this.textBoxPasswort.Size = new System.Drawing.Size(356, 31);
            this.textBoxPasswort.TabIndex = 3;
            // 
            // buttonLogin
            // 
            this.buttonLogin.Location = new System.Drawing.Point(37, 143);
            this.buttonLogin.Name = "buttonLogin";
            this.buttonLogin.Size = new System.Drawing.Size(706, 38);
            this.buttonLogin.TabIndex = 4;
            this.buttonLogin.Text = "Login";
            this.buttonLogin.UseVisualStyleBackColor = true;
            this.buttonLogin.Click += new System.EventHandler(this.buttonLogin_Click);
            // 
            // buttonEntwurfKlassisch
            // 
            this.buttonEntwurfKlassisch.Location = new System.Drawing.Point(37, 204);
            this.buttonEntwurfKlassisch.Name = "buttonEntwurfKlassisch";
            this.buttonEntwurfKlassisch.Size = new System.Drawing.Size(305, 38);
            this.buttonEntwurfKlassisch.TabIndex = 5;
            this.buttonEntwurfKlassisch.Text = "klassischen Entwurf anlegen";
            this.buttonEntwurfKlassisch.UseVisualStyleBackColor = true;
            this.buttonEntwurfKlassisch.Click += new System.EventHandler(this.buttonEntwurfKlassisch_Click);
            // 
            // buttonEntwurfElektronisch
            // 
            this.buttonEntwurfElektronisch.Location = new System.Drawing.Point(414, 204);
            this.buttonEntwurfElektronisch.Name = "buttonEntwurfElektronisch";
            this.buttonEntwurfElektronisch.Size = new System.Drawing.Size(329, 38);
            this.buttonEntwurfElektronisch.TabIndex = 6;
            this.buttonEntwurfElektronisch.Text = "elektronischen Entwurf anlegen";
            this.buttonEntwurfElektronisch.UseVisualStyleBackColor = true;
            this.buttonEntwurfElektronisch.Click += new System.EventHandler(this.buttonEntwurfElektronisch_Click);
            // 
            // buttonSendKlassisch
            // 
            this.buttonSendKlassisch.Location = new System.Drawing.Point(37, 328);
            this.buttonSendKlassisch.Name = "buttonSendKlassisch";
            this.buttonSendKlassisch.Size = new System.Drawing.Size(706, 38);
            this.buttonSendKlassisch.TabIndex = 7;
            this.buttonSendKlassisch.Text = "Entwurf versenden";
            this.buttonSendKlassisch.UseVisualStyleBackColor = true;
            this.buttonSendKlassisch.Click += new System.EventHandler(this.buttonSendKlassisch_Click);
            // 
            // buttonPreisinfoKlassisch
            // 
            this.buttonPreisinfoKlassisch.Location = new System.Drawing.Point(37, 267);
            this.buttonPreisinfoKlassisch.Name = "buttonPreisinfoKlassisch";
            this.buttonPreisinfoKlassisch.Size = new System.Drawing.Size(706, 38);
            this.buttonPreisinfoKlassisch.TabIndex = 8;
            this.buttonPreisinfoKlassisch.Text = "Preisinfo abrufen";
            this.buttonPreisinfoKlassisch.UseVisualStyleBackColor = true;
            this.buttonPreisinfoKlassisch.Click += new System.EventHandler(this.buttonPreisinfoKlassisch_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 25);
            this.label3.TabIndex = 9;
            this.label3.Text = "1.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1, 398);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 25);
            this.label4.TabIndex = 10;
            this.label4.Text = "5.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1, 211);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 25);
            this.label5.TabIndex = 11;
            this.label5.Text = "2.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1, 274);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 25);
            this.label6.TabIndex = 12;
            this.label6.Text = "3.";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1, 335);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(30, 25);
            this.label7.TabIndex = 13;
            this.label7.Text = "4.";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(37, 391);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(706, 38);
            this.button1.TabIndex = 14;
            this.button1.Text = "Logout";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(354, 211);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 25);
            this.label8.TabIndex = 15;
            this.label8.Text = "oder";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabelLogin,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabelWorkStatus});
            this.statusStrip1.Location = new System.Drawing.Point(0, 474);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(771, 37);
            this.statusStrip1.TabIndex = 16;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(151, 32);
            this.toolStripStatusLabel1.Text = "Login Status:";
            // 
            // toolStripStatusLabelLogin
            // 
            this.toolStripStatusLabelLogin.Name = "toolStripStatusLabelLogin";
            this.toolStripStatusLabelLogin.Size = new System.Drawing.Size(0, 32);
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(148, 32);
            this.toolStripStatusLabel2.Text = "Work Status:";
            // 
            // toolStripStatusLabelWorkStatus
            // 
            this.toolStripStatusLabelWorkStatus.Name = "toolStripStatusLabelWorkStatus";
            this.toolStripStatusLabelWorkStatus.Size = new System.Drawing.Size(0, 32);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 511);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttonPreisinfoKlassisch);
            this.Controls.Add(this.buttonSendKlassisch);
            this.Controls.Add(this.buttonEntwurfElektronisch);
            this.Controls.Add(this.buttonEntwurfKlassisch);
            this.Controls.Add(this.buttonLogin);
            this.Controls.Add(this.textBoxPasswort);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxBenutzername);
            this.Name = "Form1";
            this.Text = "Testversand";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxBenutzername;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxPasswort;
        private System.Windows.Forms.Button buttonLogin;
        private System.Windows.Forms.Button buttonEntwurfKlassisch;
        private System.Windows.Forms.Button buttonEntwurfElektronisch;
        private System.Windows.Forms.Button buttonSendKlassisch;
        private System.Windows.Forms.Button buttonPreisinfoKlassisch;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelLogin;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelWorkStatus;
    }
}

