﻿using System;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace EPostIdentApi
{
    using System.Collections.Specialized;
    using System.Linq.Expressions;
    using System.Net;
    using System.Text;
    using System.Web;
    using System.Linq;
    using System.Windows.Navigation;

    using EPostBusinessApiBrowser;

    public class IdentRequest
    {
        private string redirectUri = "https://localhost2/PocVersicherung_deploy/Epostbrief/AuthCallBackEpostIdent";

        private string redirectUri2 = "https://localhost2/PocVersicherung_deploy/Epostbrief/AuthCallBackEpostIdent2";

        private string scope = "120";

        private string reason = "Ident Test Request";

        private string state = "Mein Status 4711";

        private string clientId = "b5024910-0a5f-416f-be98-f93b54283e16";

        private string clientSecret = "Parole9Parole9";

        private string server = "epost-gka.de";

        private bool useProxy = false;

        public IdentRequest(
            string redirectUri,
            string redirectUri2,
            string scope,
            string reason,
            string state,
            string clientId,
            string clientSecret,
            string server,
            bool useProxy)
        {
            this.redirectUri = redirectUri;
            this.redirectUri2 = redirectUri2;
            this.reason = reason;
            this.state = state;
            this.clientId = clientId;
            this.clientSecret = clientSecret;
            this.server = server;
            this.useProxy = useProxy;
 
            this.scope = scope;
        }

        /// <summary>
        /// Liest oder setzt LoginWindow.
        /// </summary>
        private LoginWindow LoginWindow { get; set; }

        /// <summary>
        /// Liest oder setzt AuthorizationCode.
        /// </summary>
        private string AuthorizationCode { get; set; }

        public string Result { get; set; }

        public void Login()
        {
            string uri = "https://"
             + server
             + "/oauth2/login?client_id="
             + clientId
             + "&redirect_uri="
             + redirectUri
             + "&scope="
             + scope
             + "&reason="
             + reason
             + "&response_type=code"
             + "&state="
             + state;

            ExecuteInGuiThread(new Action(() =>
            {
                LoginWindow = new LoginWindow();
                LoginWindow.Height = 1000;
                LoginWindow.Width = 1100;
                WebBrowser browser = LoginWindow.Browser;
                browser.Navigating += BrowserNavigating;
                browser.Navigate(uri);
                LoginWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                LoginWindow.ShowDialog();
            }));
        }


        /// <summary>Diese Event wird mehrmals aufgerufen. Uns interessiert aber nur der erste Aufruf, bei dem die URL der redirect URL
        /// entspricht. Da steht alles drin was wir benötigen und die weiteren Events werden nicht mehr abgearbeitet.</summary>
        /// <param name="sender">Der Sender </param>
        /// <param name="eventArg">Die Event Argumente. </param>
        private void BrowserNavigating(object sender, NavigatingCancelEventArgs eventArg)
        {
            var url = eventArg.Uri == null ? null : eventArg.Uri.AbsoluteUri;
            if (url != null && url.StartsWith(redirectUri))
            {
                ExecuteInGuiThread(new Action(() => LoginWindow.Close()));

                var parameters = HttpUtility.ParseQueryString(url);
                var code = "code";
                if (parameters.AllKeys.Contains(code))
                {
                    AuthorizationCode = parameters[code];

                    byte[] response;

                    using (var client = new WebClient())
                    {
                        var values = new NameValueCollection();
                        client.Headers.Add(HttpRequestHeader.ContentType, "application/x-www-form-urlencoded");
                        client.Encoding = Encoding.UTF8;
                        values["code"] = AuthorizationCode;
                        values["client_id"] = clientId;
                        values["client_secret"] = clientSecret;
                        values["redirect_uri"] = redirectUri2;
                        values["grant_type"] = "authorization_code";

                        if (useProxy)
                        {
                            client.Proxy = new WebProxy("localhost", 8888);
                        }

                        // access ticket mit post request anfordern
                        response = client.UploadValues("https://" + server + "/oauth2/token", values);
                    }

                    using (var client = new WebClient())
                    {
                        string authorizationCode = "Bearer " + Encoding.UTF8.GetString(response);
                        client.Headers.Add(HttpRequestHeader.AcceptCharset, "utf-8");
                        client.Headers.Add(HttpRequestHeader.Accept, "application/xml");
                        client.Headers.Add(HttpRequestHeader.Authorization, authorizationCode);
                        if (useProxy)
                        {
                            client.Proxy = new WebProxy("localhost", 8888);
                        }
                        var identityData = client.DownloadData("https://" + server + "/oauth2/identdata");
                        Result = Encoding.UTF8.GetString(identityData);
                    }
                }
                else
                {
                    string error = parameters[redirectUri + "?error"];
                    Result = "Es ist ein Fehler aufgetreten: " + error;
                }
            }
        }

        /// <summary>
        /// Execute the given method in the GUI tread, using the given arguments.
        /// 
        /// Task related to the GUI have to be executed from the GUI thread. This methods helps
        /// executing code in the GUI thread.
        /// </summary>
        /// <param name="method">The method to execute.</param>
        /// <param name="args">The parameters for the method.</param>
        /// <returns>The execution results of the method.</returns>
        public static DispatcherOperation ExecuteInGuiThread(Delegate method, params Object[] args)
        {
            if (Thread.CurrentThread.GetApartmentState() == ApartmentState.STA)
            {
                // if we are in the GUI thread, we must not call the BeginInvoke
                // TODO Andreas: Maybe we can use the Invoke?...
                method.DynamicInvoke(args);
                return null;
            }

            // start the delegate in the GUI thread
            return Application.Current.Dispatcher.BeginInvoke(method, args);
        }

    }
}
