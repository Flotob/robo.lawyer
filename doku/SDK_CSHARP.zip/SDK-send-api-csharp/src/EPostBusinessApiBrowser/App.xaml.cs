﻿namespace EPostBusinessApiBrowser
{
    using System.Windows;

    /// <summary>
    /// Die Interaktions-Logik für App.xaml.
    /// </summary>
    public partial class App : Application
    {
    }
}