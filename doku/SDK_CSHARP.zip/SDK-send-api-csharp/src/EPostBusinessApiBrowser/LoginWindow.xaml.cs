﻿namespace EPostBusinessApiBrowser
{
    using System;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Interop;

    /// <summary>
    /// Interaktions-Logik für MainWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        #region Constructors and Destructors

        /// <summary>Initialisiert eine neue Instanz der <see cref="LoginWindow"/> Klasse.</summary>
        public LoginWindow()
        {
            this.InitializeComponent();
        }

        #endregion

        #region Public Properties

        /// <summary>Liest Browser.</summary>
        public WebBrowser Browser
        {
            get
            {
                return this.webBrowser1;
            }
        }

        #endregion
    }
}