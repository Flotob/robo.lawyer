﻿namespace IEPostBusinessApi
{
    /// <summary>Der WorkStatus gibt den aktuellen Status der IEPostSession an.</summary>
    public enum WorkStatus
    {
        /// <summary>
        /// Der Login-Prozess hat begonnen.
        /// </summary>
        LoginBegin, 

        /// <summary>
        /// Der Login-Prozess wurde beendet.
        /// </summary>
        LoginEnd, 

        /// <summary>
        /// Der Logout hat begonnen.
        /// </summary>
        LogoutBegin, 

        /// <summary>
        /// Der Logout wurde beendet.
        /// </summary>
        LogoutEnd, 

        /// <summary>
        /// Das Aktualisieren des Logins hat begonnen.
        /// </summary>
        RefreshLoginBegin, 

        /// <summary>
        /// Das Aktualisieren des Logins wurde beendet.
        /// </summary>
        RefreshLoginEnd,

        /// <summary>
        /// Das Erweitern des Scopes hat begonnen.
        /// </summary>
        ExtendScopeBegin,

        /// <summary>
        /// Das Erweitern des Scopes wurde beendet.
        /// </summary>
        ExtendScopeEnd, 

        /// <summary>
        /// Das Anlegen eines Entwurfs hat begonnen.
        /// </summary>
        CreateDraftBegin, 

        /// <summary>
        /// Das Anlegen eines Entwurfs wurde beendet.
        /// </summary>
        CreateDraftEnd, 

        /// <summary>
        /// Die Preisabfrage hat begonnen.
        /// </summary>
        PostageInfoBegin, 

        /// <summary>
        /// Die Preisabfrage wurde beendet.
        /// </summary>
        PostageInfoEnd, 

        /// <summary>
        /// Der Versandprozess hat begonnen.
        /// </summary>
        SendDraftBegin, 

        /// <summary>
        /// Der Versandprozess wurde beendet.
        /// </summary>
        SendDraftEnd, 

        /// <summary>
        /// Der Versandprozess hat begonnen.
        /// </summary>
        DeleteDraftBegin,

        /// <summary>
        /// Der Versandprozess wurde beendet.
        /// </summary>
        DeleteDraftEnd,

        /// <summary>
        /// Bis jetzt wurde nichts gemacht.
        /// </summary>
        Nothing
    }
}