﻿namespace IEPostBusinessApi.LoginStateMachine
{
    using System.Windows.Controls;

    /// <summary>
    /// Die Implementierungen dieses Interfaces sorgen dafür,
    /// das die entsprechenden States erreicht werden.
    /// </summary>
    public interface ILoginState
    {
        /// <summary>
        /// Der aktuelle LoginStatus.
        /// </summary>
        LoginStatus LoginStatus { get; }

        /// <summary>Gets or sets the e post session context.</summary>
        IEPostSessionContext EPostSessionContext { get; set; }

        /// <summary>Gets or sets a value indicating whether is ok.</summary>
        bool IsOk { get; }

        /// <summary>
        /// Das Login, dass die entsprechenden Login-Methoden implementiert.
        /// </summary>
        ILogin Login { get; set; }

        #region Public Methods and Operators

        /// <summary>Meldet den eventuell angemeldeten Benutzer ab.</summary>
        void GoToLoggedOutState();

        /// <summary>Der Benutzer wird aufgefordert, die Zugangsdaten im hohen Niveau in einem Browserfenster anzugeben.</summary>
        void GoToLoggedInHighStateWithBrowserAuthentication();

        /// <summary>Der Benutzer wird aufgefordert, die Zugangsdaten im hohen Niveau in einem Browserfenster anzugeben.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die Interaktionen angezeigt werden.</param>
        void GoToLoggedInHighStateWithBrowserAuthentication(WebBrowser browser);

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im hohen Niveau angemeldet.</summary>
        void GoToLoggedInHighStateWithCredentialManagerAuthentication();

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten angemeldet.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die MTAN eingegeben werden muss.</param>
        void GoToLoggedInHighStateWithCredentialManagerAuthentication(WebBrowser browser);

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im niedrigen Niveau angemeldet.</summary>
        void GoToLoggedInLowState();

        #endregion
    }
}