﻿namespace IEPostBusinessApi.LoginStateMachine
{
    /// <summary>The EPostSessionContext interface.</summary>
    public interface IEPostSessionContext
    {
        #region Public Properties

        /// <summary>
        /// Das Login, dass die entsprechenden Login-Methoden implementiert.
        /// </summary>
        ILogin Login { get; set; }

        /// <summary>Gets or sets the login state machine.</summary>
        ILoginState LoginStateMachine { get; set; }

        #endregion
    }
}