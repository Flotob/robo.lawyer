﻿namespace IEPostBusinessApi
{
    using System.Collections.Generic;

    using IEPostBusinessApi.JSON.Draft;
    using IEPostBusinessApi.JSON.Electronic;
    using IEPostBusinessApi.JSON.Folder;
    using IEPostBusinessApi.JSON.Postage;
    using IEPostBusinessApi.JSON.Print;
    using IEPostBusinessApi.JSON.PrintOptions;
    using IEPostBusinessApi.LoginStateMachine;

    /// <summary>Dieses Interface definiert die Zugriffe auf die EPostSession.</summary>
    public interface IEPostSession : IEPostSessionContext
    {
        #region Public Events

        /// <summary>Dieses Event wird ausgelöst, sobald sich der Login-FolderStatus geändert hat.</summary>
        event LoginStatusEventHandler LoginStatusChanged;

        /// <summary>
        /// Dieses Event wird ausgelöst, sobald sich der Arbeitsstatus geändert hat.
        /// Es kann dazu genutzt werden, den Benutzer über die gerade durchgeführten Aktionen der API zu informieren.
        /// </summary>
        event WorkStatusEventHandler WorkStatusChanged;

        #endregion

        #region Public Properties

        /// <summary>Liest Login.</summary>
        new ILogin Login { get; }

        #endregion

        #region Public Methods and Operators

        /// <summary>Erzeugt einen Entwurf im E-POST Postfach.</summary>
        /// <param name="createDraftRequest">Der CreateDraftRequest beinhaltet alle Parameter, die für das Anlegen des Entwurfs
        /// benötigt werden.</param>
        /// <param name="htmlBody">Der Body des E-POSTBRIEFS, also das Anschreiben, als HTML-Text.</param>
        /// <param name="files">Eine Liste von Dateien, die als Anhang an den Entwurf angelegt werden sollen.</param>
        /// <returns>Die Rückmeldung auf das Anlegen des Entwurfs als <see cref="CreateDraftResponse"/>.</returns>
        CreateDraftResponse CreateDraft(CreateDraftRequest createDraftRequest, string htmlBody, List<string> files);

        /// <summary>Erzeugt einen Entwurf für den elektronischen Versand.</summary>
        /// <param name="ePostAddressSender">Die E-POSTBRIEF Adresse des Absenders.</param>
        /// <param name="subject">Der Betreff des E-POSTBRIEFS.</param>
        /// <param name="body">Der Text des E-POSTBRIEFS.</param>
        /// <param name="ePostAddressRecipient">Die E-POSTBRIEF Adresse des Empfängers.</param>
        /// <param name="files">Eine Liste von Dateien, die als Anhang an den Entwurf angelegt werden sollen.</param>
        void CreateElectronicalDraft(
            string ePostAddressSender, 
            string subject, 
            string body, 
            string ePostAddressRecipient, 
            List<string> files);

        /// <summary>Erzeugt einen Entwurf für den physischen Versand.<br/>
        /// Es muss entweder ein Postfach oder eine Straße angegeben werden.</summary>
        /// <param name="ePostAddressSender">Die E-POSTBRIEF Adresse des Absenders.</param>
        /// <param name="subject">Der Betreff des E-POSTBRIEFS.</param>
        /// <param name="body">Der Text des E-POSTBRIEFS.</param>
        /// <param name="company">Der Firmenname.</param>
        /// <param name="salutation">Die Anrede.</param>
        /// <param name="title">Der Titel der Person.</param>
        /// <param name="firstName">Der Vorname.</param>
        /// <param name="lastName">Der Nachname.</param>
        /// <param name="postOfficeBox">Das Postfach.</param>
        /// <param name="streetName">Die Straße.</param>
        /// <param name="houseNumber">Die Hausnummer.</param>
        /// <param name="addressAddon">Zusatzinformation zur Adresse, z. B. Erdgeschoss.</param>
        /// <param name="zipCode">Die Postleitzahl.</param>
        /// <param name="city">Der Ort.</param>
        /// <param name="files">Eine Liste von Dateien, die als Anhang an den Entwurf angelegt werden sollen.</param>
        void CreatePrintDraft(
            string ePostAddressSender, 
            string subject, 
            string body, 
            string company, 
            string salutation, 
            string title, 
            string firstName, 
            string lastName, 
            string postOfficeBox, 
            string streetName, 
            string houseNumber, 
            string addressAddon, 
            string zipCode, 
            string city, 
            List<string> files);

        /// <summary>
        /// Löscht den zuvor angelegten Entwurf. Sollte kein Entwurf angelegt worden sein
        /// oder der Entwurf bereits versendet worden sein, führt der Aufruf dieser Methode zu einem Fehler.
        /// </summary>
        void DeleteActualDraft();

        /// <summary>
        /// Gibt den Status und Inhalt des Ordners Drafts zurück.
        /// </summary>
        /// <returns>Folder</returns>
        Folder GetDrafts();

        /// <summary>Gibt den Status und Inhalt des Ordners Draft zurück.</summary>
        /// <param name="offset">Der Parameter legt fest, welche Stelle der Ergebnisliste, die über limit eingeschränkt ist,
        /// zurückgegeben wird. Wenn der Parameter nicht angegeben wird, wird der Standardwert 0
        /// verwendet.</param>
        /// <param name="limit">Die Anzahl an E‑POSTBRIEFEN, die bei der Anfrage zurückgegeben werden. Wenn der
        /// Parameter nicht angegeben wird, wird der Standardwert 500 (Maximalwert) verwendet.</param>
        /// <returns>Folder</returns>
        Folder GetDrafts(int offset, int limit);

        /// <summary>
        /// Gibt den Status und Inhalt des Ordners Inbox zurück.
        /// </summary>
        /// <returns>Folder</returns>
        Folder GetInbox();

        /// <summary>Gibt den Status und Inhalt des Ordners Inbox zurück.</summary>
        /// <param name="offset">Der Parameter legt fest, welche Stelle der Ergebnisliste, die über limit eingeschränkt ist,
        /// zurückgegeben wird. Wenn der Parameter nicht angegeben wird, wird der Standardwert 0
        /// verwendet.</param>
        /// <param name="limit">Die Anzahl an E‑POSTBRIEFEN, die bei der Anfrage zurückgegeben werden. Wenn der
        /// Parameter nicht angegeben wird, wird der Standardwert 500 (Maximalwert) verwendet.</param>
        /// <returns>Folder</returns>
        Folder GetInbox(int offset, int limit);

        /// <summary>
        /// Liefert das JSON Objekt zum Brief.
        /// </summary>
        /// <param name="id">Id des Briefs.</param>
        /// <returns>GetLetterResponse</returns>
        GetLetterResponse GetLetter(string id);

        /// <summary>
        /// Liefert das Anschreiben in text oder html-Format.
        /// </summary>
        /// <param name="id">Id des Anschreibens.</param>
        /// <returns>Anschreiben in text oder html-Format.</returns>
        string GetCoverLetter(string id);

        /// <summary>
        /// Liefert das Attachment als Byte Array.
        /// </summary>
        /// <param name="letterId">Id des Briefs.</param>
        /// <param name="attachmentId">Id des Attachments.</param>
        /// <returns>Attachment als Byte Array.</returns>
        byte[] GetAttachment(string letterId, string attachmentId);

        /// <summary>Fragt die Preisinformationen aufgrund der angegebenen Metadaten ab, ohne auf einen Entwurf zu referenzieren.</summary>
        /// <param name="printOptionsRequest">Die Parameter, die zur Abfrage des Preises benötigt werden.</param>
        /// <returns>Die Preisinformation als <see cref="TotalPrice"/>.</returns>
        TotalPrice GetPostageInfo(PrintOptionsRequest printOptionsRequest);

        /// <summary>Fragt die Preisinformationen für einen referenzierten Entwurf ab.</summary>
        /// <param name="contentSource">Die Referenz auf den Entwurf.</param>
        /// <returns>Die Rückmeldung mit den entsprechenden Preisinformationen als <see cref="PostageInfoResponse"/>.</returns>
        PostageInfoResponse GetPostageInfo(string contentSource);

        /// <summary>Fragt die Preisinformationen für einen referenzierten Entwurf ab.</summary>
        /// <param name="contentSource">Die Referenz auf den Entwurf.</param>
        /// <param name="printOptionsRequest">Die Parameter, die zur Abfrage des Preises benötigt werden.</param>
        /// <returns>Die Rückmeldung mit den entsprechenden Preisinformationen als <see cref="PostageInfoResponse"/>.</returns>
        PostageInfoResponse GetPostageInfo(string contentSource, PrintOptionsRequest printOptionsRequest);

        /// <summary>Fragt die Preisinformationen für den aktuellen Entwurf ab.</summary>
        /// <param name="printOptionsRequest">Die Parameter, die zur Abfrage des Preises benötigt werden.</param>
        /// <returns>Die Preisinformation als <see cref="TotalPrice"/>.</returns>
        TotalPrice GetPostageInfoForActualDraft(PrintOptionsRequest printOptionsRequest);

        /// <summary>Fragt die Preisinformationen für den aktuellen Entwurf ab.</summary>
        /// <returns>Die Preisinformation als <see cref="TotalPrice" />.</returns>
        TotalPrice GetPostageInfoForActualDraft();

        /// <summary>
        /// Gibt den Status und Inhalt des Ordners Sent zurück.
        /// </summary>
        /// <returns>Folder</returns>
        Folder GetSent();

        /// <summary>Gibt den Status und Inhalt des Ordners Sent zurück.</summary>
        /// <param name="offset">Der Parameter legt fest, welche Stelle der Ergebnisliste, die über limit eingeschränkt ist,
        /// zurückgegeben wird. Wenn der Parameter nicht angegeben wird, wird der Standardwert 0
        /// verwendet.</param>
        /// <param name="limit">Die Anzahl an E‑POSTBRIEFEN, die bei der Anfrage zurückgegeben werden. Wenn der
        /// Parameter nicht angegeben wird, wird der Standardwert 500 (Maximalwert) verwendet.</param>
        /// <returns>Folder</returns>
        Folder GetSent(int offset, int limit);

        /// <summary>
        /// Gibt den Status und Inhalt des Ordners Trash zurück.
        /// </summary>
        /// <returns>Folder</returns>
        Folder GetTrash();

        /// <summary>Gibt den Status und Inhalt des Ordners Trash zurück.</summary>
        /// <param name="offset">Der Parameter legt fest, welche Stelle der Ergebnisliste, die über limit eingeschränkt ist,
        /// zurückgegeben wird. Wenn der Parameter nicht angegeben wird, wird der Standardwert 0
        /// verwendet.</param>
        /// <param name="limit">Die Anzahl an E‑POSTBRIEFEN, die bei der Anfrage zurückgegeben werden. Wenn der
        /// Parameter nicht angegeben wird, wird der Standardwert 500 (Maximalwert) verwendet.</param>
        /// <returns>Folder</returns>
        Folder GetTrash(int offset, int limit);

        /// <summary>Versendet den aktuellen Entwurf.</summary>
        /// <param name="printOptionsRequest">Die beim Versand zu berücksichtigenden Parameter.</param>
        void SendDraft(PrintOptionsRequest printOptionsRequest);

        /// <summary>Versendet den aktuellen Entwurf.</summary>
        void SendDraft();

        /// <summary>Versendet einen elektronischen E-POSTBRIEF.</summary>
        /// <param name="electronic">Die Parameter zum elektronischen Versand.</param>
        /// <param name="htmlBody">Der Body des E-POSTBRIEFS also das Anschreiben als HTML-Text.</param>
        /// <param name="files">Die Anhänge.</param>
        void SendElectronically(ElectronicRequest electronic, string htmlBody, List<string> files);

        /// <summary>Versendet einen physischen E-POSTBRIEF.</summary>
        /// <param name="print">Die Parameter zum physischen Versand.</param>
        /// <param name="htmlBody">Der Body des E-POSTBRIEFS also das Anschreiben als HTML-Text.</param>
        /// <param name="files">Die Anhänge.</param>
        void SendPhysically(PrintRequest print, string htmlBody, List<string> files);

        #endregion
    }
}