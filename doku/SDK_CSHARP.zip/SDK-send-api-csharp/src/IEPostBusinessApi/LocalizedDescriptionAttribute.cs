namespace IEPostBusinessApi
{
    using System;
    using System.ComponentModel;
    using System.Resources;

    /// <summary>Diese Klasse stellt die M�glichkeit bereit, f�r Aufz�hlungen im Allgemeinen und f�r Fehlermeldungen im Speziellen
    /// eine lokalisierte Beschreibung vorzuhalten.</summary>
    public class LocalizedDescriptionAttribute : DescriptionAttribute
    {
        #region Constructors and Destructors

        /// <summary>Initialisiert eine neue Instanz der <see cref="LocalizedDescriptionAttribute"/> Klasse.</summary>
        /// <param name="resourceKey">Der ResourceKey.</param>
        /// <param name="resourceType">Der ResourceType.</param>
        public LocalizedDescriptionAttribute(string resourceKey, Type resourceType)
        {
            Resource = new ResourceManager(resourceType);
            ResourceKey = resourceKey;
        }

        #endregion

        #region Public Properties

        /// <summary>Liest Description.</summary>
        public override string Description
        {
            get
            {
                var displayName = Resource.GetString(ResourceKey);

                return string.IsNullOrEmpty(displayName) ? string.Format("[[{0}]]", ResourceKey) : displayName;
            }
        }

        #endregion

        #region Properties

        /// <summary>Die Resource.</summary>
        private ResourceManager Resource { get; set; }

        /// <summary>Der ResourceKey.</summary>
        private string ResourceKey { get; set; }

        #endregion
    }
}