﻿namespace IEPostBusinessApi
{
    using System;
    using System.Collections.Generic;
    using System.Windows.Controls;

    using IEPostBusinessApi.JSON.Access;
    using IEPostBusinessApi.JSON.Draft;

    /// <summary>Das Login-Interface stellt die Schnittstelle zu den Login-Daten bereit.</summary>
    public interface ILogin
    {
        #region Public Properties

        /// <summary>Liest AccessToken.</summary>
        AccessTokenResponse AccessToken { get; set; }

        /// <summary>
        /// Diese URL wird als Zielsystem angenommen, wenn ein drittes System angesprochen werden sollte und ThirdSystem gewählt wurde.
        /// </summary>
        string ThirdSystemUrl { get; set; }

        /// <summary>
        /// Ein beliebiger String, der die Client-Applikation identifiziert.<br/>
        /// Die <em>client_id</em> ergibt sich aus <em>DevId</em> und <em>AppId</em>, die Sie
        /// bei der Registrierung für E‑POSTBUSINESS API angeben. Die Bildungsvorschrift der <em>client_id</em> erfolgt auf folgende
        /// Weise:
        /// <ul>
        ///     <li><em>clientid</em> = <em>DevId</em> "," <em>AppId</em></li>
        /// </ul>
        /// </summary>
        string ClientId { get; set; }

        /// <summary>Liest oder setzt CreateDraftResponse.</summary>
        CreateDraftResponse CreateDraftResponse { get; set; }

        /// <summary>
        /// Legt fest, welchen Code-Typ der Client für den Token-Tausch anbietet.
        /// </summary>
        GrantType GrantType { get; set; }

        /// <summary>Gibt den Status der letzten Aktion an.</summary>
        bool IsOk { get; }

        /// <summary>
        /// Die zu verwendende LIF-Datei.
        /// </summary>
        string LifContent { get; set; }

        /// <summary>
        /// Passwort des Nutzers.
        /// </summary>
        string Password { get; set; }

        /// <summary>
        /// Die URI, an welche das Login-Ergebnis geleitet wird. Die
        /// <em>redirect_uri</em> muss dem E‑POST System bekannt sein. Die finale vom System erzeugte <em>redirect_uri</em> darf nicht länger als
        /// 2083 Zeichen sein, inklusive Protokollangabe und weiterer Parameter, andernfalls kommt es zu einem
        /// Darstellungsproblem
        /// sowohl beim Browser als auch beim Server.
        /// </summary>
        Uri RedirectUri { get; set; }

        /// <summary>
        /// Der Scope legt fest, inwieweit der Client auf die Ressource(n)
        /// des Nutzers zugreift:
        /// <ul>
        /// 	<li>Es ist möglich, mehrere Scopes gleichzeitig anzugeben.</li>
        /// 	<li>Mehrere Scopes werden entweder mit einem maskierten Leerzeichen oder mit einem + -Zeichen voneinander getrennt.</li>
        /// 	<li>Beispiel für mehrere Scopes: scope=send_letter+read_letter.</li>
        /// 	<li>Das Authentisierungs-Niveau gibt an, ob sich der Nutzer des E‐POST Systems mit einer HandyTAN authentifizieren muss (hoch) oder nicht (normal).</li>
        /// 	<li>Folgende Scopes sind möglich:</li>
        /// 	<dl>
        ///    		<dt>send_letter</dt>
        ///    		<dd>
        /// 			<ul>
        /// 				<li>erlaubt das Versenden von elektronischen E‐POSTBRIEFEN</li>
        /// 				<li>erfordert ein hohes Authentifizierungs-Niveau</li>
        /// 			</ul>
        /// 		</dd>
        /// 		<dt>send_hybrid</dt>
        /// 		<dd>
        /// 			<ul>
        /// 				<li>erlaubt das Versenden von physischen E‐POSTBRIEFEN</li>
        /// 				<li>erfordert ein normales Authentifizierungs-Niveau</li>
        /// 			</ul>
        /// 		</dd>
        /// 		<dt>read_letter</dt>
        /// 		<dd>
        /// 			<ul>
        /// 				<li>erlaubt das Lesen von E‐POSTBRIEFEN</li>
        /// 				<li>erfordert ein normales Authentifizierungs-Niveau</li>
        /// 			</ul>
        /// 		</dd>
        /// 		<dt>create_letter</dt>
        /// 		<dd>
        /// 			<ul>
        /// 				<li>erlaubt das Erstellen von E‐POSTBRIEF Entwürfen</li>
        /// 				<li>erfordert ein normales Authentifizierungs-Niveau</li>
        /// 			</ul>
        /// 		</dd>
        /// 		<dt>delete_letter</dt>
        /// 		<dd>
        /// 			<ul>
        /// 				<li>erlaubt das Löschen von E‐POSTBRIEF Entwürfen</li>
        /// 				<li>erfordert ein normales Authentifizierungs-Niveau</li>
        /// 			</ul>
        /// 		</dd>
        /// 	</dl>
        /// </ul>
        /// </summary>
        List<Scope> Scopes { get; set; }

        /// <summary>
        /// Ein beliebiger String von maximal 512 Zeichen Länge, der den
        /// Zustand der Applikation beschreibt. Der Wert wird der Applikation im Login-Ergebnis zurückgegeben. Hier kann z. B.
        /// eine Session-ID durchgereicht werden.
        /// </summary>
        string State { get; set; }

        /// <summary>Liest oder setzt SystemType.</summary>
        SystemType SystemType { get; set; }

        /// <summary>
        /// Der Nutzername.
        /// </summary>
        string Username { get; set; }

        /// <summary>Liest WorkStatus.</summary>
        WorkStatus WorkStatus { get; }

        #endregion

        #region Public Methods and Operators

        /// <summary>Der Login mit oder ohne Browser.</summary>
        /// <param name="browser">Der Browser.</param>
        /// <param name="enterPasswordInHtmlPage">The enter password in html page.</param>
        void InternalLogin(WebBrowser browser, bool enterPasswordInHtmlPage);

        /// <summary>Erhöht das Anmeldeniveau, um auch elektronische E-POSTBRIEFE versenden zu können.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die Interaktionen angezeigt werden.</param>
        void LoginExtensionSendLetter(WebBrowser browser);

        #endregion
    }
}