﻿namespace IEPostBusinessApi
{
    using System;

    /// <summary>Der LoginStatusEventHandler informiert über den LoginStatus.</summary>
    /// <param name="sender">Der Sender.</param>
    /// <param name="loginStatusEventArgs">Die LoginStatusEventArgs.</param>
    public delegate void LoginStatusEventHandler(object sender, LoginStatusEventArgs loginStatusEventArgs);

    /// <summary>Die LoginStatusEventArg enthalten die Informationen über den übertragenen LoginStatus.</summary>
    public class LoginStatusEventArgs : EventArgs
    {
        #region Constructors and Destructors

        /// <summary>Initialisiert eine neue Instanz der <see cref="LoginStatusEventArgs"/> Klasse.</summary>
        /// <param name="loginStatus">Der LoginStatus.</param>
        public LoginStatusEventArgs(LoginStatus loginStatus)
        {
            LoginStatus = loginStatus;
        }

        #endregion

        #region Public Properties

        /// <summary>Liest LoginStatus.</summary>
        public LoginStatus LoginStatus { get; private set; }

        #endregion
    }
}