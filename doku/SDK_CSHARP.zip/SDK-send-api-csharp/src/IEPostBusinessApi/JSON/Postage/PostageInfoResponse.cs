﻿namespace IEPostBusinessApi.JSON.Postage
{
    using Newtonsoft.Json;

    /// <summary>
    /// POST /postage-info gibt eine Preisangabe durch die Referenz auf einen gespeicherten
    /// E‑POSTBRIEF Entwurf zurück.<br/>
    /// Für die Preisabfrage sind folgende Angaben beim Scope möglich:
    /// <dl>
    ///     <dt>send_letter</dt>
    ///     <dd>Preisabfrage für einen für den elektronischen Versand vorgesehenen E‑POSTBRIEF</dd>
    ///     <dt>send_hybrid</dt>
    ///     <dd>Preisabfrage für einen für den physischen Versand vorgesehenen E‑POSTBRIEF</dd>
    /// </dl>
    /// </summary>
    public class PostageInfoResponse
    {
        #region Public Properties

        /// <summary>
        /// Das Objekt umfasst die Preisinformationen.
        /// </summary>
        [JsonProperty("total-price")]
        public TotalPrice TotalPrice { get; set; }

        #endregion
    }
}