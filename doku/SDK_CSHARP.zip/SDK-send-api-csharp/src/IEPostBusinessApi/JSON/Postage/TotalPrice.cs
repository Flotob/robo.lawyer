namespace IEPostBusinessApi.JSON.Postage
{
    using Newtonsoft.Json;

    /// <summary>
    /// Das Objekt umfasst die Preisinformationen.
    /// </summary>
    public class TotalPrice
    {
        #region Public Properties

        /// <summary>
        /// Die W�hrung des Versandpreises.
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Der Betrag des Versandpreises.
        /// </summary>
        [JsonProperty("gross-amount")]
        public double GrossAmount { get; set; }

        #endregion
    }
}