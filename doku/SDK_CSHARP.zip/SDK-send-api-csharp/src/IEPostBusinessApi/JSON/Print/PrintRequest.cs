﻿namespace IEPostBusinessApi.JSON.Print
{
    using Newtonsoft.Json;

    /// <summary>
    /// Diese Metadaten legen Sie bei einem physischem E‑POSTBRIEF Versand an.
    /// </summary>
    public class PrintRequest
    {
        #region Public Properties

        /// <summary>
        /// Die Option legt fest, ob für den Versand ein Deckblatt generiert werden soll, oder dieses im mitgelieferten PDF-Anhang enthalten ist (erste Seite). Die Option kann folgende Werte annehmen:
        /// <dl>
        /// 	<dt>included</dt>
        /// 	<dd>Die erste Seite des des eingelieferten PDFs wird als Anschreiben verwendet</dd>
        /// 	<dt>generate</dt>
        /// 	<dd>Das Deckblatt wird automatisch generiert</dd>
        /// </dl>
        /// 
        /// Wenn die Option nicht spezifiziert wird, wird der Standardwert generate verwendet.
        /// </summary>
        [JsonProperty("coverletter")]
        public CoverLetter CoverLetter { get; set; }

        /// <summary>
        /// Enthält die Meta-Informationen zum E-POSTBRIEF für den physischen Versand.
        /// </summary>
        [JsonProperty("printed")]
        public Printed Printed { get; set; }

        /// <summary>
        /// Der Betreff des E‑POSTBRIEFS.<br/>
        /// Wenn keine Angabe gemacht wird, wird der Betreff automatisch vom System vergeben.
        /// </summary>
        [JsonProperty("subject")]
        public string Subject { get; set; }

        #endregion
    }
}