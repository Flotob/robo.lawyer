﻿namespace IEPostBusinessApi.JSON.Print
{
    using Newtonsoft.Json;

    /// <summary>
    /// Übergabe einer Liste von Empfängern für einen E‑POSTBRIEF für
    /// den physischen Versand. Zurzeit
    /// wird nur ein Empfänger unterstützt, weshalb die Liste genau ein
    /// Element enthalten muss.
    /// Folgende Werte sind Pflichtangaben:
    /// <ul>
    ///     <li><em>streetName</em> und <em>city</em> oder</li>
    ///     <li><em>postOfficeBox</em> und <em>city</em></li>
    /// </ul>
    /// Beachten Sie, dass das
    /// Setzen des Wertes <em>street-Name</em> den Wert <em>postOffice-Box</em> ausschließt (und umgekehrt). Das gleichzeitige Setzen beider
    /// Werte führt zum
    /// Abbruch der Verarbeitung.
    /// </summary>
    public class To
    {
        #region Public Properties

        /// <summary>Liest oder setzt die Zusatzinformation zur Adresse.</summary>
        [JsonProperty("addressAddOn")]
        public string AddressAddOn { get; set; }

        /// <summary>Liest oder setzt den Ort.</summary>
        [JsonProperty("city")]
        public string City { get; set; }

        /// <summary>Liest oder setzt den Firmennamen.</summary>
        [JsonProperty("company")]
        public string Company { get; set; }

        /// <summary>Liest oder setzt den Vornamen.</summary>
        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        /// <summary>Liest oder setzt die Hausnummer.</summary>
        [JsonProperty("houseNumber")]
        public string HouseNumber { get; set; }

        /// <summary>Liest oder setzt den Nachnamen.</summary>
        [JsonProperty("lastName")]
        public string LastName { get; set; }

        /// <summary>Liest oder setzt das Postfach.</summary>
        [JsonProperty("postOfficeBox")]
        public string PostOfficeBox { get; set; }

        /// <summary>Liest oder setzt die Anrede.</summary>
        [JsonProperty("salutation")]
        public string Salutation { get; set; }

        /// <summary>Liest oder setzt die Straße.</summary>
        [JsonProperty("streetName")]
        public string StreetName { get; set; }

        /// <summary>Liest oder setzt den Titel der Person.</summary>
        [JsonProperty("title")]
        public string Title { get; set; }

        /// <summary>Liest oder setzt die Postleitzahl.</summary>
        [JsonProperty("zipCode")]
        public string ZipCode { get; set; }

        #endregion
    }
}