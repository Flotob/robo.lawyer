﻿namespace IEPostBusinessApi.JSON.Print
{
    using Newtonsoft.Json;

    /// <summary>
    /// Die Option legt fest, ob für den Versand ein Deckblatt generiert werden soll, oder dieses im mitgelieferten PDF-Anhang enthalten ist (erste Seite). Die
    /// Option kann folgende Werte annehmen:
    /// <dl>
    /// 	<dt>included</dt>
    /// 	<dd>die erste Seite des des eingelieferten PDFs wird als Anschreiben verwendet</dd>
    /// 	<dt>generate</dt>
    /// 	<dd>das Deckblatt wird automatisch generiert</dd>
    /// </dl>
    /// Wenn die Option nicht spezifiziert wird, wird der Standardwert generate verwendet.
    /// </summary>
    public class CoverLetter
    {
        #region Public Properties

        /// <summary>
        /// Ein Versand ohne Deckblatt wird
        /// festgelegt und die Angabe true
        /// legt fest, dass die erste Seite des
        /// ersten eingelieferten PDF-Doku-mentes als Anschreiben zum Ver-sand des Briefes verwendet wird,
        /// wodurch die automatisch generierte erste Seite ersetzt wird.<br/>
        /// Die Option schließt die Verwendung von electronic.to
        /// aus, da die Adressdaten auf
        /// der ersten Seite des eingelieferten PDF-Dokuments erwartet werden.
        /// Die erste Seite muss eine gültige
        /// Postanschrift an der richtigen Stelle enthalten.
        /// Die Option kann folgende Werte
        /// annehmen:
        /// <ul>
        ///     <li>true</li>
        ///     <li>false</li>
        /// </ul>
        /// Beim Setzen des Wertes auf
        /// true findet zurzeit keine Konsistenzprüfung der Adressdaten aus printed.to und der
        /// Anschrift der ersten Seite des
        /// Briefes statt.
        /// </summary>
        [JsonProperty("included")]
        public bool Included { get; set; }

        #endregion
    }
}