﻿namespace IEPostBusinessApi.JSON.Print
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Angabe, dass Versandoptionen übergeben werden.
    /// </summary>
    public class Options
    {
        #region Public Properties

        /// <summary>
        /// Die Option legt fest, ob ein Farb- oder Schwarz-Weiß-Druck ausgeführt wird.<br/>
        /// Die Option kann folgende Werte annehmen:
        /// <dl>
        /// 	<dt>grayscale</dt>
        ///	    <dd>Schwarz-Weiß</dd>
        /// 	<dt>colored</dt>
        ///	    <dd>Farbe</dd>
        /// </dl>
        /// Wenn die Option nicht spezifiziert wird, wird der Standardwert grayscale verwendet.
        /// </summary>
        [JsonProperty("color")]
        [JsonConverter(typeof(StringEnumConverter))]
        public ColorEnum Color { get; set; }

        /// <summary>
        /// Die Option gibt an, ob der E-POSTBRIEF als Einschreiben versendet wird, und wenn ja, welcher Einschreiben-Typ gewählt ist
        /// Die Option kann folgende Werte annehmen:
        /// <dl>
        /// 	<dt>no</dt>
        /// 	<dd>kein Einschreiben</dd>
        /// 	<dt>standard</dt>
        /// 	<dd>Einschreiben</dd>
        /// 	<dt>submissionOnly</dt>
        /// 	<dd>Einschreiben Einwurf</dd>
        /// 	<dt>addresseeOnly</dt>
        /// 	<dd>Einschreiben eigenhändig</dd>
        /// 	<dt>withReturnReceipt</dt>
        /// 	<dd>Einschreiben Rückschein</dd>
        /// 	<dt>addresseeOnlyWithReturnReceipt</dt>
        /// 	<dd>Einschreiben eigenhändig Rückschein</dd>
        /// 	<dt>Wird kein Wert angegeben:</dt>
        /// 	<dd>Standardbrief, kein Einschreiben</dd>
        /// 
        /// </dl>
        /// Wenn die Option nicht spezifiziert wird, wird der Standardwert no verwendet.
        /// </summary>
        [JsonProperty("registered")]
        [JsonConverter(typeof(StringEnumConverter))]
        public RegisteredEnum Registered { get; set; }

        #endregion
    }
}