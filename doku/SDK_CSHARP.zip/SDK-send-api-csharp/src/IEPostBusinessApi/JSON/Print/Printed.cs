﻿namespace IEPostBusinessApi.JSON.Print
{
    using System.Collections.Generic;

    using Newtonsoft.Json;

    /// <summary>
    /// Enthält die Metadaten des E-POSTBRIEFS für den physischen Versand.
    /// </summary>
    public class Printed
    {
        #region Public Properties

        /// <summary>
        /// Angabe, dass Versandoptionen übergeben werden.
        /// </summary>
        [JsonProperty("options")]
        public Options Options { get; set; }

        /// <summary>
        /// Übergabe einer Liste von Empfängern für einen E‑POSTBRIEF für
        /// den physischen Versand. Zurzeit
        /// wird nur ein Empfänger unterstützt, weshalb die Liste genau ein
        /// Element enthalten muss.
        /// Folgende Werte sind Pflichtangaben:
        /// <ul>
        ///     <li><em>streetName</em> und <em>city</em> oder</li>
        ///     <li><em>postOfficeBox</em> und <em>city</em></li>
        /// </ul>
        /// Beachten Sie, dass das
        /// Setzen des Wertes <em>street-Name</em> den Wert <em>postOffice-Box</em> ausschließt (und umgekehrt). Das gleichzeitige Setzen beider
        /// Werte führt zum
        /// Abbruch der Verarbeitung.
        /// </summary>
        [JsonProperty("to")]
        public List<To> To { get; set; }

        #endregion
    }
}