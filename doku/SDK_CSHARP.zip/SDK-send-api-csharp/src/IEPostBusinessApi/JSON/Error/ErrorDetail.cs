namespace IEPostBusinessApi.JSON.Error
{
    using Newtonsoft.Json;

    /// <summary>
    /// Eine detaillierte Fehlerbeschreibung.
    /// </summary>
    public class ErrorDetail
    {
        #region Public Properties

        /// <summary>
        /// Eine detaillierten Fehlerbeschreibungen.
        /// </summary>
        [JsonProperty("description")]
        public string Description { get; set; }

        /// <summary>
        /// Fehlercodes im Stil CORE_XXX
        /// </summary>
        [JsonProperty("errorCode")]
        public string ErrorCode { get; set; }

        #endregion
    }
}