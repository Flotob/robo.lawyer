﻿namespace IEPostBusinessApi.JSON.Error
{
    using System.Collections.Generic;

    using Newtonsoft.Json;

    /// <summary>Die von der REST-API zurückgelieferte Fehlermeldung.</summary>
    public class ErrorResponse
    {
        #region Public Properties

        /// <summary>
        /// Auftretende Fehlercodes zu den entsprechenden Statuscodes:<br />
        /// invalid_letter (400)<br />
        /// Die Verarbeitung ist nicht möglich. Mögliche Fehlerursachen können<br />
        /// sein:<br />
        /// - nicht zulässiges PDF,<br />
        /// - PDF mit zu vielen Seiten,<br />
        /// - PDF nicht druckbar (Formatierungsfehler),<br />
        /// - ungültige Adresse.<br />
        /// Unter 8.4 PDF-Anforderungen für eine hohe Druckqualitätfinden Sie<br />
        /// ausführliche Informationen zu möglichen Fehlern bei der Einlieferung<br />
        /// von PDF-Dateien.<br />
        /// invalid_recipient (400)<br />
        /// Der angegebene Empfänger ist nicht korrekt oder unbekannt.<br />
        /// too_many_attachments (400)<br />
        /// Die Anzahl der gelieferten PDF-Dokumente darf nicht größer als 99<br />
        /// sein.<br />
        /// json_body_part_missing (400)<br />
        /// Die Metadaten des Briefes fehlen.<br />
        /// pdf_body_part_missing (400)<br />
        /// Der Brief fehlt, d. h. es wurde kein PDF-Dokument geliefert.<br />
        /// invalid_media_type (400)<br />
        /// Für die verschiedenen Teile des Briefes dürfen nur die folgenden Ty-pen verwendet werden:<br />
        /// - application/vnd.epost-send-api+json<br />
        /// - application/pdf<br />
        /// invalid_meta_data (400)<br />
        /// Die Metadaten des Briefes sind ungültig. Mögliche Fehlerursachen<br />
        /// können sein:<br />
        /// - Die Eigenschaften printed und electronicdürfen nicht zusammen verwendet werden.<br />
        /// - Eine der beiden Eigenschaften printedoder electronicmuss<br />
        /// angegeben werden.<br />
        /// - Die Liste der Adressaten fehlt.<br />
        /// - Die Adressaten wurden nicht in Form einer Liste übermittelt.<br />
        /// - Die Liste der Adressaten enthält mehr als einen Eintrag.<br />
        /// - Der Wert der Farbdruckoption ist unzulässig.<br />
        /// - Im Adressatenfeld printed.to wurde gleichzeitig Straßenname<br />
        /// und Postfach angegeben.<br />
        /// - Im Falle eines elektronischen Versands muss ein Adressat eine<br />
        /// Eigenschaft epbAddress enthalten.<br />
        /// - Im Falle eines elektronischen Versands muss die E-POSTBRIEF<br />
        /// Adresse eines Adressaten eine gültige Domain enthalten.<br />
        /// invalid_token (401)<br />
        /// Das Access Tokenist abgelaufen oder ungültig.<br />
        /// not_billable (403)<br />
        /// Der Vorgang kann nicht abgebucht werden, da das jeweilige Kunden-konto entweder gesperrt ist oder kein
        /// ausreichendes Guthaben auf-weist.<br />
        /// insufficient_scope (403)<br />
        /// Das Access Tokenhat nicht die benötigten Privilegien.<br />
        /// malware_detected (403)<br />
        /// Der Brief enthält Schadsoftware.<br />
        /// </summary>
        [JsonProperty("error")]
        public string Error { get; set; }

        /// <summary>
        /// Für Menschen lesbarer Text mit zusätzlichen Informationen, um den
        /// Entwickler beim Verstehen des aufgetretenen Fehlers zu unterstützen.
        /// </summary>
        [JsonProperty("error_description")]
        public string ErrorDescription { get; set; }

        /// <summary>
        /// Eine detaillierten Fehlerbeschreibungen.
        /// </summary>
        [JsonProperty("error_details")]
        public List<ErrorDetail> ErrorDetails { get; set; }

        /// <summary>
        /// Eine URI, die eine für Menschen lesbare Webseite mit Informationen
        /// über den Fehler informiert.
        /// </summary>
        [JsonProperty("error_uri")]
        public string ErrorUri { get; set; }

        #endregion
    }
}