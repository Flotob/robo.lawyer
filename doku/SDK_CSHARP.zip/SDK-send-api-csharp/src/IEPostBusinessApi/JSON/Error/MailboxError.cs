﻿namespace IEPostBusinessApi.JSON.Error
{
    using Newtonsoft.Json;

    /// <summary>
    /// Eine detaillierte Fehlerbeschreibung.
    /// </summary>
    public class MailboxError
    {
        #region Public Properties

        /// <summary>
        /// Fehlercodes im Stil CORE_XXX
        /// </summary>
        [JsonProperty("errorCode")]
        public string ErrorCode { get; set; }

        /// <summary>
        /// Eine detaillierten Fehlerbeschreibungen.
        /// </summary>
        [JsonProperty("errorDescription")]
        public string ErrorDescription { get; set; }

        #endregion
    }
}