﻿namespace IEPostBusinessApi.JSON.Electronic
{
    using Newtonsoft.Json;

    /// <summary>
    /// Metadaten für den elektronischen E‑POSTBRIEF Versand:<br/>
    /// Die nachfolgenden Metadaten legt Ihre Applikation an, wenn diese einen elektronischen
    /// E‑POSTBRIEF Versand vornimmt.
    /// </summary>
    public class ElectronicRequest
    {
        #region Public Properties

        /// <summary>
        /// Angabe, dass E‑POSTBRIEF Metadaten für den elektronischen
        /// Versand übergeben werden.
        /// </summary>
        [JsonProperty("electronic")]
        public Electronic Electronic { get; set; }

        /// <summary>
        /// Der E‑POSTBRIEF Betreff.
        /// </summary>
        [JsonProperty("subject")]
        public string Subject { get; set; }

        #endregion
    }
}