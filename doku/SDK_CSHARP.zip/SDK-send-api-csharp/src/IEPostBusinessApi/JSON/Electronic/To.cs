﻿namespace IEPostBusinessApi.JSON.Electronic
{
    using Newtonsoft.Json;

    /// <summary>
    /// Übergabe einer Liste von E‑POSTBRIEF Empfängern:<br/>
    /// Zurzeit wird
    /// nur ein Empfänger unterstützt,
    /// weshalb die Liste genau ein Element enthalten muss.
    /// </summary>
    public class To
    {
        #region Public Properties

        /// <summary>
        /// Angabe einer gültigen E‑POST-BRIEF Adresse.
        /// </summary>
        [JsonProperty("epbAddress")]
        public string EpbAddress { get; set; }

        #endregion
    }
}