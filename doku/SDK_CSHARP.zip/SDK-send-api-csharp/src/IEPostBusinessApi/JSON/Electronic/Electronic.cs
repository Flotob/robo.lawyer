﻿namespace IEPostBusinessApi.JSON.Electronic
{
    using System.Collections.Generic;

    using Newtonsoft.Json;

    /// <summary>
    /// Angabe, dass E‑POSTBRIEF Metadaten für den elektronischen
    /// Versand übergeben werden.
    /// </summary>
    public class Electronic
    {
        #region Public Properties

        /// <summary>
        /// Übergabe einer Liste von E‑POSTBRIEF Empfängern. Zurzeit wird
        /// nur ein Empfänger unterstützt,
        /// weshalb die Liste genau ein Element enthalten muss.
        /// </summary>
        [JsonProperty("to")]
        public List<To> To { get; set; }

        #endregion
    }
}