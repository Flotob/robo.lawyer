﻿namespace IEPostBusinessApi.JSON.Folder
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Objekt, das Metadaten über den Ordner angibt.
    /// </summary>
    public class FolderInfo
    {
        #region Public Properties

        /// <summary>
        /// Die folderId des Ordners.
        /// </summary>
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>
        /// Der Name des Ordners.
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Der Typ des Ordners (siehe 4.2 Ordner):
        /// <dl>
        ///     <dd>SYSTEM</dd>
        ///     <dt>Systemordner</dt>
        ///     <dd>USER</dd>
        ///     <dt>Nutzerordner</dt>
        /// </dl>
        /// </summary>
        [JsonProperty("type")]
        [JsonConverter(typeof(StringEnumConverter))]
        public FolderType Type { get; set; }

        #endregion
    }
}