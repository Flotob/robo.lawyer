﻿namespace IEPostBusinessApi.JSON.Folder
{
    using Newtonsoft.Json;

    /// <summary>
    /// Objekt, das Paginierungsinformationen enthält.
    /// </summary>
    public class Paging
    {
        #region Public Properties

        /// <summary>
        /// Der in der Anfrage übergebene Limit-Wert oder der Standardwert.
        /// </summary>
        [JsonProperty("currentLimit")]
        public int CurrentLimit { get; set; }

        /// <summary>
        /// Der in der Anfrage übergebene Offset-Wert oder der Standardwert.
        /// </summary>
        [JsonProperty("currentOffset")]
        public int CurrentOffset { get; set; }

        /// <summary>
        /// Objekt, das die FolderLinks für die Paginierungsinformationen enthält.
        /// </summary>
        [JsonProperty("_links")]
        public FolderLinks FolderLinks { get; set; }

        #endregion
    }
}