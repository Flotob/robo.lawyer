﻿namespace IEPostBusinessApi.JSON.Folder
{
    using Newtonsoft.Json;

    /// <summary>
    /// Objekt, das die FolderLinks für die Paginierungsinformationen enthält.
    /// </summary>
    public class FolderLinks
    {
        #region Public Properties

        /// <summary>
        /// Gibt den Link auf die nächste Seite an. Ist nur dann angegeben, wenn es eine nächste Seite gibt.
        /// </summary>
        [JsonProperty("next")]
        public Link Next { get; set; }

        /// <summary>
        /// Gibt den Link auf das Template an, das beschreibt, wie Seiten angefordert werden können.
        /// </summary>
        [JsonProperty("page")]
        public Link Page { get; set; }

        /// <summary>
        /// Gibt den Link auf die vorherige Seite an. Ist nur dann angegeben, wenn es eine vorherige Seite gibt.
        /// </summary>
        [JsonProperty("previous")]
        public Link Previous { get; set; }

        #endregion
    }
}