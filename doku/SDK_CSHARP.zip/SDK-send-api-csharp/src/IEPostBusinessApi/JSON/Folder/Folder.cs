﻿namespace IEPostBusinessApi.JSON.Folder
{
    using System.Collections.Generic;

    using IEPostBusinessApi.JSON.Draft;

    using Newtonsoft.Json;

    /// <summary>
    /// Metadaten von Foldern.
    /// </summary>
    public class Folder
    {
        #region Public Properties

        /// <summary>
        /// Liste mit Informationen zu den Unterordnern. Der Aufbau entspricht dabei dem Schema
        /// des übergeordneten Ordners: es werden die Objekte folderStatus, folderInfo, _linkss
        /// und entries dargestellt.
        /// </summary>
        [JsonProperty("entries", NullValueHandling = NullValueHandling.Ignore)]
        public List<Folder> Entries { get; set; }

        /// <summary>
        /// Liste, die die im Ordner enthaltenen E‑POSTBRIEFE auflistet. Die Metadaten der
        /// E‑POSTBRIEFE entsprechen 5.1.1 Metadaten eines E‑POSTBRIEFS.
        /// </summary>
        [JsonProperty("envelopes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Envelope> Envelopes { get; set; }

        /// <summary>
        /// Objekt, das Metadaten über den Ordner angibt.
        /// </summary>
        [JsonProperty("folderInfo", NullValueHandling = NullValueHandling.Ignore)]
        public FolderInfo FolderInfo { get; set; }

        /// <summary>
        /// Objekt zur Anzeige von Übersichtswerten für den Ordner.
        /// </summary>
        [JsonProperty("folderStatus", NullValueHandling = NullValueHandling.Ignore)]
        public FolderStatus FolderStatus { get; set; }

        /// <summary>
        /// Objekt, das Metadaten über den Ordner angibt.
        /// </summary>
        [JsonProperty("info", NullValueHandling = NullValueHandling.Ignore)]
        public FolderInfo Info { get; set; }

        /// <summary>
        /// Objekt, das abrufbare Links zu Informationen zum Ordner enthält.
        /// </summary>
        [JsonProperty("_links", NullValueHandling = NullValueHandling.Ignore)]
        public Links Links { get; set; }

        /// <summary>
        /// Objekt, das Paginierungsinformationen enthält.
        /// </summary>
        [JsonProperty("paging", NullValueHandling = NullValueHandling.Ignore)]
        public Paging Paging { get; set; }

        /// <summary>
        /// Objekt zur Anzeige von Übersichtswerten für den Ordner.
        /// </summary>
        [JsonProperty("status", NullValueHandling = NullValueHandling.Ignore)]
        public FolderStatus Status { get; set; }

        #endregion
    }
}