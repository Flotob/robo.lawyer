﻿namespace IEPostBusinessApi.JSON.Folder
{
    /// <summary>
    /// Der Typ des Ordners (siehe 4.2 Ordner):
    /// <dl>
    ///     <dd>SYSTEM</dd>
    ///     <dt>Systemordner</dt>
    ///     <dd>USER</dd>
    ///     <dt>Nutzerordner</dt>
    /// </dl>
    /// </summary>
    public enum FolderType
    {
        // ReSharper disable InconsistentNaming
        // Hier werden die Enum entgegen der Namenskonventionen definiert, da sie genau so auch in der REST-API
        // verwendet werden können und so die Interoperabilität besser erhalten werden kann.

        /// <summary>
        /// Systemordner.
        /// </summary>
        SYSTEM, 

        /// <summary>
        /// Nutzerordner
        /// </summary>
        USER
    }
}