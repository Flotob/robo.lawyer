﻿namespace IEPostBusinessApi.JSON.Folder
{
    using Newtonsoft.Json;

    /// <summary>
    /// URI, die zum Abruf der Metadaten des Ordners genutzt werden kann.
    /// </summary>
    public class Links
    {
        #region Public Properties

        /// <summary>
        /// URI, die zum Abruf des Inhalts des Ordners genutzt werden kann.
        /// </summary>
        [JsonProperty("content")]
        public Content Content { get; set; }

        /// <summary>
        /// Gibt den link auf eine Seite an.
        /// </summary>
        [JsonProperty("self")]
        public Link Self { get; set; }

        #endregion
    }
}