﻿namespace IEPostBusinessApi.JSON.Folder
{
    using Newtonsoft.Json;

    /// <summary>
    /// URI, die zum Abruf des Inhalts des Ordners genutzt werden kann.
    /// </summary>
    public class Content
    {
        #region Public Properties

        /// <summary>
        /// Gibt den Link auf eine Seite an.
        /// </summary>
        [JsonProperty("href")]
        public string Href { get; set; }

        /// <summary>
        /// NN.
        /// </summary>
        [JsonProperty("templated")]
        public bool Templated { get; set; }

        #endregion
    }
}