﻿namespace IEPostBusinessApi.JSON.Folder
{
    using Newtonsoft.Json;

    /// <summary>
    /// Objekt zur Anzeige von Übersichtswerten für den Ordner.
    /// </summary>
    public class FolderStatus
    {
        #region Public Properties

        /// <summary>
        /// Markierung uber den Datenstand der E-POSTBRIEF Liste. Diese Markierung wird für die Berechnung des ETags verwendet.
        /// </summary>
        [JsonProperty("contentTag")]
        public string ContentTag { get; set; }

        /// <summary>
        /// Gibt die Gesamtanzahl der E‑POSTBRIEFE im Ordner an.
        /// </summary>
        [JsonProperty("totalCount")]
        public int TotalCount { get; set; }

        /// <summary>
        /// Gibt die Anzahl ungelesener E‑POSTBRIEFE im Ordner an.
        /// </summary>
        [JsonProperty("unreadCount")]
        public int UnreadCount { get; set; }

        #endregion
    }
}