﻿namespace IEPostBusinessApi.JSON.Folder
{
    using Newtonsoft.Json;

    /// <summary>
    /// Gibt den link auf eine Seite an.
    /// </summary>
    public class Link
    {
        #region Public Properties

        /// <summary>
        /// Der Link auf eine Seite
        /// </summary>
        [JsonProperty("href")]
        public string Href { get; set; }

        #endregion
    }
}