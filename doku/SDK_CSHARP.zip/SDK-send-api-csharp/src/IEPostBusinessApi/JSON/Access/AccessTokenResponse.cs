﻿namespace IEPostBusinessApi.JSON.Access
{
    using Newtonsoft.Json;

    /// <summary>
    /// Die Antwort im Erfolgsfall (Statuscode 200):<br/>
    /// Im Erfolgsfall wird ein Ticket in Form eines JSON-Objekts zurückgegeben,
    /// welches ein Access Token enthält.
    /// </summary>
    public class AccessTokenResponse
    {
        #region Public Properties

        /// <summary>
        /// Das Access Token in Form eines Strings.
        /// </summary>
        [JsonProperty("access_token")]
        public string AccessToken { get; set; }

        /// <summary>
        /// Gültigkeitsdauer des Access Tokens in Sekunden.<br/>
        /// Das Access Token hat eine begrenzte Gültigkeitsdauer, die von der
        /// Login-API bestimmt wird.
        /// </summary>
        [JsonProperty("expires_in")]
        public int ExpiresIn { get; set; }

        /// <summary>
        /// Das Access Token in Form eines Strings.
        /// </summary>
        [JsonProperty("token_type")]
        public string TokenType { get; set; }

        #endregion
    }
}