namespace IEPostBusinessApi.JSON.Draft
{
    using Newtonsoft.Json;

    /// <summary>
    /// URI, die auf die zugeh�rigen Anh�nge
    /// verweist.
    /// </summary>
    public class Attachments
    {
        #region Public Properties

        /// <summary>
        /// URI, die auf die zugeh�rigen Anh�nge
        /// verweist.
        /// </summary>
        [JsonProperty("href")]
        public string Href { get; set; }

        #endregion
    }
}