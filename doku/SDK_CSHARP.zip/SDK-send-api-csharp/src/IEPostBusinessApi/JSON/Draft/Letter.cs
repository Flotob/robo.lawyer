namespace IEPostBusinessApi.JSON.Draft
{
    using Newtonsoft.Json;

    /// <summary>
    /// Gibt die URI an, unter der das Letter-Objekt abrufbar ist.
    /// </summary>
    public class Letter
    {
        #region Public Properties

        /// <summary>Die URI, unter der das Letter-Objekt abrufbar ist.</summary>
        [JsonProperty("href")]
        public string Href { get; set; }

        #endregion
    }
}