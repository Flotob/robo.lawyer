namespace IEPostBusinessApi.JSON.Draft
{
    /// <summary>Der Typ des Versenders.</summary>
    public enum SenderTypeEnum
    {
        // ReSharper disable InconsistentNaming
        // Hier werden die Enum entgegen der Namenskonventionen definiert, da sie genau so auch in der REST-API
        // verwendet werden k�nnen und so die Interoperabilit�t besser erhalten werden kann.

        /// <summary>Privat</summary>
        privat, 

        /// <summary>Gesch�ftlich</summary>
        business, 

        /// <summary>Neutral</summary>
        neutral
    }
}