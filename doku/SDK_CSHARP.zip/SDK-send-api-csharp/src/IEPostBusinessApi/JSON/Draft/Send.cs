﻿namespace IEPostBusinessApi.JSON.Draft
{
    using System.Collections.Generic;

    using Newtonsoft.Json;

    /// <summary>
    /// Die REST URI für den E‑POSTBRIEF
    /// Versand in Form des Domain Applicati-on Protocols:<br/>
    /// Der Link wird nur zurückgegeben,
    /// wenn zusätzlich zum Scope
    /// create_letter der Scope
    /// send_letter oder send_hybrid
    /// angegeben wird.
    /// </summary>
    public class Send
    {
        #region Public Properties

        /// <summary>Liest oder setzt Headers.</summary>
        [JsonProperty("headers")]
        public List<Headers> Headers { get; set; }

        /// <summary>Liest oder setzt Href.</summary>
        [JsonProperty("href")]
        public string Href { get; set; }

        /// <summary>Liest oder setzt Method.</summary>
        [JsonProperty("method")]
        public string Method { get; set; }

        #endregion
    }
}