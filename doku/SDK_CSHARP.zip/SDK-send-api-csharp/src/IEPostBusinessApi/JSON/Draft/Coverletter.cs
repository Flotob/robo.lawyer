﻿namespace IEPostBusinessApi.JSON.Draft
{
    using Newtonsoft.Json;

    /// <summary>
    /// Die REST URI für den E‑POSTBRIEF<br />
    /// Versand in Form des Domain Application Protocols:<br />
    /// Der Link wird nur zurückgegeben,
    /// wenn zusätzlich zum Scope
    /// <em>create_letter</em> der Scope
    /// <em>send_letter</em> oder <em>send_hybrid</em>
    /// angegeben wird.
    /// </summary>
    public class Coverletter
    {
        #region Public Properties

        /// <summary>
        /// Die REST URI für den E‑POSTBRIEF<br />
        /// Versand in Form des Domain Application Protocols:<br />
        /// Der Link wird nur zurückgegeben,
        /// wenn zusätzlich zum Scope
        /// <em>create_letter</em> der Scope
        /// <em>send_letter</em> oder <em>send_hybrid</em>
        /// angegeben wird.
        /// </summary>
        [JsonProperty("href")]
        public string Href { get; set; }

        /// <summary>
        /// Der link auf einen Coverletter.
        /// </summary>
        [JsonProperty("_links")]
        public Links Links { get; set; }

        #endregion
    }
}