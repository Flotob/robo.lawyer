﻿namespace IEPostBusinessApi.JSON.Draft
{
    using Newtonsoft.Json;

    /// <summary>
    /// Übergabe einer Liste von Empfängern für einen E‑POSTBRIEF für
    /// den physischen Versand. Zurzeit
    /// wird nur ein Empfänger unterstützt, weshalb die Liste genau ein
    /// Element enthalten muss.
    /// Folgende Werte sind Pflichtangaben:
    /// <ul>
    ///     <li><em>streetName</em> und <em>city</em> oder</li>
    ///     <li><em>postOfficeBox</em> und <em>city</em></li>
    /// </ul>
    /// Beachten Sie, dass das
    /// Setzen des Wertes <em>street-Name</em> den Wert <em>postOffice-Box</em> ausschließt (und umgekehrt). Das gleichzeitige
    /// Setzen beider
    /// Werte führt zum
    /// Abbruch der Verarbeitung.
    /// </summary>
    public class RecipientsPrinted
    {
        #region Public Properties

        /// <summary>Liest oder setzt Zusatzinformation zur Adresse, z. B. Erdgeschoss.</summary>
        [JsonProperty("addressAddOn", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressAddOn { get; set; }

        /// <summary>Liest oder setzt die Stadt.</summary>
        [JsonProperty("city")]
        public string City { get; set; }

        /// <summary>Liest oder setzt den Firmennamen.</summary>
        [JsonProperty("company", NullValueHandling = NullValueHandling.Ignore)]
        public string Company { get; set; }

        /// <summary>Liest oder setzt den Vornamen.</summary>
        [JsonProperty("firstName", NullValueHandling = NullValueHandling.Ignore)]
        public string FirstName { get; set; }

        /// <summary>Liest oder setzt die Hausnummer.</summary>
        [JsonProperty("houseNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string HouseNumber { get; set; }

        /// <summary>Liest oder setzt den Nachnamen.</summary>
        [JsonProperty("lastName")]
        public string LastName { get; set; }

        /// <summary>Liest oder setzt das Postfach.</summary>
        [JsonProperty("postOfficeBox", NullValueHandling = NullValueHandling.Ignore)]
        public string PostOfficeBox { get; set; }

        /// <summary>Liest oder setzt die Anrede.</summary>
        [JsonProperty("salutation", NullValueHandling = NullValueHandling.Ignore)]
        public string Salutation { get; set; }

        /// <summary>Liest oder setzt den Straßennamen.</summary>
        [JsonProperty("streetName", NullValueHandling = NullValueHandling.Ignore)]
        public string StreetName { get; set; }

        /// <summary>Liest oder setzt den Titel.</summary>
        [JsonProperty("title", NullValueHandling = NullValueHandling.Ignore)]
        public string Title { get; set; }

        /// <summary>Liest oder setzt die Postleitzahl.</summary>
        [JsonProperty("zipCode")]
        public string ZipCode { get; set; }

        #endregion

        #region Public Methods and Operators

        /// <summary>
        /// Returns a <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.
        /// </returns>
        public override string ToString()
        {
            if (FirstName != null)
            {
                return FirstName + " " + LastName;
            }

            return LastName;
        }

        #endregion
    }
}