namespace IEPostBusinessApi.JSON.Draft
{
    /// <summary>Der Nachrichtentyp.</summary>
    public enum MessageTypeEnum
    {
        // ReSharper disable InconsistentNaming
        // Hier werden die Enum entgegen der Namenskonventionen definiert, da sie genau so auch in der REST-API
        // verwendet werden k�nnen und so die Interoperabilit�t besser erhalten werden kann.

        /// <summary>E-POSTBRIEF</summary>
        EPB, 

        /// <summary>Fax</summary>
        FAX
    }
}