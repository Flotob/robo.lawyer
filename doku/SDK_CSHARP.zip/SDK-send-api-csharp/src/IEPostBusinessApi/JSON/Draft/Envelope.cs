﻿namespace IEPostBusinessApi.JSON.Draft
{
    using System;
    using System.Collections.Generic;

    using Newtonsoft.Json;

    /// <summary>
    /// Objekt zum Anlegen der Entwurfsinformationen.
    /// </summary>
    public class Envelope
    {
        #region Public Properties

        /// <summary>
        /// Gibt an, ob der E‑POSTBRIEF
        /// mindestens einen Anhang hat. Der
        /// Wert wird immer geliefert, ist aber
        /// für schreibende Operationen nicht
        /// erforderlich.
        /// </summary>
        [JsonProperty("hasAttachments")]
        public bool HasAttachments { get; set; }

        /// <summary>
        /// ID des Entwurfs
        /// </summary>
        [JsonProperty("letterId")]
        public string LetterId { get; set; }

        /// <summary>
        /// Gibt LetterLinks an, unter denen Ressourcen erreichbar sind.
        /// </summary>
        [JsonProperty("_links")]
        public LetterLinks LetterLinks { get; set; }

        /// <summary>
        /// Gibt an, ob der Brief geschäftlich
        /// oder privat ist.
        /// </summary>
        [JsonProperty("letterType")]
        public LetterType LetterType { get; set; }

        /// <summary>
        /// Gibt an, ob der E‑POSTBRIEF bereits gelesen wurde.
        /// </summary>
        [JsonProperty("read")]
        public bool Read { get; set; }

        /// <summary>
        /// Empfängerinformationen
        /// </summary>
        [JsonProperty("recipients", NullValueHandling = NullValueHandling.Ignore)]
        public List<Recipient> Recipients { get; set; }

        /// <summary>
        /// Liste der Empfänger einer Kopie
        /// (CC)
        /// </summary>
        [JsonProperty("recipientsInCopy", NullValueHandling = NullValueHandling.Ignore)]
        public List<RecipientsInCopy> RecipientsInCopy { get; set; }

        /// <summary>
        /// Übergabe einer Liste von Empfängern für einen E‑POSTBRIEF für
        /// den physischen Versand.<br/>
        /// Zurzeit
        /// wird nur ein Empfänger unterstützt, weshalb die Liste genau ein
        /// Element enthalten muss.
        /// Folgende Werte sind Pflichtangaben:
        /// <ul>
        /// <li>streetName und city oder</li>
        /// <li>postOfficeBox und city</li>
        /// </ul>
        /// Bitte beachten Sie, dass das
        /// Setzen des Wertes street-Name den Wert postOffice-Box ausschließt (und umgekehrt). Das gleichzeitige Setzen beider
        /// Werte führt zum
        /// Abbruch der Verarbeitung.
        /// </summary>
        [JsonProperty("recipientsPrinted", NullValueHandling = NullValueHandling.Ignore)]
        public List<RecipientsPrinted> RecipientsPrinted { get; set; }

        /// <summary>
        /// Absenderinformationen:<br/>
        /// Die Absenderinformationen
        /// ergeben vom angemeldeten
        /// Benutzer und werden vom referenzierten Letter ausgelesen.
        /// </summary>
        [JsonProperty("sender")]
        public Sender Sender { get; set; }

        /// <summary>
        /// Zeitpunkt des Absendens (Timestamp) im Format ISO 8601, z. B.
        /// 2012-10-20T13:05:01+02:00.
        /// </summary>
        [JsonProperty("sentDate")]
        public DateTime SentDate { get; set; }

        /// <summary>
        /// Betreff des E‑POSTBRIEFS
        /// </summary>
        [JsonProperty("subject")]
        public string Subject { get; set; }

        #endregion
    }
}