﻿namespace IEPostBusinessApi.JSON.Draft
{
    using Newtonsoft.Json;

    /// <summary>
    /// Objekt zur Anzeige aller LetterLinks des Entwurfs.
    /// </summary>
    public class Links
    {
        #region Public Properties

        /// <summary>
        /// URI, die auf die zugehörigen Anhänge
        /// verweist
        /// </summary>
        [JsonProperty("attachments")]
        public Attachments Attachments { get; set; }

        /// <summary>
        /// Link auf den Content in einem Attachment.
        /// </summary>
        [JsonProperty("content")]
        public Letter Content { get; set; }

        /// <summary>
        /// URI zum Inhalt des E‑POSTBRIEFS
        /// </summary>
        [JsonProperty("coverletter")]
        public Coverletter Coverletter { get; set; }

        /// <summary>
        /// Die REST URI zum Löschen des Entwurfs in Form des Domain Application
        /// Protocols:<br />
        /// Der Link wird nur zurückgegeben,
        /// wenn zusätzlich zum Scope
        /// create_letter der Scope
        /// delete_letter angegeben wird.
        /// </summary>
        [JsonProperty("delete")]
        public Delete Delete { get; set; }

        /// <summary>
        /// Die REST URI für die Berechnung des
        /// Preises für den Versand in Form des
        /// Domain Application Protocols:<br />
        /// Der Link wird nur zurückgegeben,
        /// wenn zusätzlich zum Scope
        /// create_letter der Scope
        /// send_letter oder send_hybrid
        /// angegeben wird.
        /// </summary>
        [JsonProperty("postageInfo")]
        public PostageInfo PostageInfo { get; set; }

        /// <summary>
        /// URI zum erstellten E‑POSTBRIEF
        /// </summary>
        [JsonProperty("self")]
        public Self Self { get; set; }

        /// <summary>
        /// Die REST URI für den E‑POSTBRIEF<br />
        /// Versand in Form des Domain Application Protocols:<br />
        /// Der Link wird nur zurückgegeben,
        /// wenn zusätzlich zum Scope
        /// create_letterder Scope
        /// send_letteroder send_hybrid
        /// angegeben wird.
        /// </summary>
        [JsonProperty("send")]
        public Send Send { get; set; }

        #endregion
    }
}