﻿namespace IEPostBusinessApi.JSON.Draft
{
    /// <summary>
    /// Art des Systemschreibens. Mögliche Werte:<br/>
    /// <dl>
    ///	    <dt>normal</dt>
    ///	    <dd>Elektronisch versendeter E‑POSTBRIEF</dd>
    ///	    <dt>hybrid</dt>
    ///	    <dd>physikalischer versendeter E‑POSTBRIEF</dd>
    ///	    <dt>confirmation of dispatch</dt>
    ///	    <dd>Versandbestätigung</dd>
    ///	    <dt>confirmation of receipt</dt>
    ///	    <dd>Zustellbestätigung</dd>
    ///	    <dt>user-acknowledge</dt>
    ///	    <dd>Positive Empfangsbestätigung</dd>
    ///	    <dt>user-reject</dt>
    ///	    <dd>Negative Empfangsbestätigung</dd>
    /// </dl>
    /// Wenn das Objekt nicht angegeben wird, wird normal als
    /// Standard festgelegt.
    /// </summary>
    public enum SystemMessageTypeEnum
    {
        // ReSharper disable InconsistentNaming
        // Hier werden die Enum entgegen der Namenskonventionen definiert, da sie genau so auch in der REST-API
        // verwendet werden können und so die Interoperabilität besser erhalten werden kann.

        /// <summary>Elektronisch versendeter E-POSTBRIEF</summary>
        normal, 

        /// <summary>phsikalisch versendeter E-POSTBRIEF</summary>
        hybrid, 

        /// <summary>Versandbestätigung</summary>
        confirmationOfDispatch, 

        /// <summary>Zustellbestätigung</summary>
        confirmationOfReceipt, 

        /// <summary>Positive Empfangsbestätigung</summary>
        userAcknowledge, 

        /// <summary>Negative Empfangsbestätigung</summary>
        userReject
    }
}