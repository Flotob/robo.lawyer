namespace IEPostBusinessApi.JSON.Draft
{
    using System.Collections.Generic;

    using Newtonsoft.Json;

    /// <summary>
    /// Die REST URI f�r die Berechnung des
    /// Preises f�r den Versand in Form des
    /// Domain Application Protocols:<br/>
    /// Der Link wird nur zur�ckgegeben,
    /// wenn zus�tzlich zum Scope
    /// create_letter der Scope
    /// send_letter oder send_hybrid
    /// angegeben wird.
    /// </summary>
    public class PostageInfo
    {
        #region Public Properties

        /// <summary>Liest oder setzt Headers.</summary>
        [JsonProperty("headers")]
        public List<Headers> Headers { get; set; }

        /// <summary>Liest oder setzt Href.</summary>
        [JsonProperty("href")]
        public string Href { get; set; }

        /// <summary>Liest oder setzt Method.</summary>
        [JsonProperty("method")]
        public string Method { get; set; }

        #endregion
    }
}