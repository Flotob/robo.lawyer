namespace IEPostBusinessApi.JSON.Draft
{
    using Newtonsoft.Json;

    /// <summary>
    /// Gibt Links an, unter denen Ressourcen erreichbar sind.
    /// </summary>
    public class LetterLinks
    {
        #region Public Properties

        /// <summary>
        /// Gibt die URI an, unter der das Letter-Objekt abrufbar ist.
        /// </summary>
        [JsonProperty("letter")]
        public Letter Letter { get; set; }

        #endregion
    }
}