namespace IEPostBusinessApi.JSON.Draft
{
    using Newtonsoft.Json;

    /// <summary>
    /// Absenderinformationen:br/>
    /// Die Absenderinformationen
    /// ergeben sich vom angemeldeten
    /// Benutzer und werden vom referenzierten Letter ausgelesen.
    /// </summary>
    public class Sender
    {
        #region Public Properties

        /// <summary>
        /// Vor- und Nachname des Absen-ders
        /// HINWEIS
        /// Es kann bei Bedarf auch ein
        /// beliebiger Name angegeben
        /// werden wenn der Anwen-dungsfall es erfordert (z. B.
        /// �Kundenservice�).
        /// </summary>
        [JsonProperty("displayName", NullValueHandling = NullValueHandling.Ignore)]
        public string DisplayName { get; set; }

        /// <summary>Liest oder setzt EpostAddress.</summary>
        [JsonProperty("epostAddress")]
        public string EpostAddress { get; set; }

        #endregion

        #region Public Methods and Operators

        /// <summary>
        /// Returns a <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.
        /// </returns>
        public override string ToString()
        {
            if (DisplayName != null)
            {
                return "\"" + DisplayName + "\" <" + EpostAddress + ">";
            }

            return EpostAddress;
        }

        #endregion
    }
}