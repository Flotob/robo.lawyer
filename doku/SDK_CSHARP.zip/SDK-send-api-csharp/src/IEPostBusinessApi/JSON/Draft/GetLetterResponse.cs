﻿namespace IEPostBusinessApi.JSON.Draft
{
    using System.Collections.Generic;

    using Newtonsoft.Json;

    /// <summary>
    /// Metadaten eines gespeicherten E‑POSTBRIEF Entwurfs:<br />
    /// Auf die nachfolgenden Metadaten greift Ihre Applikation zu, wenn diese auf den Entwurf eines E‑POSTBRIEFS
    /// referenzieren soll.
    /// </summary>
    public class GetLetterResponse
    {
        #region Public Properties

        /// <summary>
        /// Die Anhänge.
        /// </summary>
        [JsonProperty("attachments")]
        public List<Links> Attachments { get; set; }

        /// <summary>
        /// Das Anschreiben.
        /// </summary>
        [JsonProperty("coverLetterInfo")]
        public Coverletter Coverletter { get; set; }

        /// <summary>
        /// Der Briefumschlag.
        /// </summary>
        [JsonProperty("envelope")]
        public Envelope Envelope { get; set; }

        /// <summary>
        /// Objekt zur Anzeige aller LetterLinks des Entwurfs.
        /// </summary>
        [JsonProperty("_links")]
        public Links Links { get; set; }

        #endregion
    }
}