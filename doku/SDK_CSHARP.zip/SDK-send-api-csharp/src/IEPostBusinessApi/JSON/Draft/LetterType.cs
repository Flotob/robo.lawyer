﻿namespace IEPostBusinessApi.JSON.Draft
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Gibt an, ob der Brief geschäftlich
    /// oder privat ist.
    /// </summary>
    public class LetterType
    {
        #region Public Properties

        /// <summary>
        /// E‑POSTBRIEF mit Briefzusatzleistung (nur bei elektronischem E‑POSTBRIEF). Mögliche Werte:
        /// <ul>
        /// <li>Einschreiben Einwurf</li>
        /// <li>Einschreiben mit Empfangsbestätigung</li>
        /// </ul>
        /// </summary>
        [JsonProperty("additionalService")]
        public string AdditionalService { get; set; }

        /// <summary>Der Typ des Briefs.</summary>
        [JsonProperty("messageType")]
        [JsonConverter(typeof(StringEnumConverter))]
        public MessageTypeEnum MessageType { get; set; }

        /// <summary>
        /// Typ des Absenders. Mögliche
        /// Werte:<br/>
        /// <ul>
        /// <li>private: der Absender ist ein
        /// Privatkunde</li>
        /// <li>business: der Absender ist ein
        /// Geschäftskunde</li>
        /// <li>neutral: es handelt sich um
        /// eine Systemnachricht</li>
        /// </ul>
        /// </summary>
        [JsonProperty("senderType")]
        public string SenderType { get; set; }

        /// <summary>
        /// Art des Systemschreibens. Mögliche Werte:<br/>
        /// <dl>
        ///	    <dt>normal</dt>
        ///	    <dd>Elektronisch versendeter E‑POSTBRIEF</dd>
        ///	    <dt>hybrid</dt>
        ///	    <dd>physikalischer versendeter E‑POSTBRIEF</dd>
        ///     <dt>confirmation of dispatch</dt>
        ///     <dd>Versandbestätigung</dd>
        ///     <dt>confirmation of receipt</dt>
        ///     <dd>Zustellbestätigung</dd>
        ///     <dt>user-acknowledge</dt>
        ///     <dd>Positive Empfangsbestätigung</dd>
        ///     <dt>user-reject</dt>
        ///     <dd>Negative Empfangsbestätigung</dd>
        /// </dl>
        /// Wenn das Objekt nicht angegeben wird, wird <em>normal</em> als
        /// Standard festgelegt.
        /// </summary>
        [JsonProperty("systemMessageType")]
        [JsonConverter(typeof(StringEnumConverter))]
        public SystemMessageTypeEnum SystemMessageType { get; set; }

        #endregion
    }
}