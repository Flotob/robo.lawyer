﻿namespace IEPostBusinessApi.JSON.Draft
{
    using Newtonsoft.Json;

    /// <summary>
    /// URI zum erstellten E‑POSTBRIEF.
    /// </summary>
    public class Self
    {
        #region Public Properties

        /// <summary>
        /// URI zum erstellten E‑POSTBRIE
        /// </summary>
        [JsonProperty("href")]
        public string Href { get; set; }

        #endregion
    }
}