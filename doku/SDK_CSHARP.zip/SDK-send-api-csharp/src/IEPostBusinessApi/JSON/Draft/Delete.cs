namespace IEPostBusinessApi.JSON.Draft
{
    using Newtonsoft.Json;

    /// <summary>
    /// Die REST URI zum L�schen des Entwurfs in Form des Domain Application
    /// Protocols:<br/>
    /// Der Link wird nur zur�ckgegeben,
    /// wenn zus�tzlich zum Scope
    /// <em>create_letter</em> der Scope
    /// <em>delete_letter</em> angegeben wird.
    /// </summary>
    public class Delete
    {
        #region Public Properties

        /// <summary>Der Link auf den zu l�schenden Entwurf.</summary>
        [JsonProperty("href")]
        public string Href { get; set; }

        /// <summary>Die Methode zum L�schen muss immer DELETE lauten.</summary>
        [JsonProperty("method")]
        public string Method { get; set; }

        #endregion
    }
}