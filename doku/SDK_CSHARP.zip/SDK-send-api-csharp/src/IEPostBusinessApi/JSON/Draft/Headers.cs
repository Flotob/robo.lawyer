namespace IEPostBusinessApi.JSON.Draft
{
    using Newtonsoft.Json;

    /// <summary>Der Header.</summary>
    public class Headers
    {
        #region Public Properties

        /// <summary>Der Name des Header-Feldes.</summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>Der Wert des Header-Feldes.</summary>
        [JsonProperty("value")]
        public string Value { get; set; }

        #endregion
    }
}