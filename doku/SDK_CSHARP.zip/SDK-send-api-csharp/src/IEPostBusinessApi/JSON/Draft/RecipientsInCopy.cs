﻿namespace IEPostBusinessApi.JSON.Draft
{
    using Newtonsoft.Json;

    /// <summary>
    /// Liste der Empfänger einer Kopie
    /// (CC)
    /// </summary>
    public class RecipientsInCopy
    {
        #region Public Properties

        /// <summary>
        /// Vor- und Nachname des Empfängers einer Kopie.
        /// </summary>
        [JsonProperty("displayName")]
        public string DisplayName { get; set; }

        /// <summary>
        /// E‑POSTBRIEF Adresse des Empfängers einer Kopie.
        /// </summary>
        [JsonProperty("epostAddress")]
        public string EpostAddress { get; set; }

        #endregion

        #region Public Methods and Operators

        /// <summary>
        /// Returns a <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.
        /// </returns>
        public override string ToString()
        {
            if (DisplayName != null)
            {
                return "\"" + DisplayName + "\" <" + EpostAddress + ">";
            }

            return EpostAddress;
        }

        #endregion
    }
}