﻿namespace IEPostBusinessApi.JSON.Draft
{
    using Newtonsoft.Json;

    /// <summary>
    /// Metadaten für das Anlegen eines E‑POSTBRIEF Entwurfs:<br/>
    /// Die nachfolgenden Metadaten legt Ihre Applikation an, wenn diese einen Entwurf eines
    /// E‑POSTBRIEFS erstellen soll.
    /// </summary>
    public class CreateDraftRequest
    {
        #region Public Properties

        /// <summary>
        /// Objekt zum Anlegen der Entwurfsinformationen.
        /// </summary>
        [JsonProperty("envelope")]
        public Envelope Envelope { get; set; }

        #endregion
    }
}