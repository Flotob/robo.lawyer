﻿namespace IEPostBusinessApi.JSON.PrintOptions
{
    using Newtonsoft.Json;

    /// <summary>
    /// Die Metadaten für Versandoptionen geben Sie optional an, wenn Sie einen E‑POSTBRIEF Entwurf versenden.
    /// </summary>
    public class PrintOptionsRequest
    {
        #region Public Properties

        /// <summary>Liest oder setzt Letter.</summary>
        [JsonProperty("letter", NullValueHandling = NullValueHandling.Ignore)]
        public Letter Letter { get; set; }

        /// <summary>
        /// Angabe, dass Versandoptionen übergeben werden.
        /// </summary>
        [JsonProperty("options")]
        public Options Options { get; set; }

        #endregion

        #region Equals

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            PrintOptionsRequest that = obj as PrintOptionsRequest;
            if (that == null)
            {
                return false;
            }

            // exit if property Letter differs
            if ((this.Letter == null && that.Letter != null) ||
                (this.Letter != null && that.Letter == null))
            {
                return false;
            }

            if (this.Letter != null && !this.Letter.Equals(that.Letter))
            {
                return false;
            }

            // exit if property Options differs
            if ((this.Options == null && that.Options != null) ||
                (this.Options != null && that.Options == null))
            {
                return false;
            }

            if (this.Options != null && !this.Options.Equals(that.Options))
            {
                return false;
            }

            return true;
        }

        public override int GetHashCode()
        {
            int result = 0;
            if (Letter != null)
            {
                result += Letter.GetHashCode();
            }
            if (Options != null)
            {
                result += Options.GetHashCode();
            }
            return result;
        }

        #endregion
    }
}