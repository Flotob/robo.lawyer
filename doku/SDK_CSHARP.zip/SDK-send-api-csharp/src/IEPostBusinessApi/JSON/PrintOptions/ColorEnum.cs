﻿namespace IEPostBusinessApi.JSON.PrintOptions
{
    /// <summary>
    /// Die Option legt fest, ob ein Farb- oder Schwarz-Weiß-Druck ausgeführt wird.<br/>
    /// Die Option kann folgende Werte annehmen:
    /// <dl>
    /// 	<dt>grayscale</dt>
    ///	    <dd>Schwarz-Weiß</dd>
    /// 	<dt>colored</dt>
    ///	    <dd>Farbe</dd>
    /// </dl>
    /// Wenn die Option nicht spezifiziert wird, wird der Standardwert grayscale verwendet.
    /// </summary>
    public enum ColorEnum
    {
        // ReSharper disable InconsistentNaming
        // Hier werden die Enum entgegen der Namenskonventionen definiert, da sie genau so auch in der REST-API
        // verwendet werden können und so die Interoperabilität besser erhalten werden kann.

        /// <summary>Farbe</summary>
        colored,

        /// <summary>Schwarz-Weiß</summary>
        grayscale
    }
}