﻿namespace IEPostBusinessApi.JSON.PrintOptions
{
    /// <summary>
    /// Die Option legt fest, ob für den Versand ein Deckblatt generiert werden soll, oder dieses im mitgelieferten PDF-Anhang enthalten ist (erste Seite). Die Option kann folgende Werte annehmen:
    /// <dl>
    /// 	<dt>included</dt>
    /// 	<dd>Die erste Seite des des eingelieferten PDFs wird als Anschreiben verwendet</dd>
    /// 	<dt>generate</dt>
    /// 	<dd>Das Deckblatt wird automatisch generiert</dd>
    /// </dl>
    /// 
    /// Wenn die Option nicht spezifiziert wird, wird der Standardwert generate verwendet.
    /// </summary>
    public enum CoverLetterEnum
    {
        // ReSharper disable InconsistentNaming
        // Hier werden die Enum entgegen der Namenskonventionen definiert, da sie genau so auch in der REST-API
        // verwendet werden können und so die Interoperabilität besser erhalten werden kann.

        /// <summary>Die erste Seite des des eingelieferten PDFs wird als Anschreiben verwendet</summary>
        included,

        /// <summary>Das Deckblatt wird automatisch generiert</summary>
        generate
    }
}