﻿namespace IEPostBusinessApi.JSON.PrintOptions
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Angabe, dass Versandoptionen
    /// übergeben werden
    /// </summary>
    public class Options
    {
        #region Public Properties

        /// <summary>
        /// Die Option legt fest, ob ein Farb- oder Schwarz-Weiß-Druck ausgeführt wird.
        /// Die Option kann folgende Werte annehmen:
        /// <dl>
        /// 	<dt>grayscale</dt>
        ///	    <dd>Schwarz-Weiß</dd>
        /// 	<dt>colored</dt>
        ///	    <dd>Farbe</dd>
        /// </dl>
        /// Wenn die Option nicht spezifiziert wird, wird der Standardwert grayscale verwendet.
        /// </summary>
        [JsonProperty("color")]
        [JsonConverter(typeof(StringEnumConverter))]
        public ColorEnum Color { get; set; }

        /// <summary>
        /// Die Option legt fest, ob für den Versand ein Deckblatt generiert werden soll, oder dieses im mitgelieferten PDF-Anhang enthalten ist (erste Seite).
        /// Die Option kann folgende Werte annehmen:
        /// <dl>
        /// 	<dt>included</dt>
        /// 	<dd>Die erste Seite des des eingelieferten PDFs wird als Anschreiben verwendet</dd>
        /// 	<dt>generate</dt>
        /// 	<dd>Das Deckblatt wird automatisch generiert</dd>
        /// </dl>
        /// 
        /// Wenn die Option nicht spezifiziert wird, wird der Standardwert generate verwendet.
        /// </summary>
        [JsonProperty("coverLetter")]
        [JsonConverter(typeof(StringEnumConverter))]
        public CoverLetterEnum CoverLetter { get; set; }

        /// <summary>
        /// Die Option gibt an, ob der E-POSTBRIEF als Einschreiben versendet wird, und wenn ja, welcher Einschreiben-Typ gewählt ist.<br/>
        /// Die Option kann folgende Werte annehmen:
        /// <dl>
        /// 	<dt>standard</dt>
        /// 	<dd>Einschreiben</dd>
        /// 	<dt>submissionOnly</dt>
        /// 	<dd>Einschreiben Einwurf</dd>
        /// 	<dt>addresseeOnly</dt>
        /// 	<dd>Einschreiben eigenhändig</dd>
        /// 	<dt>withReturnReceipt</dt>
        /// 	<dd>Einschreiben Rückschein</dd>
        /// 	<dt>addresseeOnlyWithReturnReceipt</dt>
        /// 	<dd>Einschreiben eigenhändig Rückschein</dd>
        /// 	<dt>no</dt>
        /// 	<dd>Standardbrief</dd>
        /// 
        /// </dl>
        /// Wenn die Option nicht spezifiziert wird, wird der Standardwert no verwendet.
        /// </summary>
        [JsonProperty("registered")]
        [JsonConverter(typeof(StringEnumConverter))]
        public RegisteredEnum Registered { get; set; }

        /// <summary>
        /// Die Option gibt an, ob eine Adressanreicherung durchgeführt werden soll. Mögliche Werte sind true oder false.<br/>
        /// Die Funktion prüft, ob der postalisch adressierte Empfänger eine E‐POSTBRIEF Adresse besitzt. Dies erfolgt durch die Übergabe der postalischen Empfänger-Metadaten. Die Funktion reichert nur Adressen der Privatkunden im öffentlichen E‐POSTBRIEF Adressverzeichnis an.<br/>
        /// Sollte vom Empfänger eine E‐POSTBRIEF Adresse gefunden werden, wird der E‐POSTBRIEF auf elektronischem Weg an diese Adresse versendet.
        /// </summary>

        [JsonProperty("tryElectronic", NullValueHandling = NullValueHandling.Ignore)]
        public bool? TryElectronic { get; set; }
        
        /// <summary>
        /// Gibt an, ob der neue E42 PrintService verwendet werden soll.
        /// </summary>
        [JsonProperty("usePrs", NullValueHandling = NullValueHandling.Ignore)]
        public bool? UsePrs { get; set; }

        #endregion

        #region Equals

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Options that = obj as Options;
            if (that == null)
            {
                return false;
            }

            return (this.Color.Equals(that.Color) &&
                this.CoverLetter.Equals(that.CoverLetter) &&
                this.Registered.Equals(that.Registered) &&
                EqualsNullableBooleans(this.TryElectronic, that.TryElectronic) &&
                EqualsNullableBooleans(this.UsePrs, that.UsePrs));
        }

        private static bool EqualsNullableBooleans(bool? boolean1, bool? boolean2)
        {
            if (boolean1 == null && boolean2 == null)
            {
                return true;
            }

            if ((boolean1 != null && boolean2 == null) ||
                (boolean1 == null && boolean2 != null))
            {
                return false;
            }

            return boolean1 == boolean2;
        }

        public override int GetHashCode()
        {
            return Color.GetHashCode() +
                   CoverLetter.GetHashCode() +
                   Registered.GetHashCode() +
                   GetHashCodeNullableBoolean(TryElectronic) +
                   GetHashCodeNullableBoolean(UsePrs);
        }

        private static int GetHashCodeNullableBoolean(bool? boolean1)
        {
            return boolean1 == null ? 0 : boolean1.GetHashCode();
        }

        #endregion
    }
}