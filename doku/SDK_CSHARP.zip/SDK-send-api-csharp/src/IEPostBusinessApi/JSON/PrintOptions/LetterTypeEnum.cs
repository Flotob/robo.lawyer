﻿namespace IEPostBusinessApi.JSON.PrintOptions
{
    /// <summary>
    /// Der Typ des E-POSTBRIEFS:
    /// <dl>
    ///     <dt>normal</dt>
    ///     <dd>Elektronisch versendeter E-POSTBRIEF</dd>
    ///     <dt>hybrid</dt>
    ///     <dd>Physisch versendeter E-POSTBRIEF</dd>
    /// </dl>
    /// </summary>
    public enum LetterTypeEnum
    {
        // ReSharper disable InconsistentNaming
        // Hier werden die Enum entgegen der Namenskonventionen definiert, da sie genau so auch in der REST-API
        // verwendet werden können und so die Interoperabilität besser erhalten werden kann.

        /// <summary>Physisch versendeter E-POSTBRIEF</summary>
        hybrid,

        /// <summary>Elektronisch versendeter E-POSTBRIEF</summary>
        normal
    }
}