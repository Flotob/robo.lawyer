﻿namespace IEPostBusinessApi.JSON.PrintOptions
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>Informationen zum E-POSTBRIEF</summary>
    public class Letter
    {
        #region Public Properties

        /// <summary>
        /// LetterTypeEnum.hybrid: Anzahl der Seiten
        /// LetterTypeEnum.normal: Größe des Dokuments in MByte
        /// </summary>
        [JsonProperty("size")]
        public int Size { get; set; }

        /// <summary>
        /// Der Typ des E-POSTBRIEFs:
        /// - normal: elektronisch
        /// - hybrid: physisch
        /// </summary>
        [JsonProperty("type")]
        [JsonConverter(typeof(StringEnumConverter))]
        public LetterTypeEnum Type { get; set; }

        #endregion

        #region Equals

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Letter that = obj as Letter;
            if (that == null)
            {
                return false;
            }

            return (this.Size.Equals(that.Size) && this.Type.Equals(that.Type));
        }

        public override int GetHashCode()
        {
            return Size.GetHashCode() + Type.GetHashCode();
        }

        #endregion
    }
}