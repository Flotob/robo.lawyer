namespace IEPostBusinessApi.JSON.PrintOptions
{
    /// <summary>
    /// Die Option gibt an, ob der E-POSTBRIEF als Einschreiben versendet wird, und wenn ja, welcher Einschreiben-Typ gew�hlt ist.<br/>
    /// Die Option kann folgende Werte annehmen:
    /// <dl>
    /// 	<dt>no</dt>
    /// 	<dd>kein Einschreiben</dd>
    /// 	<dt>standard</dt>
    /// 	<dd>Einschreiben</dd>
    /// 	<dt>submissionOnly</dt>
    /// 	<dd>Einschreiben Einwurf</dd>
    /// 	<dt>addresseeOnly</dt>
    /// 	<dd>Einschreiben eigenh�ndig</dd>
    /// 	<dt>withReturnReceipt</dt>
    /// 	<dd>Einschreiben R�ckschein</dd>
    /// 	<dt>addresseeOnlyWithReturnReceipt</dt>
    /// 	<dd>Einschreiben eigenh�ndig R�ckschein</dd>
    /// 	<dt>Wir kein Wert angebgen</dt>
    /// 	<dd>Standardbrief, kein Einschreiben</dd>
    /// 
    /// </dl>
    /// Wenn die Option nicht spezifiziert wird, wird der Standardwert no verwendet.
    /// </summary>
    public enum RegisteredEnum
    {
        // ReSharper disable InconsistentNaming
        // Hier werden die Enum entgegen der Namenskonventionen definiert, da sie genau so auch in der REST-API
        // verwendet werden k�nnen und so die Interoperabilit�t besser erhalten werden kann.

        /// <summary>Standardbrief</summary>
        no,

        /// <summary>Einschreiben</summary>
        standard,

        /// <summary>Einschreiben Einwurf</summary>
        submissionOnly,

        /// <summary>Einschreiben eigenh�ndig</summary>
        addresseeOnly,

        /// <summary>Einschreiben R�ckschein</summary>
        withReturnReceipt,

        /// <summary>Einschreiben eigenh�ndig R�ckschein</summary>
        addresseeOnlyWithReturnReceipt
    }
}