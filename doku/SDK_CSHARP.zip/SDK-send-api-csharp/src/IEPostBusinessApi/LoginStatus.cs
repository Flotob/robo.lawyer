﻿namespace IEPostBusinessApi
{
    /// <summary>
    /// Gibt den Login-Status an.
    /// </summary>
    public enum LoginStatus
    {
        /// <summary>
        /// Der Nutzer war zu noch keinem Zeitpunkt innerhalb dieser Session eingeloggt.
        /// </summary>
        NotLoggedIn, 

        /// <summary>
        /// Der Nutzer ist mit hohem Authentifizierungs-Niveau eingeloggt.
        /// </summary>
        LoggedInHigh,

        /// <summary>
        /// Der Nutzer ist mit normalem Authentifizierungs-Niveau eingeloggt. 
        /// </summary>
        LoggedInLow,

        /// <summary>
        /// Der Nutzer hat sich ausgeloggt.
        /// </summary>
        LoggedOut, 

        /// <summary>
        /// Der Nutzer ist nicht eingeloggt, ein Refresh führt aber ins hohe Authentifizierungs-Niveau.
        /// </summary>
        RefreshableHigh,

        /// <summary>
        /// Der Nutzer ist nicht eingeloggt, ein Refresh führt aber ins normale Authentifizierungs-Niveau.
        /// </summary>
        RefreshableLow
    }
}