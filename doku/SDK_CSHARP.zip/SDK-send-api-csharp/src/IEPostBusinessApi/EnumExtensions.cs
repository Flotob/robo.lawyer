﻿using System.Reflection;

namespace IEPostBusinessApi
{
    using System;
    using System.Linq;
    using System.Resources;
    using System.Windows.Forms;

    using IEPostBusinessApi.Properties;

    /// <summary>
    /// Diese statische Klasse erweitert Enumerations um die Möglichkeit, lokalisiert an Controls gebunden zu werden und einen
    /// lokalisierten Namen über Ressourcen zu erhalten.
    /// Dabei müssen die Resourcen wie folgt deklariert werden:
    /// <ul>
    ///     <li>EnumResources.xx-XX.resx wobei xx-XX für die Lokalisierung steht.</li>
    ///     <li>Die Ressource muss dann wie folgt definiert werden: Typname_enumName</li>
    /// </ul>
    /// </summary>
    public static class EnumExtensions
    {
        #region Public Properties

        /// <summary>Liest DisplayMember.</summary>
        public static string DisplayMember
        {
            get
            {
                return "Value";
            }
        }

        /// <summary>Liest ValueMember.</summary>
        public static string ValueMember
        {
            get
            {
                return "Key";
            }
        }

        #endregion

        #region Public Methods and Operators

        /// <summary>TODO The get binding source.</summary>
        /// <param name="enumType">TODO The enum type.</param>
        /// <returns>The <see cref="BindingSource"/>.</returns>
        public static BindingSource GetBindingSource(Type enumType)
        {
            var bindingSource = new BindingSource();
            var enumValues = enumType.GetEnumValues();
            var data = enumValues.OfType<Enum>()
                .ToDictionary(enumValue => enumValue, enumValue => enumValue.GetLocalizedName());

            bindingSource.DataSource = data;

            return bindingSource;
        }

        /// <summary>Liefert den lokalisierten Namen der Enum soweit er in der Resource-Datei angegeben ist.</summary>
        /// <param name="e">Die Enum.</param>
        /// <returns>Der lokalisierte <see cref="string"/>.</returns>
        public static string GetLocalizedName(this Enum e)
        {
            // This method may be used from several projects. The appropriate resource is located in the assembly and
            // namespace of the enum for which this extension is called.
            // The first idea to get the correct resource manager would be to use Type.getType() - but this doesn't
            // work in some scenarios. Be very careful when changing here: At least test the Business Mailer and
            // the export utility!
            string resourceName = e.GetType().FullName.Split('.')[0] + ".Properties.EnumResources";
            var rm = new ResourceManager(e.GetType().Assembly.GetType(resourceName));
            var resourceDisplayName = rm.GetString(e.GetType().Name + "_" + e);

            return string.IsNullOrWhiteSpace(resourceDisplayName)
                       ? GetUnknownName(e.ToString("f"))
                       : resourceDisplayName;
        }

        #endregion

        #region Methods

        /// <summary>Liefert den Namen einer Enum, falls sie unbekannt ist.</summary>
        /// <param name="name">Der Name der unbekannten Enum.</param>
        /// <returns>Der Name als <see cref="string"/>.</returns>
        internal static string GetUnknownName(string name)
        {
            return string.Format("[[{0}]]", name);
        }

        #endregion
    }
}