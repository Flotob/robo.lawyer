namespace IEPostBusinessApi
{
    /// <summary>
    /// Legt fest, welchen Code-Typ der Client f�r den Token-Tausch anbietet.
    /// </summary>
    public enum GrantType
    {
        // 6749 spezifiziert (siehe http://tools.ietf.org/html/rfc6749#secti-on-4.3.2).

        // ReSharper disable InconsistentNaming
        // Hier werden die Enum entgegen der Namenskonventionen definiert, da sie genau so auch in der REST-API
        // verwendet werden k�nnen und so die Interoperabilit�t besser erhalten werden kann.

        /// <summary>
        /// Es muss ein fester Wert <em>password</em> gesetzt werden, wie in RFC 6749 spezifiziert (siehe http://tools.ietf.org/html/rfc6749#secti-on-4.3.2)
        /// </summary>
        password, 

        /// <summary>
        /// F�r die Authentisierung mit Authorization Code wird als
        /// Typ-Angabe nur <em>authorization_code</em> unterst�tzt.
        /// </summary>
        authorization_code
    }
}