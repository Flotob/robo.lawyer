﻿namespace IEPostBusinessApi.EPostException
{
    /// <summary>Der EPostBusinessApiExceptionType identifiziert den in der REST-Schnittstelle aufgetretenen Fehler.</summary>
    public enum EPostBusinessApiExceptionType
    {
        // ReSharper disable InconsistentNaming

        /// <summary>
        /// Abbruch
        /// </summary>
        EPostSession302 = 1100,

        /// <summary>
        /// Fehlende oder fehlerhafte Parameter oder Referer
        /// </summary>
        EPostSession302invalid_request,

        /// <summary>
        /// Response Type entspricht nicht dem code
        /// </summary>
        EPostSession302unsupported_response_type,

        /// <summary>
        /// Falsches Listenformat oder die Liste enthält einen oder mehrere unbekannte(n)
        /// oder ungültige(n) Scope(s)
        /// </summary>
        EPostSession302access_denied,

        /// <summary>
        /// Zugang verweigert
        /// </summary>
        EPostSession302access_deniedTheresourceownerorauthorizationserverdeniedtherequest,

        /// <summary>
        /// Unerwarteter serverseitiger Fehler
        /// </summary>
        EPostSession302server_error,

        /// <summary>
        /// Temporärer serverseitiger Fehler
        /// </summary>
        EPostSession302temporarily_unavailable,

        /// <summary>
        /// Der Server kann die Anfrage momentan nicht bearbeiten, da er beschäftigt oder nicht verfügbar ist.
        /// </summary>
        EPostSession302temporarily_unavailableTheauthorizationserveriscurrentlyunabletohandletherequestduetoatemporaryoverloadingormaintenanceoftheserverThiserrorcodeisneededbecausea503ServiceUnavailableHTTPstatuscodecannotbereturnedtotheclientviaanHTTPredirect,

        /// <summary>
        /// Das übergebene Access Token fehlt oder ist im falschen Format.
        /// </summary>
        EPostSession400 = 1200,

        /// <summary>
        /// Parameter-Fehler
        /// </summary>
        EPostSession400invalid_request,

        /// <summary>
        /// grant_type ist ungleich authorization_code
        /// </summary>
        EPostSession400unsupported_grant_type,

        /// <summary>
        /// ungültiger authorization_code
        /// </summary>
        EPostSession400invalid_grant,

        /// <summary>
        /// Ungültiger authorization_code
        /// </summary>
        EPostSession400invalid_grantTheprovidedauthorizationgrantegauthorizationcoderesourceownercredentialsorrefreshtokenisinvalidexpiredrevokeddoesnotmatchtheredirectionURIusedintheauthorizationrequestorwasissuedtoanotherclient,

        /// <summary>
        /// Der grant_type ist für den authentifizierten Client nicht erlaubt
        /// </summary>
        EPostSession400unauthorized_client,

        /// <summary>
        /// Verwendung eines falschen Listenformats oder die angegebene Liste
        /// enthält einen oder mehrere unbekannte(n) oder ungültige(n) Scope(s) bzw. die
        /// übergebene Liste gleicht nicht der Liste, die bei der Beantragung des
        /// verwendeten Autorisierungscodes verwendet wurde.
        /// </summary>
        EPostSession400invalid_scope,

        /// <summary>
        /// Credentials fehlen, Client-ID ist ungültig oder Credentials sind nicht
        /// valide
        /// </summary>
        EPostSession401invalid_client,

        /// <summary>
        /// Der Content-Type der Anfrage wird nicht unterstützt.
        /// </summary>
        EPostSession415unsupported_media_type,

        /// <summary>The e post session 404.</summary>
        EPostSession404,

        /// <summary>The e post session 405.</summary>
        EPostSession405,

        /// <summary>The e post session 413.</summary>
        EPostSession413,

        /// <summary>The e post session 415.</summary>
        EPostSession415,

        /// <summary>The e post session 500.</summary>
        EPostSession500 = 1300,

        /// <summary>The e post session 503.</summary>
        EPostSession503,

        /// <summary>The e post session 503 could_not_get_result.</summary>
        EPostSession503could_not_get_result,

        /// <summary>The e post session 504 could_not_get_result.</summary>
        EPostSession504,

        /// <summary>The e post session 504 could_not_get_result.</summary>
        EPostSession504could_not_get_result,

        /// <summary>The e post session 502 could_not_get_result.</summary>
        EPostSession502could_not_get_result,

        /// <summary>The e post session 999 could_not_get_result.</summary>
        EPostSession999could_not_get_result = 1390,

        /// <summary>The e post session 0 could_not_get_result.</summary>
        EPostSession0could_not_get_result,

        /// <summary>Die JSON-Fehlermeldung konnte nicht geparst werden. Mögliche Fehler: Server-Fehler oder fehlende Internetverbindung.</summary>
        EPostSessionUnexpectedcharacterencountered,

        /// <summary>
        /// Die Verarbeitung ist nicht möglich. Mögliche Fehlerursachen:
        /// <ul>
        ///     <li>nicht zulässiges PDF,</li>
        ///     <li>PDF mit zu vielen Seiten,</li>
        ///     <li>PDF nicht druckbar (Formatierungsfehler),</li>
        ///     <li>ungültige Adresse.</li>
        /// </ul>
        /// In der E‐POSTBUSINESS API Versand-API Referenz finden Sie
        /// ausführliche Informationen zu möglichen Fehlern bei der Einlieferung
        /// von PDF-Dateien.
        /// </summary>
        Send400invalid_letter = 1400,

        /// <summary>
        /// Der angegebene Empfänger ist nicht korrekt oder unbekannt.
        /// </summary>
        Send400invalid_recipient,

        /// <summary>
        /// Die Anzahl der gelieferten PDF-Dokumente darf nicht größer als 99
        /// sein.
        /// </summary>
        Send400too_many_attachments,

        /// <summary>
        /// Die Metadaten des Briefes fehlen.
        /// </summary>
        Send400json_body_part_missing,

        /// <summary>
        /// Der Brief fehlt, d. h. es wurde kein PDF-Dokument geliefert.
        /// </summary>
        Send400pdf_body_part_missing,

        /// <summary>
        /// Für die verschiedenen Teile des Briefes dürfen nur die folgenden Typen
        /// verwendet werden:
        /// <ul>
        ///     <li>application/vnd.epost-send-api+json</li>
        ///     <li>application/pdf</li>
        /// </ul>
        /// </summary>
        Send400invalid_media_type,

        /// <summary>
        /// Die Metadaten des Briefes sind ungültig. Mögliche Fehlerursachen
        /// können sein:
        /// <ol>
        ///     <li>Die Eigenschaften printed und electronic dürfen nicht zusammen verwendet werden.</li>
        ///     <li>Eine der beiden Eigenschaften printed oder electronic muss angegeben werden.</li>
        ///     <li>Die Liste der Adressaten fehlt.</li>
        ///     <li>Die Adressaten wurden nicht in Form einer Liste übermittelt.</li>
        ///     <li>Die Liste der Adressaten enthält mehr als einen Eintrag.</li>
        ///     <li>Der Wert der Farbdruckoption ist unzulässig.</li>
        ///     <li>Im Adressatenfeld printed.to wurde gleichzeitig Straßenname und Postfach angegeben.</li>
        ///     <li>Im Falle des elektronischen Versands muss ein Adressat eine Eigenschaft <q>epbAddress</q> enthalten.</li>
        ///     <li>Im Falle des elektronischen Versands muss die E‑POSTBRIEF Adresse eines Adressaten eine gültige Domain enthalten.</li>
        /// </ol>
        /// </summary>
        Send400invalid_meta_data,

        /// <summary>
        /// Das Access Token ist abgelaufen oder ungültig.
        /// </summary>
        Send401invalid_tokenTheaccesstokenisinvalidorhasbeenexpired,

        /// <summary>
        /// Der Vorgang kann nicht abgebucht werden, da das jeweilige Kundenkonto
        /// entweder gesperrt ist oder kein ausreichendes Guthaben aufweist.
        /// </summary>
        Send403not_billable,

        /// <summary>
        /// Das Access Token hat nicht die benötigten Privilegien.
        /// </summary>
        Send403insufficient_scope,

        /// <summary>
        /// Der Brief enthält Schadsoftware.
        /// </summary>
        Send403malware_detected,

        /// <summary>
        /// Unter der angegebenen URL konnte keine Ressource gefunden werden.
        /// </summary>
        Send404,

        /// <summary>
        /// Die HTTP-Methode ist nicht unterstützt.
        /// </summary>
        Send405,

        /// <summary>
        /// Ein Accept-Header fehlt oder wurde angegeben und hatte einen anderen
        /// Wert als <q>application/json</q>.
        /// </summary>
        Send406,

        /// <summary>
        /// Die HTTP-Anfrage ist größer als 25 MB bzw. der aus den verschiedenen
        /// Teilen generierte Brief ist größer als 20 MB.
        /// </summary>
        Send413,

        /// <summary>
        /// Der übergebene Content-Type ist nicht vom Typ multipart/mixed.
        /// </summary>
        Send415,

        /// <summary>
        /// Interner Verarbeitungsfehler.
        /// </summary>
        Send500 = 1500,

        /// <summary>The send 503.</summary>
        Send503,

        /// <summary>The send 503 could_not_get_result.</summary>
        Send503could_not_get_result,

        /// <summary>The send 999 could_not_get_result.</summary>
        Send999could_not_get_result = 1590,

        /// <summary>The send 999 access_token_null.</summary>
        Send999access_token_null,

        /// <summary>The send 999 json_null.</summary>
        Send999json_null,

        /// <summary>Die JSON-Fehlermeldung konnte nicht geparst werden. Mögliche Fehler: Server-Fehler oder fehlende Internetverbindung.</summary>
        SendUnexpectedcharacterencountered,

        /// <summary>The e send session 0 could_not_get_result.</summary>
        Send0could_not_get_result,

        /// <summary>
        /// Die Anfrage ist fehlerhaft aufgebaut. Dies kann folgende Gründe haben:
        /// <ul>
        ///     <li>keine multipart/mixed; boundary Anfrage</li>
        ///     <li>fehlende oder ungültige Metadaten</li>
        ///     <li>kein file-Body-Part enthalten</li>
        ///     <li>ein Teil der Anfrage hat einen unzulässigen Content-Type</li>
        ///     <li>zu viele Anhänge (>99)</li>
        ///     <li>Das Format des Anschreibens ist ungültig (invalides HTML)</li>
        /// </ul>
        /// </summary>
        Draft400 = 1600,

        /// <summary>
        /// Unauthorized
        /// </summary>
        Draft401,

        /// <summary>
        /// Z.B. nach Logout.
        /// </summary>
        Draft401internal,

        /// <summary>
        /// Die Gesamtgröße der Anhänge für einen E‑POSTBRIEF ist überschritten.
        /// </summary>
        Draft403CORE_035,

        /// <summary>
        /// Die Gesamtzahl der Anhänge für einen E‑POSTBRIEF ist überschritten.
        /// </summary>
        Draft403CORE_038,

        /// <summary>
        /// Es wurde Schad-Software gefunden.
        /// </summary>
        Draft400READ_001,

        /// <summary>
        /// Unter der angegebenen URL konnte keine Ressource gefunden werden.
        /// </summary>
        Draft404,

        /// <summary>
        /// Die HTTP-Methode ist nicht unterstützt.
        /// </summary>
        Draft405,

        /// <summary>
        /// Ein Accept-Header fehlt oder wurde angegeben und hatte einen anderen
        /// Wert als application/json.
        /// </summary>
        Draft406,

        /// <summary>
        /// Die HTTP-Anfrage ist größer als 25 MB bzw. der aus den verschiedenen
        /// Teilen generierte Brief ist größer als 20 MB.
        /// </summary>
        Draft413,

        /// <summary>
        /// Der übergebene Content-Type ist nicht vom Typ multipart/mixed.
        /// </summary>
        Draft415,

        /// <summary>
        /// Draft401Ticketisnotvalid.
        /// </summary>
        Draft401Ticketisnotvalid,

        /// <summary>
        /// Interner Verarbeitungsfehler.
        /// </summary>
        Draft500 = 1700,

        /// <summary>The draft 503.</summary>
        Draft503,

        /// <summary>The draft 503 could_not_get_result.</summary>
        Draft503could_not_get_result,

        /// <summary>
        /// Interner Fehler auf dem Server
        /// </summary>
        Draft500internal,

        /// <summary>The draft 502 could_not_get_result.</summary>
        Draft502could_not_get_result,

        /// <summary>The draft 504 could_not_get_result.</summary>
        Draft504could_not_get_result,

        /// <summary>
        /// AccessToken ist null
        /// </summary>
        Draft999could_not_get_result = 1790,

        /// <summary>The draft 999 access_token_null.</summary>
        Draft999access_token_null,

        /// <summary>The draft 999 create_draft_request_null.</summary>
        Draft999create_draft_request_null,

        /// <summary>Die JSON-Fehlermeldung konnte nicht geparst werden. Mögliche Fehler: Server-Fehler oder fehlende Internetverbindung.</summary>
        DraftUnexpectedcharacterencountered,

        /// <summary>The draft 0 could_not_get_result.</summary>
        Draft0could_not_get_result,

        /// <summary>
        /// Das Access Token ist abgelaufen oder ungültig.
        /// </summary>
        SendDraft401invalid_tokenTheaccesstokenisinvalidorhasbeenexpired = 1800,

        /// <summary>
        /// Der Vorgang kann nicht abgebucht werden, da das jeweilige Kundenkonto
        /// entweder gesperrt ist oder kein ausreichendes Guthaben aufweist.
        /// </summary>
        SendDraft403not_billable,

        /// <summary>
        /// Der Vorgang kann nicht abgebucht werden, da das jeweilige Kundenkonto
        /// entweder gesperrt ist oder kein ausreichendes Guthaben aufweist.
        /// </summary>
        SendDraft403not_billableDebtorhasinsufficientfunds,

        /// <summary>
        /// Das Access Token hat nicht die benötigten Privilegien.
        /// </summary>
        SendDraft403insufficient_scopeTheaccesstokenlackstherequiredprivileges,

        /// <summary>
        /// Der Brief enthält Schadsoftware.
        /// </summary>
        SendDraft403malware_detected,

        /// <summary>
        /// Unter der angegebenen URL konnte keine Ressource gefunden werden.
        /// </summary>
        SendDraft404,

        /// <summary>
        /// Die HTTP-Methode ist nicht unterstützt.
        /// </summary>
        SendDraft405,

        /// <summary>
        /// Ein Accept-Header fehlt oder wurde angegeben und hatte einen anderen
        /// Wert als application/json.
        /// </summary>
        SendDraft406,

        /// <summary>
        /// Beim referenzierten E‑POSTBRIEF handelt es sich nicht um einen
        /// Entwurf.
        /// </summary>
        SendDraft409not_draft,

        /// <summary>
        /// Der im referenzierten Brief angegebene Empfänger ist nicht korrekt
        /// oder unbekannt.
        /// </summary>
        SendDraft409invalid_recipient,

        /// <summary>
        /// Die Anzahl der im referenzierten Brief enthaltenen Anhänge ist größer
        /// als 99.
        /// </summary>
        SendDraft409too_many_attachments,

        /// <summary>
        /// Der referenzierte Brief enthält Anhänge mit nicht unterstützem Typ.
        /// Unterstützt werden:
        /// <ul>
        ///     <li>application/pdf</li>
        ///     <li>image/jpeg</li>
        /// </ul>
        /// </summary>
        SendDraft409invalid_media_type,

        /// <summary>
        /// Der referenzierte Brief (inkl. Anhang) ist größer als 20 MB.
        /// </summary>
        SendDraft409letter_size_limit_exceeded,

        /// <summary>
        /// Die Metadaten des Briefes sind ungültig. Mögliche Fehlerursachen
        /// sind u.a.:
        /// <ul>
        ///     <li>Ein Adressat muss entweder Straßenname oder Postfach enthalten</li>
        ///     <li>Ein Adressat darf nicht gleichzeitig Straßenname und Postfach enthalten</li>
        ///     <li>Der Betreff ist ungültig (z. B. wenn er zu lang ist; bei UTF-8-Kodierung sind maximal 1.000 Zeichen erlaubt)</li>
        /// </ul>
        /// </summary>
        SendDraft409invalid_meta_data,

        /// <summary>
        /// Es darf nicht gleichzeitg Straße und Postfach angegeben werden.
        /// </summary>
        SendDraft409invalid_meta_dataAddressmustnotcontainbothpostOfficeBoxandstreetName,

        /// <summary>
        /// Es muss entweder eine Straße oder ein Postfach angeben werden.
        /// </summary>
        SendDraft409invalid_meta_dataAddressmustcontaineitherpostOfficeBoxorstreetName,

        /// <summary>
        /// Die E-POSTBRIEF Adresse ist ungültig.
        /// </summary>
        SendDraft409invalid_meta_dataAddressmustcontainvalidbasedomain,

        /// <summary>
        /// Unbekannter Empfänger
        /// </summary>
        SendDraft409invalid_recipientUnknownaddressee,

        /// <summary>
        /// Die Postleitzahl muss genau 5 Ziffern besitzen
        /// </summary>
        SendDraft409invalid_meta_dataZipcodemustconsistofexactlyfivedigits,

        /// <summary>
        /// Fehler beim Versand eines langen Briefes (Auftreten unwahrscheinlich)
        /// </summary>
        SendDraft409invalid_media_typeTherequestmediatypemustbemultipartmixedmetadatamediatypemustbeapplicationvndepostsendapijsonpdfpartmediatypemustbeapplicationpdfandjpgpartmediatypemustbeimagejpegSeehttptoolsietforghtmlrfc2616forvalidcontenttypesandparameters,

        /// <summary>
        /// SendDraft401Ticketisnotvalid.
        /// </summary>
        SendDraft401Ticketisnotvalid,

        /// <summary>
        /// Interner Verarbeitungsfehler
        /// </summary>
        SendDraft500 = 1900,

        /// <summary>The send draft 500 could_not_get_result.</summary>
        SendDraft500could_not_get_result,

        /// <summary>The send draft 503.</summary>
        SendDraft503,

        /// <summary>The send draft 503 could_not_get_result.</summary>
        SendDraft503could_not_get_result,

        /// <summary>
        /// Interner Server-Fehler
        /// </summary>
        SendDraft500internal,

        /// <summary>The send draft 502 could_not_get_result.</summary>
        SendDraft502could_not_get_result,

        /// <summary>The send draft 504 could_not_get_result.</summary>
        SendDraft504could_not_get_result,

        /// <summary>The send draft 999 could_not_get_result.</summary>
        SendDraft999could_not_get_result = 1990,

        /// <summary>
        /// Das AccessToken ist null
        /// </summary>
        SendDraft999access_token_null,

        /// <summary>Die JSON-Fehlermeldung konnte nicht geparst werden. Mögliche Fehler: Server-Fehler oder fehlende Internetverbindung.</summary>
        SendDraftUnexpectedcharacterencountered,

        /// <summary>The SendDraft 0 could_not_get_result.</summary>
        SendDraft0could_not_get_result,

        /// <summary>
        /// Fehler bei der Abfrage der Ressource Postage-Info.
        /// </summary>
        PostageInfo400 = 2000,

        /// <summary>
        /// Die Anzahl der angegebenen Seiten ist zu hoch.
        /// </summary>
        PostageInfo400invalid_letterPagecountisnotsupported,

        /// <summary>
        /// Es wurden keine korrekten Autorisierungs-Informationen übermittelt.
        /// </summary>
        PostageInfo401,

        /// <summary>
        /// Das Access Token ist abgelaufen oder ungültig.
        /// </summary>
        PostageInfo401invalid_tokenTheaccesstokenisinvalidorhasbeenexpired,

        /// <summary>
        /// Es besteht keine Berechtigung, um auf die Ressource zuzugreifen.
        /// </summary>
        PostageInfo403,

        /// <summary>
        /// Das Access Token hat nicht die benötigten Privilegien.
        /// </summary>
        PostageInfo403insufficient_scopeTheaccesstokenlackstherequiredprivileges,

        /// <summary>
        /// Unter der angegebenen URI im Content-Source-Header konnte keine
        /// Ressource gefunden werden.
        /// </summary>
        PostageInfo404,

        /// <summary>
        /// Die HTTP-Methode ist nicht unterstützt.
        /// </summary>
        PostageInfo405,

        /// <summary>
        /// Ein Accept-Header fehlt oder wurde angegeben und hatte einen anderen
        /// Wert als application/json.
        /// </summary>
        PostageInfo406,

        /// <summary>
        /// Die Anfrage wurde unter einer falschen Annahme gestellt.
        /// </summary>
        PostageInfo409,

        /// <summary>
        /// Der referenzierte Brief kann nicht verarbeitet werden. Mögliche Fehlerursachen
        /// sind:
        /// <ul>
        ///     <li>zu viele Seiten</li>
        ///     <li>nicht zulässiges Anschreiben (nicht unterstützte HTML-Tags)</li>
        ///     <li>Anschreiben nicht druckbar (Formatierungs- oder Konvertierungsfehler)</li>
        ///     <li>unzulässiger Anhang (keine PDF-Datei)</li>
        ///     <li>Anhang nicht druckbar (Formatierungs- oder Konvertierungsfehler)</li>
        /// </ul>
        /// </summary>
        PostageInfo409invalid_letter,

        /// <summary>
        /// Bei dem referenzierten Brief handelt es sich nicht um einen Entwurf.
        /// </summary>
        PostageInfo409not_draft,

        /// <summary>
        /// Fehler beim Versand eines langen Briefes (Auftreten unwahrscheinlich)
        /// </summary>
        PostageInfo409invalid_media_typeTherequestmediatypemustbemultipartmixedmetadatamediatypemustbeapplicationvndepostsendapijsonpdfpartmediatypemustbeapplicationpdfandjpgpartmediatypemustbeimagejpegSeehttptoolsietforghtmlrfc2616forvalidcontenttypesandparameters,

        /// <summary>
        /// PostageInfo401Ticketisnotvalid.
        /// </summary>
        PostageInfo401Ticketisnotvalid,

        /// <summary>
        /// Interner Verarbeitungsfehler.
        /// </summary>
        PostageInfo500 = 2100,

        /// <summary>The postage info 503.</summary>
        PostageInfo503,

        /// <summary>The postage info 503 could_not_get_result.</summary>
        PostageInfo503could_not_get_result,

        /// <summary>
        /// Interner Server-Fehler
        /// </summary>
        PostageInfo500internal,

        /// <summary>The e post session 502 could_not_get_result.</summary>
        PostageInfo502could_not_get_result,

        /// <summary>The postage info 504 could_not_get_result.</summary>
        PostageInfo504could_not_get_result,

        /// <summary>The postage info 999 could_not_get_result.</summary>
        PostageInfo999could_not_get_result = 2190,

        /// <summary>The postage info 999 access_token_null.</summary>
        PostageInfo999access_token_null,

        /// <summary>The postage info 999 content_source_null.</summary>
        PostageInfo999content_source_null,

        /// <summary>Die JSON-Fehlermeldung konnte nicht geparst werden. Mögliche Fehler: Server-Fehler oder fehlende Internetverbindung.</summary>
        PostageInfoUnexpectedcharacterencountered,

        /// <summary>The postage info 0 could_not_get_result.</summary>
        PostageInfo0could_not_get_result,

        /// <summary>
        /// Das Access Token ist abgelaufen oder ungültig.
        /// </summary>
        DeleteDraft401invalid_tokenTheaccesstokenisinvalidorhasbeenexpired = 2200,

        /// <summary>
        /// Nicht korrekt eingelogt.
        /// </summary>
        DeleteDraft401Ticketisnotvalid,

        /// <summary>
        /// Forbidden.
        /// </summary>
        DeleteDraft403,

        /// <summary>
        /// Der E-POSTBRIEF ist eine ungelesene Empfangsbestätigung (diese könnnen grundsätzlich nicht gelöscht wwerden).
        /// </summary>
        DeleteDraft403READ_002,

        /// <summary>
        /// Fehlende Zugriffsrechte.
        /// </summary>
        DeleteDraft403READ_003,

        /// <summary>
        /// Fehlende Privilegien.
        /// </summary>
        DeleteDraft403insufficient_scopeTheaccesstokenlackstherequiredprivileges,

        /// <summary>
        /// Kein passender Scope.
        /// </summary>
        DeleteDraft403Authenticationscopedoesnotmatch,

        /// <summary>
        /// Unter der angegebenen URL konnte keine Ressource gefunden werden.
        /// </summary>
        DeleteDraft404,

        /// <summary>
        /// Die HTTP-Methode ist nicht unterstützt.
        /// </summary>
        DeleteDraft405,

        /// <summary>
        /// Beim referenzierten E‑POSTBRIEF handelt es sich nicht um einen
        /// Entwurf.
        /// </summary>
        DeleteDraft409not_draft,

        /// <summary>
        /// Interner Verarbeitungsfehler.
        /// </summary>
        DeleteDraft500 = 2300,

        /// <summary>The delete draft 500 could_not_get_result.</summary>
        DeleteDraft500could_not_get_result,

        /// <summary>The delete draft 503.</summary>
        DeleteDraft503,

        /// <summary>The delete draft 503 could_not_get_result.</summary>
        DeleteDraft503could_not_get_result,

        /// <summary>
        /// Interner Fehler auf dem Server
        /// </summary>
        DeleteDraft500internal,

        /// <summary>The delete draft 502 could_not_get_result.</summary>
        DeleteDraft502could_not_get_result,

        /// <summary>The delete draft 504 could_not_get_result.</summary>
        DeleteDraft504could_not_get_result,

        /// <summary>The delete draft 999 could_not_get_result.</summary>
        DeleteDraft999could_not_get_result = 2390,

        /// <summary>
        /// AccessToken is null
        /// </summary>
        DeleteDraft999access_token_null,

        /// <summary>Error message (JSON) could not be parsed. Possible reason, server error, no internet connection</summary>
        DeleteDraftUnexpectedcharacterencountered,

        /// <summary>The DeleteDraft 0 could_not_get_result.</summary>
        DeleteDraft0could_not_get_result,

        /// <summary>
        /// Der Fehlertyp konnte nicht bestimmt werden.
        /// </summary>
        Unknown = 2999,
    }
}