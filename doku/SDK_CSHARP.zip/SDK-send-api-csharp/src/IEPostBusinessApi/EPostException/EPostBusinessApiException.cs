namespace IEPostBusinessApi.EPostException
{
    using System;
    using System.Configuration;
    using System.Text;

    using IEPostBusinessApi.JSON.Error;
    using IEPostBusinessApi.Properties;

    /// <summary>
    ///   Die EPostBusinessApiException kapselt die in der REST-Schnittstelle zum E-POST-Server auftretenden Fehler.
    /// </summary>
    public class EPostBusinessApiException : Exception
    {
        #region Constructors and Destructors

        /// <summary>
        ///   Initialisiert eine neue Instanz der <see cref="EPostBusinessApiException" /> Klasse.
        /// </summary>
        /// <param name="message"> Die Fehlerbeschreibung der Exception. </param>
        /// <param name="innerException"> Eine innere Exception, falls Sie zum Auftreten dieser Exception gef�hrt hat. </param>
        /// <param name="className"> Der Name der Klasse, in der diese Exception ausgel�st wurde. </param>
        /// <param name="httpStatusCode"> Der HttpStatusCode, der vom Service, der diese Exception ausgel�st hat, zur�ck geliefert wurde. </param>
        /// <param name="error"> Die <see cref="ErrorResponse" />, die die REST-Schnittstelle zur�ck geliefert hat. </param>
        public EPostBusinessApiException(
            string message, Exception innerException, string className, int httpStatusCode, ErrorResponse error)
            : base(message, innerException)
        {
            Error = error;
            ErrorType = GetEPostBusinessConnectExceptionType(className, httpStatusCode, Error);
        }

        /// <summary>
        ///   Initialisiert eine neue Instanz der <see cref="EPostBusinessApiException" /> Klasse.
        /// </summary>
        /// <param name="message"> Die Fehlerbeschreibung der Exception. </param>
        /// <param name="className"> Der Name der Klasse, in der diese Exception ausgel�st wurde. </param>
        /// <param name="httpStatusCode"> Der HttpStatusCode, der vom Service, der diese Exception ausgel�st hat, zur�ck geleifert wurde. </param>
        /// <param name="error"> Die <see cref="ErrorResponse" />, die die REST-Schnittstelle zur�ck geliefert hat. </param>
        public EPostBusinessApiException(string message, string className, int httpStatusCode, ErrorResponse error)
            : base(message)
        {
            Error = error;
            ErrorType = GetEPostBusinessConnectExceptionType(className, httpStatusCode, Error);
        }

        #endregion

        #region Public Properties

        /// <summary>
        ///   Die ErrorResponse, die die REST-Schnittstelle zur�ck geliefert hat.
        /// </summary>
        public ErrorResponse Error { get; set; }

        /// <summary>
        ///   Der ErrorType der EPostBusinessApiException.
        /// </summary>
        public EPostBusinessApiExceptionType ErrorType { get; private set; }

        /// <summary>
        ///   Der Name des Fehlers.
        /// </summary>
        public string ErrorTypeName { get; private set; }

        /// <summary>
        ///   Liefert die lokalisierte Beschreibung des Fehlers. <br /> Diese sollte f�r den Benutzer lesbar und verst�ndlich sein.
        /// </summary>
        public string LocalizedDescription
        {
            get
            {
                var displayName = ErrorType.GetLocalizedName();
                if (displayName.Equals(EnumExtensions.GetUnknownName(ErrorType.ToString("f"))))
                {
                    displayName = EnumExtensions.GetUnknownName(ErrorTypeName);
                    return string.Format(Resources.UnknownError, displayName);
                }

                return string.Format(Resources.Error, (int)ErrorType, displayName);
            }
        }

        #endregion

        #region Methods

        /// <summary>
        ///   Normalisiert einen string um daraus eine Fehlerbeschreibung zu erhalten.
        /// </summary>
        /// <param name="stringToBeNormalized"> Der string, der normalisiert werden soll. </param>
        /// <returns> der normalisierte string. </returns>
        private static string NormalizeString(string stringToBeNormalized)
        {
            return stringToBeNormalized != null
                       ? stringToBeNormalized.Replace(" ", string.Empty).Replace(".", string.Empty).Replace(
                           ":", string.Empty).Replace("(", string.Empty).Replace(")", string.Empty).Replace(",", string.Empty)
                           .Replace("'", string.Empty).Replace("/", string.Empty).Replace("-", string.Empty).Replace("+", string.Empty)
                       : string.Empty;
        }

        /// <summary>
        ///   Erzeugt den Fehlercode.
        /// </summary>
        /// <param name="className"> Der Name der Klasse, in der diese Exception ausgel�st wurde. </param>
        /// <param name="httpStatusCode"> Der HttpStatusCode, der vom Service, der diese Exception ausgel�st hat, zur�ck geliefert wurde. </param>
        /// <param name="error"> Die ErrorResponse, die die REST-Schnittstelle zur�ck geliefert hat. </param>
        /// <returns> Die <see cref="EPostBusinessApiExceptionType" /> . </returns>
        private EPostBusinessApiExceptionType GetEPostBusinessConnectExceptionType(
            string className, int httpStatusCode, ErrorResponse error)
        {
            var retEnum = EPostBusinessApiExceptionType.Unknown;
            var stringToBeParsed = new StringBuilder();
            try
            {
                if (className == null)
                {
                    className = string.Empty;
                }

                stringToBeParsed = new StringBuilder(className);

                // Check if error while parsing JSON --> fatal error while connecting to server.
                if (NormalizeString(error.Error).StartsWith(Settings.Default.UnecpectedError))
                {
                    stringToBeParsed.Append(Settings.Default.UnecpectedError);
                }
                else
                {
                    stringToBeParsed.Append(httpStatusCode);
                    stringToBeParsed.Append(error.Error ?? string.Empty);
                    if (error.ErrorDetails != null && error.ErrorDetails.Count > 0)
                    {
                        if (!string.IsNullOrEmpty(error.ErrorDetails[0].ErrorCode))
                        {
                            stringToBeParsed.Append(error.ErrorDetails[0].ErrorCode);
                        }
                        else
                        {
                            stringToBeParsed.Append(error.ErrorDetails[0].Description);
                        }
                    }
                    else
                    {
                        stringToBeParsed.Append(error.ErrorDescription);
                    }
                }

                retEnum =
                    (EPostBusinessApiExceptionType)
                    Enum.Parse(typeof(EPostBusinessApiExceptionType), NormalizeString(stringToBeParsed.ToString()));
                ErrorTypeName = retEnum.ToString("f");
            }
            catch (Exception)
            {
                ErrorTypeName = retEnum.ToString("f") + "-" + NormalizeString(stringToBeParsed.ToString());
            }

            return retEnum;
        }

        #endregion
    }
}