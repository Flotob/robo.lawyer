﻿namespace IEPostBusinessApi
{
    using System;

    /// <summary>Der WorkStatusEventHandler dient dazu, über den WorkStatus zu informieren.</summary>
    /// <param name="sender">Der Sender.</param>
    /// <param name="workStatusEventArgs">Die WorkStatusEventArgs.</param>
    public delegate void WorkStatusEventHandler(object sender, WorkStatusEventArgs workStatusEventArgs);

    /// <summary>Die WorkStatusEventArgs beinhalten die Informationen über den übertragenen WorkStatus.</summary>
    public class WorkStatusEventArgs : EventArgs
    {
        #region Constructors and Destructors

        /// <summary>Initialisiert eine neue Instanz der <see cref="WorkStatusEventArgs"/> Klasse.</summary>
        /// <param name="workStatus">TODO The work status.</param>
        public WorkStatusEventArgs(WorkStatus workStatus)
        {
            WorkStatus = workStatus;
        }

        #endregion

        #region Public Properties

        /// <summary>Liest WorkStatus.</summary>
        public WorkStatus WorkStatus { get; private set; }

        #endregion
    }
}