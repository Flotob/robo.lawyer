﻿namespace IEPostBusinessApi
{
    /// <summary>
    /// Der Scope legt fest, inwieweit der Client auf die Ressource(n)
    /// des Nutzers zugreift:
    /// <ul>
    /// 	<li>Es ist möglich, mehrere Scopes gleichzeitig anzugeben.</li>
    /// 	<li>Mehrere Scopes werden entweder mit einem maskierten Leerzeichen oder mit einem + -Zeichen voneinander getrennt.</li>
    /// 	<li>Beispiel für mehrere Scopes: scope=send_letter+read_letter.</li>
    /// 	<li>Das Authentisierungs-Niveau gibt an, ob sich der Nutzer des E‐POST Systems mit einer HandyTAN authentifizieren muss (hoch) oder nicht (normal).</li>
    /// 	<li>Folgende Scopes sind möglich:</li>
    /// 	<dl>
    ///    		<dt>send_letter</dt>
    ///    		<dd>
    /// 			<ul>
    /// 				<li>erlaubt das Versenden von elektronischen E-POSTBRIEFEN</li>
    /// 				<li>erfordert ein hohes Authentifizierungs-Niveau</li>
    /// 			</ul>
    /// 		</dd>
    /// 		<dt>send_hybrid</dt>
    /// 		<dd>
    /// 			<ul>
    /// 				<li>erlaubt das Versenden von physischen E-POSTBRIEFEN</li>
    /// 				<li>erfordert ein normales Authentifizierungs-Niveau</li>
    /// 			</ul>
    /// 		</dd>
    /// 		<dt>read_letter</dt>
    /// 		<dd>
    /// 			<ul>
    /// 				<li>erlaubt das Lesen von E-POSTBRIEFEN</li>
    /// 				<li>erfordert ein normales Authentifizierungs-Niveau</li>
    /// 			</ul>
    /// 		</dd>
    /// 		<dt>create_letter</dt>
    /// 		<dd>
    /// 			<ul>
    /// 				<li>erlaubt das Erstellen von E-POSTBRIEF Entwürfen</li>
    /// 				<li>erfordert ein normales Authentifizierungs-Niveau</li>
    /// 			</ul>
    /// 		</dd>
    /// 		<dt>delete_letter</dt>
    /// 		<dd>
    /// 			<ul>
    /// 				<li>erlaubt das Löschen von E-POSTBRIEF Entwürfen</li>
    /// 				<li>erfordert ein normales Authentifizierungs-Niveau</li>
    /// 			</ul>
    /// 		</dd>
    /// 	</dl>
    /// </ul>
    /// </summary>
    public enum Scope
    {
        // ReSharper disable InconsistentNaming
        // Hier werden die Enum entgegen der Namenskonventionen definiert, da sie genau so auch in der REST-API
        // verwendet werden können und so die Interoperabilität besser erhalten werden kann.

        /// <summary>
        /// <dl>
        ///    	<dt>send_letter</dt>
        ///    	<dd>
        /// 		<ul>
        /// 			<li>erlaubt das Versenden von elektronischen E-POSTBRIEFEN</li>
        /// 			<li>erfordert ein hohes Authentifizierungs-Niveau</li>
        /// 		</ul>
        /// 	</dd>
        /// </dl>
        /// </summary>
        send_letter, 

        /// <summary>
        ///	<dl>
        /// 	<dt>send_hybrid</dt>
        /// 	<dd>
        /// 		<ul>
        /// 			<li>erlaubt das Versenden von physischen E-POSTBRIEFEN</li>
        /// 			<li>erfordert ein normales Authentifizierungs-Niveau</li>
        /// 		</ul>
        /// 	</dd>
        /// </dl>
        /// </summary>
        send_hybrid, 

        /// <summary>
        ///	<dl>
        /// 	<dt>read_letter</dt>
        /// 	<dd>
        /// 		<ul>
        /// 			<li>erlaubt das Lesen von E-POSTBRIEFEN</li>
        /// 			<li>erfordert ein normales Authentifizierungs-Niveau</li>
        /// 		</ul>
        /// 	</dd>
        /// </dl>
        /// </summary>
        read_letter, 

        /// <summary>
        ///	<dl>
        /// 	<dt>create_letter</dt>
        /// 	<dd>
        /// 		<ul>
        /// 			<li>erlaubt das Erstellen von E-POSTBRIEF Entwürfen</li>
        /// 			<li>erfordert ein normales Authentifizierungs-Niveau</li>
        /// 		</ul>
        /// 	</dd>
        /// </dl>
        /// </summary>
        create_letter, 

        /// <summary>
        ///	<dl>
        /// 	<dt>delete_letter</dt>
        /// 	<dd>
        /// 		<ul>
        /// 			<li>erlaubt das Löschen von E-POSTBRIEF Entwürfen</li>
        /// 			<li>erfordert ein normales Authentifizierungs-Niveau</li>
        /// 		</ul>
        /// 	</dd>
        /// </dl>
        /// </summary>
        delete_letter,

        /// <summary>
        ///	<dl>
        /// 	<dt>delete_letter</dt>
        /// 	<dd>
        /// 		<ul>
        /// 			<li>erlaubt en Zugriff auf den E-POSTSAFE</li>
        /// 			<li>erfordert ein normales Authentifizierungs-Niveau</li>
        /// 		</ul>
        /// 	</dd>
        /// </dl>
        /// </summary>
        safe
    }
}