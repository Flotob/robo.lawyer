﻿namespace IEPostBusinessApi
{
    /// <summary>
    /// Eine Aufzählung der Hauptordner im E-POSTBRIEF Konto.
    /// </summary>
    public enum MainFolderTypes
    {
        // ReSharper disable InconsistentNaming

        /// <summary>
        /// Posteingang.
        /// </summary>
        inbox, 

        /// <summary>
        /// Entwürfe.
        /// </summary>
        drafts, 

        /// <summary>
        /// Gesendet.
        /// </summary>
        sent, 

        /// <summary>
        /// Gelöscht.
        /// </summary>
        trash
    }
}