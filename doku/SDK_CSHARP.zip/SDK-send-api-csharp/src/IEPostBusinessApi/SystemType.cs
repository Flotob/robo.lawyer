namespace IEPostBusinessApi
{
    /// <summary>
    /// Angabe des zu verwendenden Systems:
    /// <ul>
    ///     <li>Integrations- und Testumgebung (ITU)</li>
    ///     <li>Produktionsumgebung (PROD)</li>
    /// </ul>
    /// </summary>
    public enum SystemType
    {
        /// <summary>
        /// Integrations- und Testumgebung (ITU)
        /// </summary>
        Itu, 

        /// <summary>
        /// Produktionsumgebung (PROD)
        /// </summary>
        Prod,

        /// <summary>
        /// Ein drittest System, das unabh�ngig angegeben werden kann.
        /// </summary>
        ThirdSystem
    }
}