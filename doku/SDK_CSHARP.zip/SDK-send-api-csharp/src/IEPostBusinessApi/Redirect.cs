﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IEPostBusinessApi
{
    using System.Net;

    /// <summary>
    /// Diese Klasse enthält ein Objekt, dass zum Redirect eines Aufrufs genutzt werden kann, bei dem auch Cookies gesetzt werden können.
    /// </summary>
    public class Redirect
    {
        /// <summary>
        /// Die Uri.
        /// </summary>
        public Uri Uri { get; set; }

        /// <summary>
        /// Der Cookies.
        /// </summary>
        public CookieCollection Cookies { get; set; }
    }
}
