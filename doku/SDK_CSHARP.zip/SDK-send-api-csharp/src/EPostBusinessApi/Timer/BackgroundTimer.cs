﻿namespace EPostBusinessApi.Timer
{
    using System;
    using System.ComponentModel;
    using System.Threading;

    /// <summary>
    /// Dies ist der Timer, der in einem Backgroundworker-Thread die Zeiten zum Statuswechsel überwacht.
    /// </summary>
    public class BackgroundTimer
    {
        #region Fields

        /// <summary>
        /// Gibt an, ob der BackgroundWorker gestoppt werden soll.
        /// </summary>
        private bool stop = true;

        /// <summary>
        /// Der Timer läuft als BackgroundWorker.
        /// </summary>
        private BackgroundWorker worker;

        #endregion

        #region Public Events

        /// <summary>
        /// Wird aufgerufen, nachdem der Timer abgelaufen ist.
        /// </summary>
        public event EventHandler Elapsed;

        #endregion

        #region Public Properties

        /// <summary>
        /// Die Anzahl der Sekunden, nachdem der Timer abläuft.
        /// </summary>
        public int Seconds { get; set; }

        #endregion

        #region Properties

        /// <summary>
        /// Der Zeitpunkt, zu dem der Timer abläuft.
        /// </summary>
        private DateTime DateTimeElapsed { get; set; }

        #endregion

        #region Public Methods and Operators

        /// <summary>
        /// Dispose Methode.
        /// </summary>
        public void Dispose()
        {
            stop = true;
            Elapsed = null;

            if (worker != null)
            {
                worker.CancelAsync();
                worker.Dispose();
            }
        }

        /// <summary>
        /// Startet den Timer.
        /// </summary>
        public void Start()
        {
            if (Seconds < 1)
            {
                throw new ArgumentException("Seconds must be minimum of 1");
            }

            if (worker != null && worker.IsBusy)
            {
                throw new ArgumentException("Worker already started");
            }

            DateTimeElapsed = DateTime.Now.AddSeconds(Seconds);

            worker = new BackgroundWorker { WorkerSupportsCancellation = true };
            worker.DoWork += this.WorkerDoWork;
            worker.RunWorkerAsync();
        }

        /// <summary>
        /// Stoppt den Timer.
        /// </summary>
        public void Stop()
        {
            stop = true;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Ruft das Elapsed Event auf.
        /// </summary>
        protected virtual void OnElapsed()
        {
            var handler = this.Elapsed;
            if (handler != null)
            {
                handler(this, EventArgs.Empty);
            }
        }

        /// <summary>Der asynchrone Thread, der den Ablauf überwacht.</summary>
        /// <param name="sender">sender.</param>
        /// <param name="e">EventArgs.</param>
        private void WorkerDoWork(object sender, DoWorkEventArgs e)
        {
            stop = false;

            while (DateTime.Now < DateTimeElapsed)
            {
                Thread.Sleep(500);
                if (stop)
                {
                    return;
                }
            }

            this.OnElapsed();
        }

        #endregion
    }
}