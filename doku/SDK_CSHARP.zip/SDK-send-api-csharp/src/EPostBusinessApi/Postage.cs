﻿namespace EPostBusinessApi
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net;

    using EPostBusinessApi.Properties;
    using EPostBusinessApi.Status;

    using IEPostBusinessApi.EPostException;
    using IEPostBusinessApi.JSON.Error;
    using IEPostBusinessApi.JSON.Postage;
    using IEPostBusinessApi.JSON.PrintOptions;

    using Newtonsoft.Json;

    /// <summary>Diese Klasse dient dem Abfragen der Preisinformationen.</summary>
    internal class Postage : ApiBaseRequest
    {
        #region Constants

        /// <summary>Der Name dieser Klasse zu Zwecken der Fehlerbehandlung.</summary>
        private const string ClassName = "PostageInfo";

        #endregion

        #region Properties

        /// <summary>Liest oder setzt ContentSource.</summary>
        internal string ContentSource { get; set; }

        /// <summary>Liest oder setzt PrintOptionsRequest.</summary>
        internal PrintOptionsRequest PrintOptionsRequest { get; set; }

        /// <summary>Liest oder setzt XEpostAccessToken.</summary>
        internal string XEpostAccessToken { get; set; }

        /// <summary>Liest ContentType.</summary>
        protected override string ContentType
        {
            get
            {
                return ContentSource == null
                           ? Settings.Default.MIME_TypePostageInfo
                           : Settings.Default.MIME_TYPESendPrintOptions;
            }
        }

        /// <summary>Gets the method.</summary>
        protected override string Method
        {
            get
            {
                return Settings.Default.Method_POST;
            }
        }

        /// <summary>Gets the mime type.</summary>
        protected override string MimeType
        {
            get
            {
                return Settings.Default.MIME_TypePostageInfo;
            }
        }

        /// <summary>Gets the ok status code.</summary>
        protected override HttpStatusCode OkStatusCode
        {
            get
            {
                return HttpStatusCode.OK;
            }
        }

        /// <summary>Gets the request header.</summary>
        protected override List<string> RequestHeader
        {
            get
            {
                var header = new List<string>
                                 {
                                     string.Format(
                                         Settings.Default.XEpostAccessToken, 
                                         XEpostAccessToken)
                                 };

                // ContentSource nur hinzufügen, falls vorhanden, dann wird die Abfrage für den hier referenzierten Entwurf gemacht
                // ansonsten nur auf Grundlage der Metadaten.
                if (!string.IsNullOrEmpty(ContentSource))
                {
                    header.Add(string.Format(Settings.Default.ContentSource, ContentSource));
                }

                return header;
            }
        }

        /// <summary>Gets the url.</summary>
        protected override Uri Url
        {
            get
            {
                return new Uri(CreateUrl());
            }
        }

        #endregion

        #region Methods

        /// <summary>Fragt die Preisinformation ab.</summary>
        /// <returns>Die Preisinformation als <see cref="PostageInfoResponse" />.</returns>
        /// <exception cref="EPostBusinessApiException">throws an exception</exception>
        internal PostageInfoResponse GetPostageInfo()
        {
            if (XEpostAccessToken == null)
            {
                Error = CreateErrorResponse("access_token_null", "Access Token is null", null);
                throw new EPostBusinessApiException("Access Token is null", ClassName, 999, Error);
            }

            var result = DoRequest();
            if (result.Key == typeof(PostageInfoResponse))
            {
                return result.Value as PostageInfoResponse;
            }

            if (result.Key == typeof(ErrorResponse))
            {
                Error = result.Value as ErrorResponse;
            }
            else if (result.Key == typeof(ErrorDetail))
            {
                var detail = result.Value as ErrorDetail;
                if (detail != null)
                {
                    Error = new ErrorResponse
                                     {
                                         Error = string.Empty, 
                                         ErrorDescription = detail.Description, 
                                         ErrorDetails = new List<ErrorDetail> { detail }
                                     };
                }
            }
            else
            {
                Error = CreateErrorResponse("could_not_get_result", "Could not get result", null);
            }

            throw new EPostBusinessApiException("Could not get result", ClassName, (int)StatusCode, Error);
        }

        /// <summary>Liefert das Format des zurückgegebenen Bodies aus dem HttpStatusCode.</summary>
        /// <param name="statusCode">HttpStatusCode</param>
        /// <returns>BodyFormat</returns>
        protected override BodyFormat GetBodyFormat(HttpStatusCode statusCode)
        {
            switch (statusCode)
            {
                case HttpStatusCode.OK:
                    return BodyFormat.JsonPostageInfo;
                case HttpStatusCode.Unauthorized:
                case HttpStatusCode.Forbidden:
                case HttpStatusCode.NotAcceptable:
                case HttpStatusCode.Conflict:
                case HttpStatusCode.BadRequest:
                    return BodyFormat.JsonError;
                case HttpStatusCode.NotFound:
                case HttpStatusCode.MethodNotAllowed:
                case HttpStatusCode.InternalServerError:
                case HttpStatusCode.UnsupportedMediaType:
                    return BodyFormat.JsonErrorOnlyDescription;
                default:
                    return BodyFormat.NothingUndefined;
            }
        }

        /// <summary>Schreibt den Request.</summary>
        /// <param name="writer">Der writer.</param>
        protected override void WriteRequestStream(StreamWriter writer)
        {
            if (PrintOptionsRequest != null)
            {
                writer.WriteLine(JsonConvert.SerializeObject(PrintOptionsRequest, Formatting.Indented));
            }
        }

        /// <summary>Erzeugt die URL.</summary>
        /// <returns>Die URL als <see cref="string" />.</returns>
        private string CreateUrl()
        {
            return string.Format(Settings.Default.PostageInfoURL, GetSystem());
        }

        #endregion
    }
}