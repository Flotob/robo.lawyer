﻿namespace EPostBusinessApi
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net.Mail;

    using IEPostBusinessApi;
    using IEPostBusinessApi.EPostException;
    using IEPostBusinessApi.JSON.Error;

    /// <summary>Diese Klasse ist eine Hilfsklasse zur Validierung.</summary>
    public static class Validator
    {
        #region Static Fields

        /// <summary>Itu Adressen.</summary>
        private static readonly string[] ItuAddresses = { "@epost-gka.de", ".epost-gka.de" };

        /// <summary>Prod Adressen.</summary>
        private static readonly string[] ProdAddresses = { "@epost.de", ".epost.de" };

        #endregion

        #region Public Methods and Operators

        /// <summary>Prüft auf eine gültige E-Mailadresse.</summary>
        /// <param name="emailAddressCandidate">Die zu prüfende Adresse.</param>
        /// <returns>true / false <see cref="bool"/>.</returns>
        public static bool IsValidEmailaddress(string emailAddressCandidate)
        {
            try
            {
                // ReSharper disable once ObjectCreationAsStatement
                new MailAddress(emailAddressCandidate);
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }

        /// <summary>Prüft auf eine gültige E-Postbriefadresse in Abhängigkeit vom System.</summary>
        /// <param name="ePostbriefAddressCandidate">Die zu prüfende Adresse.</param>
        /// <param name="systemType">Der SystemType.</param>
        /// <returns>true / false <see cref="bool"/>.</returns>
        /// <exception cref="EPostBusinessApiException">EPostBusinessApiException</exception>
        public static bool IsValidEpostbriefaddress(string ePostbriefAddressCandidate, string systemType)
        {
            try
            {
                var st = (SystemType)Enum.Parse(typeof(SystemType), systemType);

                return IsValidEpostbriefaddress(ePostbriefAddressCandidate, st);
            }
            catch (Exception e)
            {
                throw new EPostBusinessApiException(
                    "Wrong system type", 
                    e, 
                    "Validator", 
                    999, 
                    new ErrorResponse { Error = "Wrong system type" });
            }
        }

        /// <summary>Prüft auf eine gültige E-Postbriefadresse in Abhängigkeit vom System.</summary>
        /// <param name="ePostbriefAddressCandidate">Die zu prüfende Adresse.</param>
        /// <param name="systemType">Der SystemType.</param>
        /// <returns>true / false <see cref="bool"/>.</returns>
        /// <exception cref="EPostBusinessApiException">EPostBusinessApiException</exception>
        public static bool IsValidEpostbriefaddress(string ePostbriefAddressCandidate, SystemType systemType)
        {
            var lowerCaseAddressCandidate = ePostbriefAddressCandidate.ToLowerInvariant();

            bool isItuAddress = (systemType == SystemType.Itu && Endswith(lowerCaseAddressCandidate, ItuAddresses));
            bool isProdAddress = (systemType == SystemType.Prod && Endswith(lowerCaseAddressCandidate, ProdAddresses));
            bool dotNetThinksItIsAValidEmailAddress = IsValidEmailaddress(lowerCaseAddressCandidate);
            return ((isItuAddress || isProdAddress) && dotNetThinksItIsAValidEmailAddress);
        }

        #endregion

        #region Methods

        /// <summary>Prüft, ob ein String auf einen der im Array angegeben Strings endet.</summary>
        /// <param name="candidate">Der zu prüfende String.</param>
        /// <param name="ending">Das Array mit den Endungen.</param>
        /// <returns>true / false <see cref="bool"/>.</returns>
        private static bool Endswith(string candidate, IEnumerable<string> ending)
        {
            return candidate != null && ending.Any(candidate.EndsWith);
        }

        #endregion
    }
}