﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EPostBusinessApi.LoginStateMachine
{
    using IEPostBusinessApi;
    using IEPostBusinessApi.LoginStateMachine;

    /// <summary>
    /// Der Status in dem ein Refresh ins normale Authentifizierungs-Niveau möglich ist.
    /// </summary>
    public class RefreshableLowState : BaseLoginState
    {
        /// <summary>Initialisiert eine neue Instanz der <see cref="LoggedOutState"/> Klasse.</summary>
        /// <param name="loginState">Der vorherige LoginStatus.</param>
        public RefreshableLowState(ILoginState loginState)
            : base(loginState)
        {
            // Da der Zustand RefreshLow sowohl aus LoggedInLow als auch RefreshHigh erreicht werden kann und beim Starten immer nur ein
            // vorheriger Timer gestoppt werden kann, wird hier ein evtl. laufender Timer zum Status RefreshHigh gestoppt.
            ((EPostSession)loginState.EPostSessionContext).StopTimerRefreshHigh();
            ((EPostSession)loginState.EPostSessionContext).StartTimerRefreshLow();

            LoginStatus = LoginStatus.RefreshableLow;
        }

        /// <summary>Der Benutzer wird aufgefordert, die Zugangsdaten im hohen Authentifizierungs-Niveau in einem Browserfenster anzugeben.</summary>
        public override void GoToLoggedInHighStateWithBrowserAuthentication()
        {
            this.GoToLoggedInHighStateWithBrowserAuthentication(null);
        }

        /// <summary>Der Benutzer wird aufgefordert, die Zugangsdaten im hohen Authentifizierungs-Niveau in einem Browserfenster anzugeben.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die Interaktionen angezeigt werden.</param>
        public override void GoToLoggedInHighStateWithBrowserAuthentication(System.Windows.Controls.WebBrowser browser)
        {
            try
            {
                RefreshAccessTokenLow();
                EPostSessionContext.LoginStateMachine.GoToLoggedInHighStateWithBrowserAuthentication(browser);
            }
            catch (Exception)
            {
                EPostSessionContext.LoginStateMachine = new LoggedOutState(this);
                throw;
            }
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im hohen Authentifizierungs-Niveau angemeldet.</summary>
        public override void GoToLoggedInHighStateWithCredentialManagerAuthentication()
        {
            this.GoToLoggedInHighStateWithCredentialManagerAuthentication(null);
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten angemeldet.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die HandyTAN eingegeben werden muss.</param>
        public override void GoToLoggedInHighStateWithCredentialManagerAuthentication(System.Windows.Controls.WebBrowser browser)
        {
            try
            {
                RefreshAccessTokenLow();
            }
            catch (Exception)
            {
                EPostSessionContext.LoginStateMachine = new LoggedOutState(this);
                throw;
            }
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im niedrigen Authentifizierungs-Niveau angemeldet.
        /// Sollte er sich im hohen Authentifizierungs-Niveau befinden, bleibt er dort.</summary>
        public override void GoToLoggedInLowState()
        {
            try
            {
                RefreshAccessTokenLow();
            }
            catch (Exception)
            {
                EPostSessionContext.LoginStateMachine = new LoggedOutState(this);
                throw;
            }
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im niedrigen Authentifizierungs-Niveau angemeldet.
        /// Sollte er sich im hohen Authentifizierungs-Niveau befinden, wird er auf jeden Fall abgemeldet und ins niedrige Niveau befördert.</summary>
        public override void ForceLoginLow()
        {
            this.GoToLoggedInLowState();
        }
    }
}
