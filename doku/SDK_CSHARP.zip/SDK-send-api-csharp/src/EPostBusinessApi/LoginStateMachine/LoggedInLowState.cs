﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EPostBusinessApi.LoginStateMachine
{
    using IEPostBusinessApi;
    using IEPostBusinessApi.EPostException;
    using IEPostBusinessApi.LoginStateMachine;

    /// <summary>
    /// Der Status des Logins mit normalem Authentifizierungs-Niveau.
    /// </summary>
    public class LoggedInLowState : BaseLoginState
    {
        /// <summary>Initialisiert eine neue Instanz der <see cref="LoggedOutState"/> Klasse.</summary>
        /// <param name="loginState">Der vorherige LoginStatus.</param>
        public LoggedInLowState(ILoginState loginState)
            : base(loginState)
        {
            // LoggedOut 1440 min (nur beim ersten Mal)
            ((EPostSession)loginState.EPostSessionContext).StartTimerFinallyLoggedOut();

            // TokenUsable 10 min
            ((EPostSession)loginState.EPostSessionContext).StartTimerLoggedInLow();

            LoginStatus = LoginStatus.LoggedInLow;
        }

        /// <summary>Der Benutzer wird aufgefordert, die Zugangsdaten im hohen Authentifizierungs-Niveau in einem Browserfenster anzugeben.</summary>
        public override void GoToLoggedInHighStateWithBrowserAuthentication()
        {
            this.GoToLoggedInHighStateWithBrowserAuthentication(null);
        }

        /// <summary>Der Benutzer wird aufgefordert, die Zugangsdaten im hohen Authentifizierungs-Niveau in einem Browserfenster anzugeben.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die Interaktionen angezeigt werden.</param>
        public override void GoToLoggedInHighStateWithBrowserAuthentication(System.Windows.Controls.WebBrowser browser)
        {
            // Authentifizierungs-Niveau erhöhen
            try
            {
                LoginExtensionSendLetter(browser);
            }
            catch (Exception)
            {
                // Falls das nicht geklappt hat, hoeren wir auf
                EPostSessionContext.LoginStateMachine = new LoggedOutState(this);
                throw;
            }
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im hohen Authentifizierungs-Niveau angemeldet.</summary>
        public override void GoToLoggedInHighStateWithCredentialManagerAuthentication()
        {
            this.GoToLoggedInHighStateWithCredentialManagerAuthentication(null);
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten angemeldet.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die HandyTAN eingegeben werden muss.</param>
        public override void GoToLoggedInHighStateWithCredentialManagerAuthentication(System.Windows.Controls.WebBrowser browser)
        {
            // Authentifizierungsniveau erhöhen
            try
            {
                LoginExtensionSendLetter(browser);
            }
            catch (Exception)
            {
                // Es kann sein, dass wir erst mal refreshen müssen:
                try
                {
                    RefreshAccessTokenLow();
                    LoginExtensionSendLetter(browser);
                }
                catch (Exception)
                {
                    // Falls das nicht geklappt hat, hoeren wir auf
                    EPostSessionContext.LoginStateMachine = new LoggedOutState(this);
                    throw;
                }
            }
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im niedrigen Authentifizierungs-Niveau angemeldet.
        /// Sollte er sich im hohen Authentifizierungs-Niveau befinden bleibt er dort.</summary>
        public override void GoToLoggedInLowState()
        {
            // Nothing to do.
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im niedrigen Authentifizierungs-Niveau angemeldet.
        /// Sollte er sich im hohen Authentifizierungs-Niveau befinden, wird er auf jeden Fall abgemeldet und ins neiedrige Authentifizierungs-Niveau befördert.</summary>
        public override void ForceLoginLow()
        {
            // Nothing to do.
        }
    }
}
