﻿namespace EPostBusinessApi.LoginStateMachine
{
    using System.Windows.Controls;

    using IEPostBusinessApi;
    using IEPostBusinessApi.LoginStateMachine;

    /// <summary>Der nicht eingeloggte Status.</summary>
    public class NotLoggedInState : BaseLoginState
    {
        #region Constructors and Destructors

        /// <summary>Initialisiert eine neue Instanz der <see cref="BaseLoginState"/> Klasse. Initialisiert eine neue Instanz der<see cref="LoggedOutState"/> Klasse.</summary>
        /// <param name="ePostSessionContext">IEPostSessionContext</param>
        public NotLoggedInState(IEPostSessionContext ePostSessionContext) : base(ePostSessionContext)
        {
        }

        /// <summary>Initialisiert eine neue Instanz der <see cref="LoggedOutState"/> Klasse.</summary>
        /// <param name="loginState">Der vorherige LoginStatus.</param>
        public NotLoggedInState(ILoginState loginState)
            : base(loginState)
        {
            LoginStatus = LoginStatus.NotLoggedIn;
        }

        #endregion

        #region Public Methods and Operators

        /// <summary>Meldet den eventuell angemeldeten Benutzer ab.</summary>
        public override void GoToLoggedOutState()
        {
            // Do Nothing, we are already LoggedOut.
        }

        /// <summary>Der Benutzer wird aufgefordert, die Zugangsdaten im hohen Authentifizierungs-Niveau in einem Browserfenster anzugeben.</summary>
        public override void GoToLoggedInHighStateWithBrowserAuthentication()
        {
            LoginWithBrowserAuthentication(null);
        }

        /// <summary>Der Benutzer wird aufgefordert, die Zugangsdaten im hohen Authentifizierungs-Niveau in einem Browserfenster anzugeben.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die Interaktionen angezeigt werden.</param>
        public override void GoToLoggedInHighStateWithBrowserAuthentication(WebBrowser browser)
        {
            LoginWithBrowserAuthentication(browser);
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im hohen Authentifizierungs-Niveau angemeldet.</summary>
        public override void GoToLoggedInHighStateWithCredentialManagerAuthentication()
        {
            this.GoToLoggedInHighStateWithCredentialManagerAuthentication(null);
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten angemeldet.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die HandyTAN eingegeben werden muss.</param>
        public override void GoToLoggedInHighStateWithCredentialManagerAuthentication(WebBrowser browser)
        {
            // Erst mal ins niedrige Niveau
            LoginWithCredentialManagerAuthentication();

            // und dann ab ins hohe (aus dem niedrigen heraus
            EPostSessionContext.LoginStateMachine.GoToLoggedInHighStateWithCredentialManagerAuthentication(browser);
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im normalen Authentifizierungs-Niveau angemeldet.
        /// Sollte er sich im hohen Authentifizierungs-Niveau befinden, bleibt er dort.</summary>
        public override void GoToLoggedInLowState()
        {
            LoginWithCredentialManagerAuthentication();
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im normalen Authentifizierungs-Niveau angemeldet.
        /// Sollte er sich im hohen Authentifizierungs-Niveau befinden, wird er auf jeden Fall abgemeldet und ins normale Authentifizierungs-Niveau befördert.</summary>
        public override void ForceLoginLow()
        {
            this.GoToLoggedInLowState();
        }

        #endregion
    }
}