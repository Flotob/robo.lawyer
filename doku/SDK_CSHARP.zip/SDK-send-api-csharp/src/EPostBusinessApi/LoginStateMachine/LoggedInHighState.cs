﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EPostBusinessApi.LoginStateMachine
{
    using IEPostBusinessApi;
    using IEPostBusinessApi.LoginStateMachine;

    /// <summary>
    /// Der Status des Logins mit hohem Authentifizierungs-Niveau.
    /// </summary>
    public class LoggedInHighState : BaseLoginState
    {
        /// <summary>Initialisiert eine neue Instanz der <see cref="LoggedOutState"/> Klasse.</summary>
        /// <param name="loginState">Der vorherige LoginStatus.</param>
        public LoggedInHighState(ILoginState loginState)
            : base(loginState)
        {
            LoginStatus = LoginStatus.LoggedInHigh;

            // LoggedOut 1440 min (nur beim ersten Mal)
            ((EPostSession)loginState.EPostSessionContext).StartTimerFinallyLoggedOut();

            // TokenUsable 10 min
            ((EPostSession)loginState.EPostSessionContext).StopTimerLoggedInLow();
            ((EPostSession)loginState.EPostSessionContext).StartTimerLoggedInHigh();
        }

        /// <summary>Der Benutzer wird aufgefordert, die Zugangsdaten im hohen Authentifizierungs-Niveau in einem Browserfenster anzugeben.</summary>
        public override void GoToLoggedInHighStateWithBrowserAuthentication()
        {
            // Nothing to do.
        }

        /// <summary>Der Benutzer wird aufgefordert, die Zugangsdaten im hohen Authentifizierungs-Niveau in einem Browserfenster anzugeben.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die Interaktionen angezeigt werden.</param>
        public override void GoToLoggedInHighStateWithBrowserAuthentication(System.Windows.Controls.WebBrowser browser)
        {
            // Nothing to do.
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im hohen Authentifizierungs-Niveau angemeldet.</summary>
        public override void GoToLoggedInHighStateWithCredentialManagerAuthentication()
        {
            // Nothing to do.
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten angemeldet.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die HandyTAN eingegeben werden muss.</param>
        public override void GoToLoggedInHighStateWithCredentialManagerAuthentication(System.Windows.Controls.WebBrowser browser)
        {
            // Nothing to do.
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im normalen Authentifizierungs-Niveau angemeldet.
        /// Sollte er sich im hohen Authentifizierungs-Niveau befinden, bleibt er dort.</summary>
        public override void GoToLoggedInLowState()
        {
            // Nothing to do.
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im normalen Authentifizierungs-Niveau angemeldet.
        /// Sollte er sich im hohen Authentifizierungs-Niveau befinden, wird er auf jeden Fall abgemeldet und ins normale Authentifizierungs-Niveau befördert.</summary>
        public override void ForceLoginLow()
        {
            // Es gibt keinen direkten weg vom hohen in den niedrigen Status
            // deshalb erst mal ausloggen
            // dort wird dann auch der ausgeloggte Status gesetzt.
            Logout();

            // der ausgeloggte Status der dann aktiv ist, weiß, wie man in den niedrigen kommt.
            EPostSessionContext.LoginStateMachine.GoToLoggedInLowState();
        }
    }
}
