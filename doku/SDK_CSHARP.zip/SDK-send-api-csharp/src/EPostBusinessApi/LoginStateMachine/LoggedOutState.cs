﻿namespace EPostBusinessApi.LoginStateMachine
{
    using System.Windows.Controls;

    using IEPostBusinessApi;
    using IEPostBusinessApi.LoginStateMachine;

    /// <summary>Der ausgeloggte Status.</summary>
    public class LoggedOutState : NotLoggedInState
    {
        #region Constructors and Destructors

        /// <summary>Initialisiert eine neue Instanz der <see cref="LoggedOutState"/> Klasse.</summary>
        /// <param name="loginState">Der vorherige LoginStatus.</param>
        public LoggedOutState(ILoginState loginState)
            : base(loginState)
        {
            LoginStatus = LoginStatus.LoggedOut;

            ((EPostSession)loginState.EPostSessionContext).StopTimerFinallyLoggedOut();
            ((EPostSession)loginState.EPostSessionContext).StopTimerLoggedInLow();
            ((EPostSession)loginState.EPostSessionContext).StopTimerLoggedInHigh();
            ((EPostSession)loginState.EPostSessionContext).StopTimerRefreshLow();
            ((EPostSession)loginState.EPostSessionContext).StopTimerRefreshHigh();
        }

        #endregion
   }
}