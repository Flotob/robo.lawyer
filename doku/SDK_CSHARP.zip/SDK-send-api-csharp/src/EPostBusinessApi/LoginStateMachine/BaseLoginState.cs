﻿namespace EPostBusinessApi.LoginStateMachine
{
    using System;
    using System.Windows.Controls;

    using IEPostBusinessApi;
    using IEPostBusinessApi.LoginStateMachine;

    /// <summary>Die abstrakte Basisklasse für alle LoginStates.</summary>
    public abstract class BaseLoginState : ILoginState
    {
        #region Constructors and Destructors

        /// <summary>Initialisiert eine neue Instanz der <see cref="BaseLoginState"/> Klasse. Initialisiert eine neue Instanz der <see cref="LoggedOutState"/> Klasse.</summary>
        /// <param name="ePostSessionContext">IEPostSessionContext</param>
        protected BaseLoginState(IEPostSessionContext ePostSessionContext)
        {
            EPostSessionContext = ePostSessionContext;
            Login = ePostSessionContext.Login;
        }

        /// <summary>Initialisiert eine neue Instanz der <see cref="BaseLoginState"/> Klasse. Initialisiert eine neue Instanz der <see cref="LoggedOutState"/> Klasse.</summary>
        /// <param name="loginState">Der vorherige LoginStatus.</param>
        protected BaseLoginState(ILoginState loginState)
        {
            Login = loginState.Login;
            EPostSessionContext = loginState.EPostSessionContext;
        }

        #endregion

        #region Public Properties

        /// <summary>Liest oder setzt EPostSessionContext.</summary>
        public IEPostSessionContext EPostSessionContext { get; set; }

        /// <summary>Liest oder setzt einen Wert, der das OK signalisiert.</summary>
        public bool IsOk { get; protected set; }

        /// <summary>
        /// Der aktuelle Login Status.
        /// </summary>
        public LoginStatus LoginStatus { get; protected set; }

        /// <summary>
        /// Der Login, der die entsprechenden Login-Methoden implementiert.
        /// </summary>
        public ILogin Login { get; set; }

        #endregion

        #region Public Methods and Operators

        /// <summary>
        /// Der Benutzer wird mit den hinterlegten Zugangsdaten im niedrigen Authentifizierungs-Niveau angemeldet.
        /// Sollte er sich im hohen Authentifizierungs-Niveau befinden wird er auf jeden Fall abgemeldet und ins niedrige Authentifizierungs-Niveau befördert.
        /// </summary>
        public abstract void ForceLoginLow();

        /// <summary>Meldet den eventuell angemeldeten Benutzer ab.</summary>
        public virtual void GoToLoggedOutState()
        {
            Logout();
        }

        /// <summary>Der Benutzer wird aufgefordert, die Zugangsdaten im hohen Authentifizierungs-Niveau in einem Browserfenster anzugeben.</summary>
        public abstract void GoToLoggedInHighStateWithBrowserAuthentication();

        /// <summary>Der Benutzer wird aufgefordert, die Zugangsdaten im hohen Authentifizierungs-Niveau in einem Browserfenster anzugeben.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die Interaktionen angezeigt werden.</param>
        public abstract void GoToLoggedInHighStateWithBrowserAuthentication(WebBrowser browser);

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im hohen Authentifizierungs-Niveau angemeldet.</summary>
        public abstract void GoToLoggedInHighStateWithCredentialManagerAuthentication();

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten angemeldet.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die HandyTAN eingegeben werden muss.</param>
        public abstract void GoToLoggedInHighStateWithCredentialManagerAuthentication(WebBrowser browser);

        /// <summary>
        /// Der Benutzer wird mit den hinterlegten Zugangsdaten im niedrigen Authentifizierungs-Niveau angemeldet.
        /// Sollte er sich im hohen Authentifizierungs-Niveau befinden bleibt er dort.
        /// </summary>
        public abstract void GoToLoggedInLowState();

        #endregion

        #region Methods

        /// <summary>Erhöht das Authentifizierungs-Niveau, um das Versenden von elektronischen E-POSTBRIEFEN zu ermöglichen.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die Interaktionen angezeigt werden.</param>
        protected void LoginExtensionSendLetter(WebBrowser browser)
        {
            DoWorkStatusChanged(WorkStatus.ExtendScopeBegin);
            try
            {
                Login.LoginExtensionSendLetter(browser);
                IsOk = Login.IsOk;
                if (IsOk)
                {
                    EPostSessionContext.LoginStateMachine = new LoggedInHighState(this);
                }
            }
            finally
            {
                DoWorkStatusChanged(WorkStatus.ExtendScopeEnd);
            }
        }

        /// <summary>Der Benutzer wird aufgefordert, die Zugangsdaten in einem Browserfenster anzugeben.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die Interaktionen angezeigt werden.</param>
        protected void LoginWithBrowserAuthentication(WebBrowser browser)
        {
            this.DoLogin(browser, true);
            if (IsOk)
            {
                EPostSessionContext.LoginStateMachine = new LoggedInHighState(this);
            }
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten angemeldet.</summary>
        protected void LoginWithCredentialManagerAuthentication()
        {
            this.DoLogin(null, false);
            if (IsOk)
            {
                EPostSessionContext.LoginStateMachine = new LoggedInLowState(this);
            }
        }

        /// <summary>Meldet den eventuell angemeldeten Benutzer ab.</summary>
        protected void Logout()
        {
            DoWorkStatusChanged(WorkStatus.LogoutBegin);
            try
            {
                var logout = new Logout { AccessToken = Login.AccessToken, SystemType = Login.SystemType, ThirdSystemUrl = Login.ThirdSystemUrl };
                logout.LogOut();
                EPostSessionContext.LoginStateMachine = new LoggedOutState(this);
            }
            catch (Exception)
            {
                // falls das nicht geklappt hat, setzen wir den Status hart:
                EPostSessionContext.LoginStateMachine = new LoggedOutState(this);
            }
            finally
            {
                DoWorkStatusChanged(WorkStatus.LogoutEnd);
            }
        }

        /// <summary>Erneuert ein eventuell abgelaufenes Access Token in den hohen Modus.</summary>
        protected void RefreshAccessTokenHigh()
        {
            RefreshAccessToken();
            if (IsOk)
            {
                EPostSessionContext.LoginStateMachine = new LoggedInHighState(this);
            }
        }

        /// <summary>Erneuert ein eventuell abgelaufenes Access Token in den hohen Modus.</summary>
        protected void RefreshAccessTokenLow()
        {
            RefreshAccessToken();
            if (IsOk)
            {
                EPostSessionContext.LoginStateMachine = new LoggedInLowState(this);
            }
        }

        /// <summary>The do login.</summary>
        /// <param name="browser">The browser.</param>
        /// <param name="enterPasswordInHtmlPage">INdicates to enter the password in a html page.</param>
        private void DoLogin(WebBrowser browser, bool enterPasswordInHtmlPage)
        {
            DoWorkStatusChanged(WorkStatus.LoginBegin);

            try
            {
                Login.InternalLogin(browser, enterPasswordInHtmlPage);
            }
            finally
            {
                IsOk = Login.IsOk;

                DoWorkStatusChanged(WorkStatus.LoginEnd);
            }
        }

        /// <summary>Der Do Work Status Changed.</summary>
        /// <param name="workStatus">Der Beginn des Logouts.</param>
        private void DoWorkStatusChanged(WorkStatus workStatus)
        {
            var worker = EPostSessionContext as IWorkStatusChanger;
            if (worker != null)
            {
                worker.DoWorkStatusChanged(workStatus);
            }
        }

        /// <summary>Erneuert ein eventuell abgelaufenes AccessToken.</summary>
        private void RefreshAccessToken()
        {
            DoWorkStatusChanged(WorkStatus.RefreshLoginBegin);
            try
            {
                var refresh = new Refresh
                                  {
                                      AccessTokenToBeRefreshed = Login.AccessToken, 
                                      ClientId = Login.ClientId, 
                                      LifContent = Login.LifContent, 
                                      SystemType = Login.SystemType,
                                      ThirdSystemUrl = Login.ThirdSystemUrl
                                  };
                refresh.RefreshAccessToken();
                IsOk = refresh.IsOk;
                if (IsOk)
                {
                    Login.AccessToken = refresh.AccessToken;
                }
            }
            finally
            {
                DoWorkStatusChanged(WorkStatus.RefreshLoginEnd);
            }
        }

        #endregion
    }
}