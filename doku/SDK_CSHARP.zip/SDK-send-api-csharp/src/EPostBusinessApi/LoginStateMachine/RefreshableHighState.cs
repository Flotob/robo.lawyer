﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EPostBusinessApi.LoginStateMachine
{
    using IEPostBusinessApi;
    using IEPostBusinessApi.LoginStateMachine;

    /// <summary>
    /// Der Status, in dem ein Refresh ins hohe Authentifizierungs-Niveau möglich ist.
    /// </summary>
    public class RefreshableHighState : BaseLoginState
    {
        /// <summary>Initialisiert eine neue Instanz der <see cref="LoggedOutState"/> Klasse.</summary>
        /// <param name="loginState">Der vorherige LoginStatus.</param>
        public RefreshableHighState(ILoginState loginState)
            : base(loginState)
        {
            // RefreshableHigh 5 min
            ((EPostSession)loginState.EPostSessionContext).StartTimerRefreshHigh();

            LoginStatus = LoginStatus.RefreshableHigh;
        }

        /// <summary>Der Benutzer wird aufgefordert, die Zugangsdaten im hohen Authentifizierungs-Niveau in einem Browserfenster anzugeben.</summary>
        public override void GoToLoggedInHighStateWithBrowserAuthentication()
        {
            this.GoToLoggedInHighStateWithBrowserAuthentication(null);
        }

        /// <summary>Der Benutzer wird aufgefordert, die Zugangsdaten im hohen Authentifizierungs-Niveau in einem Browserfenster anzugeben.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die Interaktionen angezeigt werden.</param>
        public override void GoToLoggedInHighStateWithBrowserAuthentication(System.Windows.Controls.WebBrowser browser)
        {
            try
            {
                RefreshAccessTokenHigh();
            }
            catch (Exception)
            {
                EPostSessionContext.LoginStateMachine = new LoggedOutState(this);
                throw;
            }
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im hohen Authentifizierungs-Niveau angemeldet.</summary>
        public override void GoToLoggedInHighStateWithCredentialManagerAuthentication()
        {
            this.GoToLoggedInHighStateWithCredentialManagerAuthentication(null);
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten angemeldet.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die HandyTAN eingegeben werden muss.</param>
        public override void GoToLoggedInHighStateWithCredentialManagerAuthentication(System.Windows.Controls.WebBrowser browser)
        {
            try
            {
                RefreshAccessTokenHigh();
            }
            catch (Exception)
            {
                EPostSessionContext.LoginStateMachine = new LoggedOutState(this);
                throw;
            }
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im niedrigen Authentifizierungs-Niveau angemeldet.
        /// Sollte er sich im hohen Authentifizierungs-Niveau befinden, bleibt er dort.</summary>
        public override void GoToLoggedInLowState()
        {
            try
            {
                RefreshAccessTokenHigh();
            }
            catch (Exception)
            {
                EPostSessionContext.LoginStateMachine = new LoggedOutState(this);
                throw;
            }
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten im niedrigen Authentifizierungs-Niveau angemeldet.
        /// Sollte er sich im hohen Authentifizierungs-Niveau befinden, wird er auf jeden Fall abgemeldet und ins niedrige Authentifizierungs-Niveau befördert.</summary>
        public override void ForceLoginLow()
        {
            // Es gibt keinen direkten weg vom hohen Authentifizierungs-Niveau in das niedrige Authentifizierungs-Niveau.
            // Deshalb erst mal ausloggen.
            // Dort wird dann auch der ausgeloggte Status gesetzt.
            Logout();

            // Der ausgeloggte Status, der darauf aktiv ist, weiß, wie man in das niedrige Authentifizierungs-Niveau gelangt.
            EPostSessionContext.LoginStateMachine.GoToLoggedInLowState();
        }
    }
}
