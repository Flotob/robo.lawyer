﻿namespace EPostBusinessApi
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net;
    using System.Web;

    using EPostBusinessApi.Properties;
    using EPostBusinessApi.Status;

    using IEPostBusinessApi.EPostException;
    using IEPostBusinessApi.JSON.Access;
    using IEPostBusinessApi.JSON.Error;

    /// <summary>Diese Klasse dient dazu, das Authentifizierungs-Niveau zu erhöhen, um auch elektronische E-POSTBRIEFE versenden zu können.</summary>
    internal class Extension : ApiBaseRequest
    {
        #region Constants

        /// <summary>Der Name dieser Klasse zu Zwecken der Fehlerbehandlung.</summary>
        private const string ClassName = "EPostSession";

        #endregion

        #region Properties

        /// <summary>
        /// Diese Uri enthält den Verweis auf die HandyTAN Eingabe.
        /// </summary>
        internal Uri MTanUri { get; set; }

        /// <summary>
        /// Dieser String enthält den Cookie, den man beim Aufrufen der HandyTAN Maske setzen muss.
        /// </summary>
        internal string Cookie { get; set; }

        /// <summary>Liest oder setzt AccessToken.</summary>
        internal AccessTokenResponse AccessToken { get; set; }

        /// <summary>
        /// Ein beliebiger String, der die Client-Applikation identifiziert.
        /// HINWEIS
        /// Die client_id ergibt sich aus DevIdund AppId, die Sie
        /// bei der Registrierung für E‑POSTBUSINESS API ange-ben. Die Bildungsvorschrift der client_iderfolgt auf fol-gende
        /// Weise:
        /// ▪ clientid = devid "," appid
        /// </summary>
        internal string ClientId { get; set; }

        /// <summary>Liest ResponseType.</summary>
        internal string ResponseType
        {
            get
            {
                return Settings.Default.ResponseType;
            }
        }

        /// <summary>Liest Scope.</summary>
        internal string Scope
        {
            get
            {
                return IEPostBusinessApi.Scope.send_letter.ToString("f");
            }
        }

        /// <summary>
        /// Ein beliebiger String von maximal 512 Zeichen Länge, der den
        /// Zustand der Applikation beschreibt. Der Wert wird der Applikation im Login-Ergebnis zurückgegeben. Hier kann z. B.
        /// eine Session-ID durchgereicht werden.
        /// </summary>
        internal string State { get; set; }

        /// <summary>Liest ContentType.</summary>
        protected override string ContentType
        {
            get
            {
                return Settings.Default.Login_ContentType;
            }
        }

        /// <summary>Liest Method.</summary>
        protected override string Method
        {
            get
            {
                return Settings.Default.Method_POST;
            }
        }

        /// <summary>Liest MimeType.</summary>
        protected override string MimeType
        {
            get
            {
                return string.Empty;
            }
        }

        /// <summary>Liest OkStatusCode.</summary>
        protected override HttpStatusCode OkStatusCode
        {
            get
            {
                return HttpStatusCode.Found;
            }
        }

        /// <summary>Liest RequestHeader.</summary>
        protected override List<string> RequestHeader
        {
            get
            {
                return null;
            }
        }

        /// <summary>Liest Url.</summary>
        protected override Uri Url
        {
            get
            {
                return new Uri(CreateLoginExtensionUrl());
            }
        }

        #endregion

        #region Methods

        /// <summary>Erhöht das Authentifizierungs-Niveau, um auch elektronische E-POSTBRIEFE versenden zu können.</summary>
        /// <exception cref="EPostBusinessApiException">Im Fehlerfall wird eine EPostBusinessApiException geworfen.</exception>
        internal KeyValuePair<Type, object> Extend()
        {
            if (AccessToken == null)
            {
                Error = CreateErrorResponse("access_token_null", "Access Token is null", null);
                throw new EPostBusinessApiException("Access Token is null", ClassName, 999, Error);
            }

            var result = DoRequest();
            
            // Falls es nicht OK war: Fehler
            if (!IsOk)
            {
                if (result.Key == typeof(ErrorResponse))
                {
                    Error = result.Value as ErrorResponse;
                }
                else if (result.Key == typeof(ErrorDetail))
                {
                    var detail = result.Value as ErrorDetail;
                    if (detail != null)
                    {
                        Error = new ErrorResponse
                                         {
                                             Error = string.Empty, 
                                             ErrorDescription = detail.Description, 
                                             ErrorDetails = new List<ErrorDetail> { detail }
                                         };
                    }
                }
                else
                {
                    Error = CreateErrorResponse("could_not_get_result", "Could not get result", null);
                }

                throw new EPostBusinessApiException("Could not get result", ClassName, (int)StatusCode, Error);
            }

            // Falls es OK war, result zurück geben
            return result;
        }

        /// <summary>Liefert das Format des zurückgegebenen Bodies aus dem HttpStatusCode.</summary>
        /// <param name="statusCode">HttpStatusCode</param>
        /// <returns>BodyFormat</returns>
        protected override BodyFormat GetBodyFormat(HttpStatusCode statusCode)
        {
            switch (statusCode)
            {
                case HttpStatusCode.OK:
                    return BodyFormat.JsonAccessToken;
                case HttpStatusCode.BadRequest:
                case HttpStatusCode.UnsupportedMediaType:
                case HttpStatusCode.Found:
                    return BodyFormat.JsonError;
                case HttpStatusCode.NotFound:
                case HttpStatusCode.MethodNotAllowed:
                case HttpStatusCode.RequestEntityTooLarge:
                case HttpStatusCode.InternalServerError:
                    return BodyFormat.NothingError;
                default:
                    return BodyFormat.NothingUndefined;
            }
        }

        /// <summary>Schreibt den Request.</summary>
        /// <param name="writer">Der writer.</param>
        protected override void WriteRequestStream(StreamWriter writer)
        {
            writer.Write(CreateLoginExtensionBody());
        }

        /// <summary>Erzeugt den benötigen Body für den Request.</summary>
        /// <returns>Der Body als <see cref="string" />.</returns>
        private string CreateLoginExtensionBody()
        {
            // response_type={0}&client_id={1}&state={2}&scope={3}&redirect_uri={4}&access_token={5}
            var body = string.Format(
                Settings.Default.LoginExtensionBody, 
                HttpUtility.UrlEncode(ResponseType), 
                HttpUtility.UrlEncode(ClientId), 
                HttpUtility.UrlEncode(State), 
                HttpUtility.UrlEncode(Scope), 
                HttpUtility.UrlEncode(RedirectUri.AbsoluteUri), 
                HttpUtility.UrlEncode(AccessToken.AccessToken));
            return body;
        }

        /// <summary>Erzeugt die benötigte URL.</summary>
        /// <returns>Die URL als <see cref="string" />.</returns>
        private string CreateLoginExtensionUrl()
        {
            // https://login.{0}/oauth2/auth/extension
            var urlRequest = string.Format(Settings.Default.LoginExtension, GetSystem());
            return urlRequest;
        }

        #endregion
    }
}