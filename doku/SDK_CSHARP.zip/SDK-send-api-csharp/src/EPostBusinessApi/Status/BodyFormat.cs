﻿namespace EPostBusinessApi.Status
{
    /// <summary>
    /// Die Klasse gibt das Format des zurückgegebenen Bodys an.
    /// </summary>
    public enum BodyFormat
    {
        /// <summary>
        /// Bytes, z. B. Vorschau auf das PDF-Dokument.
        /// </summary>
        Bytes, 

        /// <summary>
        /// Kein Format, mit Fehler.
        /// </summary>
        NothingError, 

        /// <summary>
        /// Kein Format, ohne Fehler.
        /// </summary>
        NothingOk, 

        /// <summary>
        /// Kein Format, undefiniert.
        /// </summary>
        NothingUndefined, 

        /// <summary>
        /// JSON mit ausführlicher Fehlerbeschreibung.
        /// </summary>
        JsonError, 

        /// <summary>
        /// JSON mit kompakter Fehlerbeschreibung.
        /// </summary>
        JsonErrorOnlyDescription, 

        /// <summary>
        /// JSON mit Preisinformation.
        /// </summary>
        JsonPostageInfo, 

        /// <summary>
        /// JSON mit dem Access Token.
        /// </summary>
        JsonAccessToken, 

        /// <summary>
        /// JSON mit den Informationen zu einem gespeicherten Entwurf.
        /// </summary>
        JsonSaveDraft
    }
}