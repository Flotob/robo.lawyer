﻿namespace EPostBusinessApi.Status
{
    using System.Net;

    /// <summary>
    /// Hilfsklasse zur Auswertung der Statuscodes.
    /// </summary>
    public static class PreviewStatusCodes
    {
        #region Public Methods and Operators

        /// <summary>Liefert das Format des zurückgegebenen Bodies aus dem HttpStatusCode.</summary>
        /// <param name="statusCode">HttpStatusCode</param>
        /// <returns>BodyFormat</returns>
        public static BodyFormat GetBodyFormat(HttpStatusCode statusCode)
        {
            switch (statusCode)
            {
                case HttpStatusCode.OK:
                    return BodyFormat.Bytes;
                case HttpStatusCode.BadRequest:
                case HttpStatusCode.Unauthorized:
                case HttpStatusCode.Forbidden:
                case HttpStatusCode.NotAcceptable:
                    return BodyFormat.JsonError;
                case HttpStatusCode.NotFound:
                case HttpStatusCode.MethodNotAllowed:
                case HttpStatusCode.RequestEntityTooLarge:
                case HttpStatusCode.UnsupportedMediaType:
                case HttpStatusCode.InternalServerError:
                    return BodyFormat.NothingError;
                default:
                    return BodyFormat.NothingUndefined;
            }
        }

        #endregion
    }
}