namespace EPostBusinessApi.Status
{
    using System;
    using System.Collections.Generic;

    using IEPostBusinessApi.JSON.Access;
    using IEPostBusinessApi.JSON.Draft;
    using IEPostBusinessApi.JSON.Error;
    using IEPostBusinessApi.JSON.Postage;

    /// <summary>Diese Klasse definiert das Mapping zwischen dem BodyFormat und dem Typ des JSON-Objekts.</summary>
    public static class JsonBodyFormatMapping
    {
        #region Static Fields

        /// <summary>Das Mapping.</summary>
        private static readonly Dictionary<BodyFormat, Type> Mapping;

        #endregion

        #region Constructors and Destructors

        /// <summary>Initialisiert statische Member der <see cref="JsonBodyFormatMapping" /> Klasse.</summary>
        static JsonBodyFormatMapping()
        {
            Mapping = new Dictionary<BodyFormat, Type>
                          {
                              { BodyFormat.Bytes, typeof(byte[]) }, 
                              { BodyFormat.JsonAccessToken, typeof(AccessTokenResponse) }, 
                              { BodyFormat.JsonSaveDraft, typeof(CreateDraftResponse) }, 
                              { BodyFormat.JsonError, typeof(ErrorResponse) }, 
                              { BodyFormat.JsonErrorOnlyDescription, typeof(ErrorDetail) }, 
                              { BodyFormat.JsonPostageInfo, typeof(PostageInfoResponse) }, 
                              { BodyFormat.NothingError, typeof(ErrorResponse) }, 
                              { BodyFormat.NothingOk, null }, 
                              { BodyFormat.NothingUndefined, null }
                          };
        }

        #endregion

        #region Methods

        /// <summary>Liefert den Typ auf Grund des BodyFormats.</summary>
        /// <param name="bodyFormat">Das BodyFormat.</param>
        /// <returns>Der <see cref="Type"/>.</returns>
        internal static Type GetTypeFromBodyFormat(BodyFormat bodyFormat)
        {
            try
            {
                return Mapping[bodyFormat];
            }
            catch (Exception)
            {
                return null;
            }
        }

        #endregion
    }
}