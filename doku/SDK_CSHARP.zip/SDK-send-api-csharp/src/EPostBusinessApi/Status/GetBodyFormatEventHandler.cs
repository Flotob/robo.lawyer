namespace EPostBusinessApi.Status
{
    using System.Net;

    /// <summary>Die Klasse liefert das BodyFormat auf Grund des HttpStatusCodes zur�ck.</summary>
    /// <param name="statusCode">Der HttpStatusCode.</param>
    /// <returns>BodyFormat.</returns>
    public delegate BodyFormat GetBodyFormatEventHandler(HttpStatusCode statusCode);
}