﻿namespace EPostBusinessApi
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net;
    using System.Text;
    using System.Web;

    using EPostBusinessApi.Properties;
    using EPostBusinessApi.Status;

    using IEPostBusinessApi;
    using IEPostBusinessApi.JSON.Error;

    using Newtonsoft.Json;

    /// <summary>
    /// Der ApiBaseRequest ist die Basisklasse für alle JSON-Requests auf die E-POST API. Von ihr werden die
    /// entsprechenden Requests abgeleitet.
    /// </summary>
    public abstract class ApiBaseRequest
    {
        #region Constructors and Destructors

        /// <summary>
        /// Initialisiert eine neue Instanz der <see cref="ApiBaseRequest" /> Klasse.
        /// </summary>
        protected ApiBaseRequest()
        {
            Boundary = null;
        }

        #endregion

        #region Public Properties

        /// <summary>Liest oder setzt Error.</summary>
        public ErrorResponse Error { get; protected set; }

        /// <summary>
        /// Diese URL wird als Zielsystem angenommen, wenn ein drittes System angesprochen werden sollte und ThirdSystem gewählt wurde.
        /// </summary>
        public string ThirdSystemUrl { get; set; }

        /// <summary>
        /// Die URI, an welche das Login-Ergebnis geleitet wird. Die
        /// <em><redirect_uri</em> muss dem E‑POST System bekannt sein. Die finale vom System erzeugte <em>redirect_uri</em> darf nicht länger als
        /// 2083 Zeichen sein, inklusive Protokollangabe und weiterer Parameter, andernfalls kommt es zu einem
        /// Darstellungsproblem
        /// sowohl beim Browser als auch beim Server.
        /// </summary>
        public Uri RedirectUri { get; set; }

        /// <summary>
        /// Angabe des zu verwendenden Systems:
        /// <ul>
        ///     <li>Integrations- und Testumgebung (ITU)</li>
        ///     <li>Produktionsumgebung (PROD)</li>
        /// </ul>
        /// </summary>
        public SystemType SystemType { get; set; }

        #endregion

        #region Properties

        /// <summary>Liest Boundary.</summary>
        protected string Boundary { get; private set; }

        /// <summary>Liest BoundaryBegin.</summary>
        protected string BoundaryBegin
        {
            get
            {
                return new StringBuilder(Settings.Default.BoundaryBegin).Append(Boundary).ToString();
            }
        }

        /// <summary>Liest BoundaryEnd.</summary>
        protected string BoundaryEnd
        {
            get
            {
                return new StringBuilder(BoundaryBegin).Append(Settings.Default.BoundaryEnd).ToString();
            }
        }

        /// <summary>Liest ContentType.</summary>
        protected abstract string ContentType { get; }

        /// <summary>Liest ContentTypeFileTemplate.</summary>
        protected virtual string ContentTypeFileTemplate
        {
            get
            {
                return Settings.Default.ApiBaseRequest_ContentTypeFileTemplate;
            }
        }

        protected virtual string HtmlContentMimeType
        {
            get
            {
                return Settings.Default.HtmlContentMimeType;
            }
        }

        /// <summary>Liest ContentTypeTemplate.</summary>
        protected string ContentTypeTemplate
        {
            get
            {
                return Settings.Default.ApiBaseRequest_ContentTypeTemplate;
            }
        }

        /// <summary>Liest oder setzt einen Wert, der das OK signalisiert.</summary>
        public bool IsOk { get; protected set; }

        /// <summary>Liest Method.</summary>
        protected abstract string Method { get; }

        /// <summary>Liest MimeType.</summary>
        protected abstract string MimeType { get; }

        /// <summary>Liest OkStatusCode.</summary>
        protected abstract HttpStatusCode OkStatusCode { get; }

        /// <summary>Liest RequestHeader.</summary>
        protected abstract List<string> RequestHeader { get; }

        /// <summary>Liest oder setzt StatusCode.</summary>
        protected internal HttpStatusCode StatusCode { get; set; }

        /// <summary>Liest Url.</summary>
        protected abstract Uri Url { get; }

        #endregion

        #region Methods

        /// <summary>Liefert das DateTime Objekt zurück.</summary>
        /// <param name="dateTime">DateTime.</param>
        /// <returns>Das <see cref="DateTime"/> Objekt.</returns>
        internal static DateTime GetDateTimeObject(DateTime dateTime)
        {
            return new DateTime(
                dateTime.Year, 
                dateTime.Month, 
                dateTime.Day, 
                dateTime.Hour, 
                dateTime.Minute, 
                dateTime.Second, 
                DateTimeKind.Local);
        }

        /// <summary>Erzeugt eine ErrorResponse.</summary>
        /// <param name="error">Der error.</param>
        /// <param name="errorDescription">Die errorDescription.</param>
        /// <param name="errorCode">Der errorCode.</param>
        /// <returns>Die <see cref="ErrorResponse"/>.</returns>
        protected internal static ErrorResponse CreateErrorResponse(string error, string errorDescription, string errorCode)
        {
            var errorResponse = new ErrorResponse
                                    {
                                        Error = error, 
                                        ErrorDescription = errorDescription, 
                                        ErrorDetails = new List<ErrorDetail> { new ErrorDetail() }
                                    };
            if (errorCode != null)
            {
                errorResponse.ErrorDetails[0].Description = errorDescription;
                errorResponse.ErrorDetails[0].ErrorCode = errorCode;
            }

            return errorResponse;
        }

        /// <summary>Diese Methode führt den eigentlichen Request durch.
        /// Sie wird von den einzelnen Klassen, die darauf den Request implementieren, überschrieben.</summary>
        /// <returns>
        /// Das <see><cref>KeyValuePair</cref></see>.
        /// </returns>
        protected KeyValuePair<Type, object> DoRequest()
        {
            var retValue = new KeyValuePair<Type, object>();
            try
            {
                try
                {
                    // Neue Boundary erzeugen
                    UpdateBoundary();

                    var request = WebRequest.Create(Url.AbsoluteUri) as HttpWebRequest;
                    if (request != null)
                    {
                        request.Method = Method;
                        AddHeaders(request.Headers);
                        request.ContentType = ContentType;
                        request.AllowAutoRedirect = false;

                        using (var stream = request.GetRequestStream())
                        using (var writer = new StreamWriter(stream))
                        {
                            writer.AutoFlush = true;
                            WriteRequestStream(writer);
                        }

                        using (var response = request.GetResponse() as HttpWebResponse)
                        {
                            retValue = ParseResponse(response);
                        }
                    }
                }
                catch (WebException we)
                {
                    Console.WriteLine(we.Message);
                    var wr = we.Response as HttpWebResponse;
                    retValue = ParseResponse(wr);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                IsOk = false;
                retValue = new KeyValuePair<Type, object>(
                    typeof(ErrorResponse), 
                    CreateErrorResponse(e.Message, e.Message, null));
            }

            return retValue;
        }

        /// <summary>Liefert das Format des zurückgegebenen Bodies aus dem HttpStatusCode.</summary>
        /// <param name="statusCode">HttpStatusCode</param>
        /// <returns>BodyFormat</returns>
        protected abstract BodyFormat GetBodyFormat(HttpStatusCode statusCode);

        /// <summary>Liefert das aktuell eingestellte System.</summary>
        /// <returns>Das aktuelle System als <see cref="string" />.</returns>
        protected string GetSystem()
        {
            switch (SystemType)
            {
                case SystemType.Prod:
                    return Settings.Default.PRODServer;
                case SystemType.ThirdSystem:
                    return ThirdSystemUrl;
                default:
                    return Settings.Default.ITUServer;
            }
        }

        /// <summary>Parst die Response um den Typ der Repsonse herauszufinden.</summary>
        /// <param name="response">Die HttpWebResponse.</param>
        /// <returns>Das<see>
        ///     <cref>KeyValuePair</cref>
        /// </see>
        /// .</returns>
        protected KeyValuePair<Type, object> ParseResponse(HttpWebResponse response)
        {
            if (response == null)
            {
                return new KeyValuePair<Type, object>();
            }

            StatusCode = response.StatusCode;

            // Hier wird ein redirect abgefangen, dass ggf. in der URL Fehlermeldungen enthält
            // Es wird eine entsprechendes ErrorObjekt  zusammengebaut.
            // Es kann aber auch sein, dass es kein Error war, sondern der redirect zur HandyTAN Eingabe
            // die erkennen wir daran, dass wir ein entsprechendes redirect haben
            if (response.StatusCode == HttpStatusCode.Found)
            {
                // Die in location zurück bekommen redirect uri
                var redirectUri = HttpUtility.UrlDecode(response.Headers["Location"]);

                // Die Parameter innerhalb der redirect uri.
                var parameters = HttpUtility.ParseQueryString(response.Headers["Location"]);

                // Aus den Parametern versuchen wir ein Error Objekt zu erstellen,
                // dass die Fehlermeldungen erhält
                // Das kann aber auch in den Parametern null sein.
                Error = new ErrorResponse
                            {
                                Error = parameters[RedirectUri + "?error"],
                                ErrorDescription = parameters["error_description"],
                                ErrorUri = parameters["error_uri"]
                            };

                // Das Error Objekt ist in  den Parametren null und die redirect uri stimmt nicht mit unseren überein
                // Dann war es ein redirect auf die HandyTAN Abfrage
                if (Error.Error == null && Error.ErrorDescription == null && Error.ErrorUri == null
                    && !redirectUri.StartsWith(RedirectUri.AbsoluteUri))
                {
                    IsOk = true;

                    // Hier schauen wir nach, ob Cookies vorhanden sind.
                    // Falls ja, wird die CookieCollection erstellt.
                    CookieCollection cookieCollection = null;
                    var cookieHeader = response.Headers["Set-Cookie"];

                    if (!string.IsNullOrEmpty(cookieHeader))
                    {
                        var uriRedirectUri = new Uri(redirectUri);
                        var cookieContainer = new CookieContainer();
                        cookieContainer.SetCookies(uriRedirectUri, cookieHeader);

                        cookieCollection = cookieContainer.GetCookies(uriRedirectUri);
                    }

                    // redirect uri und cookies werden zurückgeliefert.
                    return new KeyValuePair<Type, object>(
                        typeof(Redirect), new Redirect { Uri = new Uri(redirectUri), Cookies = cookieCollection });
                }

                // Ansonsten war es ein Fehler
                return new KeyValuePair<Type, object>(typeof(ErrorResponse), Error);
            }

            IsOk = StatusCode == OkStatusCode;
            var bodyFormat = GetBodyFormat(StatusCode);
            var jsonType = JsonBodyFormatMapping.GetTypeFromBodyFormat(bodyFormat);
            var stream = response.GetResponseStream();
            object json = null;
            if (stream != null)
            {
                var content = new StreamReader(stream).ReadToEnd();
                json = JsonConvert.DeserializeObject(content, jsonType);
            }

            var retValue = new KeyValuePair<Type, object>(jsonType, json);

            return retValue;
        }

        /// <summary>Schreibt das JSON-Objekt und die Dateianhänge in den entsprechenden <em>writer</em>.</summary>
        /// <param name="writer">Der writer.</param>
        /// <param name="json">Das JSON-Objekt.</param>
        /// <param name="htmlBody">Der Aschreibentext.</param>
        /// <param name="files">Die Liste der Dateien, die angehängt werden sollen.</param>
        protected void WriteJsonAndFilesToRequestStream(StreamWriter writer, object json, string htmlBody, List<FileInfo> files)
        {
            // Boundary rausschreiben
            writer.WriteLine(BoundaryBegin);

            // Content-Type für JSON rausschreiben
            writer.WriteLine(ContentTypeTemplate, MimeType);
            writer.WriteLine(string.Empty);

            // JSON rausschreiben
            writer.WriteLine(JsonConvert.SerializeObject(json, Formatting.Indented));
            writer.WriteLine(string.Empty);
            writer.WriteLine(string.Empty);

            // HtmlBody rausschreiben, falls vorhanden
            if(!string.IsNullOrEmpty(htmlBody))
            {
                // Boundary rausschreiben
                writer.WriteLine(BoundaryBegin);

                // Content-Type rausschreiben
                writer.WriteLine(HtmlContentMimeType);
                writer.WriteLine(string.Empty);

                // Body rausschreiben
                writer.WriteLine(htmlBody);
                writer.WriteLine(string.Empty);
                writer.WriteLine(string.Empty);
            }

            // Dateien rausschreiben
            if (files != null)
            {
                foreach (var file in files)
                {
                    // Boundary rausschreiben
                    writer.WriteLine(BoundaryBegin);

                    // Content-Type rausschreiben
                    var extension = file.Extension.Substring(1);
                    var fileName = file.Name;
                    writer.WriteLine(ContentTypeFileTemplate, extension, fileName);
                    writer.WriteLine(string.Empty);

                    // Datei rausschreiben
                    WriteFile(writer, file);
                }
            }

            // Trailer Boundary rausschreiben
            writer.WriteLine(string.Empty);
            writer.Write(BoundaryEnd);
        }

        /// <summary>Schreibt den Request.</summary>
        /// <param name="writer">Der writer.</param>
        protected abstract void WriteRequestStream(StreamWriter writer);

        /// <summary>Schreibt die Datei.</summary>
        /// <param name="writer">Der writer.</param>
        /// <param name="file">Die Datei.</param>
        private static void WriteFile(StreamWriter writer, FileSystemInfo file)
        {
            if (file == null)
            {
                throw new ArgumentNullException("file");
            }

            var bytes = File.ReadAllBytes(file.FullName);
            writer.BaseStream.Write(bytes, 0, bytes.Length);
        }

        /// <summary>Fügt dem Request die gewünschten Header hinzu.</summary>
        /// <param name="headers">Die hinzuzufügenden Header.</param>
        private void AddHeaders(WebHeaderCollection headers)
        {
            if (RequestHeader == null)
            {
                return;
            }

            foreach (var requestHead in RequestHeader)
            {
                headers.Add(requestHead);
            }
        }

        /// <summary>Erstellt die benötigte Boundary.</summary>
        private void UpdateBoundary()
        {
            Boundary = Settings.Default.BoundaryPrefix + DateTime.Now.Ticks.ToString("x");
        }

        #endregion
    }
}