﻿namespace EPostBusinessApi
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net;
    using System.Text;
    using System.Web;

    using EPostBusinessApi.Properties;
    using EPostBusinessApi.Status;

    using IEPostBusinessApi.EPostException;
    using IEPostBusinessApi.JSON.Access;
    using IEPostBusinessApi.JSON.Error;

    /// <summary>Diese Klasse erneuert ein eventuell abgelaufenes AccessToken.</summary>
    internal class Refresh : ApiBaseRequest
    {
        #region Constants

        /// <summary>Der Name dieser Klasse zu Zwecken der Fehlerbehandlung.</summary>
        private const string ClassName = "EPostSession";

        #endregion

        #region Properties

        /// <summary>Liest AccessToken.</summary>
        internal AccessTokenResponse AccessToken { get; private set; }

        /// <summary>Liest oder setzt AccessTokenToBeRefreshed.</summary>
        internal AccessTokenResponse AccessTokenToBeRefreshed { get; set; }

        /// <summary>
        /// Ein beliebiger String, der die Client-Applikation identifiziert.
        /// HINWEIS
        /// Die client_idergibt sich aus DevIdund AppId, die Sie
        /// bei der Registrierung für E‑POSTBUSINESS API ange-ben. Die Bildungsvorschrift der client_iderfolgt auf fol-gende
        /// Weise:
        /// ▪ clientid = devid "," appid
        /// </summary>
        internal string ClientId { get; set; }

        /// <summary>
        /// Die zu verwendende Lif-Datei.
        /// </summary>
        internal string LifContent { get; set; }

        /// <summary>Liest ContentType.</summary>
        protected override string ContentType
        {
            get
            {
                return Settings.Default.Login_ContentType;
            }
        }

        /// <summary>Liest Method.</summary>
        protected override string Method
        {
            get
            {
                return Settings.Default.Method_POST;
            }
        }

        /// <summary>Liest MimeType.</summary>
        protected override string MimeType
        {
            get
            {
                return string.Empty;
            }
        }

        /// <summary>Liest OkStatusCode.</summary>
        protected override HttpStatusCode OkStatusCode
        {
            get
            {
                return HttpStatusCode.OK;
            }
        }

        /// <summary>Liest RequestHeader.</summary>
        protected override List<string> RequestHeader
        {
            get
            {
                var header = new List<string>
                                 {
                                     string.Format(
                                         Settings.Default.Authorization, 
                                         GetBasicAuthentication())
                                 };
                return header;
            }
        }

        /// <summary>Liest Url.</summary>
        protected override Uri Url
        {
            get
            {
                return new Uri(CreateResourceOwnerPasswordCredentialsGrantUrl());
            }
        }

        #endregion

        #region Methods

        /// <summary>Erneuert ein eventuell abgelaufenes AccessToken.</summary>
        /// <exception cref="EPostBusinessApiException">Im Fehlerfall wird eine EPostBusinessApiException geworfen.</exception>
        internal void RefreshAccessToken()
        {
            var result = DoRequest();
            if (result.Key == typeof(AccessTokenResponse))
            {
                AccessToken = result.Value as AccessTokenResponse;
                return;
            }

            if (result.Key == typeof(ErrorResponse))
            {
                Error = result.Value as ErrorResponse;
            }
            else
            {
                Error = CreateErrorResponse("could_not_get_result", "Could not get result", null);
            }

            throw new EPostBusinessApiException("Could not get result", ClassName, (int)StatusCode, Error);
        }

        /// <summary>Liefert das Format des zurückgegebenen Bodies aus dem HttpStatusCode.</summary>
        /// <param name="statusCode">HttpStatusCode</param>
        /// <returns>BodyFormat</returns>
        protected override BodyFormat GetBodyFormat(HttpStatusCode statusCode)
        {
            switch (statusCode)
            {
                case HttpStatusCode.OK:
                    return BodyFormat.JsonAccessToken;
                case HttpStatusCode.BadRequest:
                case HttpStatusCode.UnsupportedMediaType:
                case HttpStatusCode.Found:
                    return BodyFormat.JsonError;
                case HttpStatusCode.NotFound:
                case HttpStatusCode.MethodNotAllowed:
                case HttpStatusCode.RequestEntityTooLarge:
                case HttpStatusCode.InternalServerError:
                    return BodyFormat.NothingError;
                default:
                    return BodyFormat.NothingUndefined;
            }
        }

        /// <summary>Schreibt den Request.</summary>
        /// <param name="writer">Der writer.</param>
        protected override void WriteRequestStream(StreamWriter writer)
        {
            writer.Write(CreateRefreshBody());
        }

        /// <summary>Erzeugt den RefreshBody.</summary>
        /// <returns>Der RefreshBody als <see cref="string" />.</returns>
        private string CreateRefreshBody()
        {
            // grant_type=refresh_token&refresh_token={0}
            var body = string.Format(Settings.Default.LoginRefreshBody, AccessTokenToBeRefreshed.AccessToken);
            return body;
        }

        /// <summary>Erzeugt die ResourceOwnerPasswordCredentialsGrantUrl.</summary>
        /// <returns>Die ResourceOwnerPasswordCredentialsGrantUrl als <see cref="string" />.</returns>
        private string CreateResourceOwnerPasswordCredentialsGrantUrl()
        {
            // https://login.{0}/oauth2/tokens
            var urlRequest = string.Format(
                Settings.Default.LoginResourceOwnerPasswordCredentialsGrantURL, 
                GetSystem());
            return urlRequest;
        }

        /// <summary>Erzeugt den string zur Basi Authentication.</summary>
        /// <returns>Die Basi Authentication als <see cref="string" />.</returns>
        private string GetBasicAuthentication()
        {
            try
            {
                var authentication = new StringBuilder("Basic ");
                var clientpass = new StringBuilder(HttpUtility.UrlEncode(ClientId));

                clientpass.Append(":").Append(HttpUtility.UrlEncode(LifContent));
                authentication.Append(Convert.ToBase64String(Encoding.ASCII.GetBytes(clientpass.ToString())));

                return authentication.ToString();
            }
                
// ReSharper disable EmptyGeneralCatchClause
            catch (Exception)
// ReSharper restore EmptyGeneralCatchClause
            {
            }

            return null;
        }

        #endregion
    }
}