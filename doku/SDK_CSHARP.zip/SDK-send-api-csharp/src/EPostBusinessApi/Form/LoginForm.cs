﻿using System.Windows.Forms;

namespace EPostBusinessConnect.Form
{
    public partial class LoginForm : System.Windows.Forms.Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        public WebBrowser WebBrowser { get; private set; }
    }
}