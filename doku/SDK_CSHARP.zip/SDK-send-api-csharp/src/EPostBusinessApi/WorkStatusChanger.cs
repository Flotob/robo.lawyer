﻿namespace EPostBusinessApi
{
    using IEPostBusinessApi;

    /// <summary>
    /// Benachrichtig über einen geänderten Arbeitsstatus.
    /// </summary>
    internal interface IWorkStatusChanger
    {
        #region Public Methods and Operators

        /// <summary>Wirft das WorkStatusChangedEvent.</summary>
        /// <param name="workStatus">The work Status.</param>
        void DoWorkStatusChanged(WorkStatus workStatus);

        #endregion
    }
}