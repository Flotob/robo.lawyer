﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EPostBusinessApi
{
    using System.IO;
    using System.Net;
    using System.Windows.Media;

    using EPostBusinessApi.Properties;

    using IEPostBusinessApi;
    using IEPostBusinessApi.JSON.Access;
    using IEPostBusinessApi.JSON.Draft;
    using IEPostBusinessApi.JSON.Error;
    using IEPostBusinessApi.JSON.Folder;

    using Newtonsoft.Json;

    internal class Mailbox
    {
        private AccessTokenResponse AccessTokenResponse { get; set; }

        private SystemType SystemType { get; set; }

        public bool IsOk { get; set; }

        public MailboxError Error { get; set; }

        public Mailbox(AccessTokenResponse accessTokenResponse, SystemType systemType)
        {
            this.AccessTokenResponse = accessTokenResponse;
            this.SystemType = systemType;
        }

        internal Folder GetFolder(MainFolderTypes folderType, int offset, int limit)
        {
            string downloadUrl = string.Format(Settings.Default.MailboxFolderURLOffsetLimit, this.GetSystem(), folderType, offset, limit);

            return GetFolder(downloadUrl);
        }

        internal Folder GetFolder(MainFolderTypes folderType)
        {
            string downloadUrl = string.Format(Settings.Default.MailboxFolderURL, this.GetSystem(), folderType);

            return GetFolder(downloadUrl);
        }

        private Folder GetFolder(string url)
        {
            Folder json = null;
            using (var client = new WebClient())
            {
                client.Headers.Add(string.Format(Settings.Default.XEpostAccessToken, this.AccessTokenResponse.AccessToken));
                try
                {
                    var identityData = client.DownloadData(url);
                    string result = Encoding.UTF8.GetString(identityData);

                    json = JsonConvert.DeserializeObject<Folder>(result);
                }
                catch (WebException we)
                {
                    using (StreamReader reader = new StreamReader(we.Response.GetResponseStream()))
                    {
                        string result = reader.ReadToEnd();
                        Error = JsonConvert.DeserializeObject<MailboxError>(result);
                    }
                }
            }
            return json;
        }

        internal GetLetterResponse GetLetter(string id)
        {
            string url = string.Format(Settings.Default.MailboxLetterURL, this.GetSystem(), id);
            GetLetterResponse json = null;
            using (var client = new WebClient())
            {
                client.Headers.Add(string.Format(Settings.Default.XEpostAccessToken, this.AccessTokenResponse.AccessToken));
                try
                {
                    var identityData = client.DownloadData(url);
                    string result = Encoding.UTF8.GetString(identityData);

                    json = JsonConvert.DeserializeObject<GetLetterResponse>(result);
                }
                catch (WebException we)
                {
                    using (StreamReader reader = new StreamReader(we.Response.GetResponseStream()))
                    {
                        string result = reader.ReadToEnd();
                        Error = JsonConvert.DeserializeObject<MailboxError>(result);
                    }
                }
            }
            return json;
        }

        internal string GetCoverLetter(string id)
        {
            string url = string.Format(Settings.Default.MailboxCoverLetterURL, this.GetSystem(), id);
            using (var client = new WebClient())
            {
                client.Headers.Add(string.Format(Settings.Default.XEpostAccessToken, this.AccessTokenResponse.AccessToken));
                try
                {
                    var identityData = client.DownloadData(url);
                    string result = Encoding.UTF8.GetString(identityData);

                    return result;
                }
                catch (WebException we)
                {
                    using (StreamReader reader = new StreamReader(we.Response.GetResponseStream()))
                    {
                        string result = reader.ReadToEnd();
                        Error = JsonConvert.DeserializeObject<MailboxError>(result);
                    }
                }
            }
            return null;
        }

        internal byte[] GetAttachment(string letterId, string attachmentId)
        {
            string url = string.Format(Settings.Default.MailboxAttachmentURL, this.GetSystem(), letterId, attachmentId);
            using (var client = new WebClient())
            {
                client.Headers.Add(string.Format(Settings.Default.XEpostAccessToken, this.AccessTokenResponse.AccessToken));
                try
                {
                    var identityData = client.DownloadData(url);

                    return identityData;
                }
                catch (WebException we)
                {
                    if (we.Response != null)
                    {
                        using (StreamReader reader = new StreamReader(we.Response.GetResponseStream()))
                        {
                            string result = reader.ReadToEnd();
                            this.Error = JsonConvert.DeserializeObject<MailboxError>(result);
                        }
                    }
                }
            }
            return null;
        }

        /// <summary>Liefert das aktuell eingestellte System.</summary>
        /// <returns>Das aktuelle System als <see cref="string" />.</returns>
        private string GetSystem()
        {
            switch (SystemType)
            {
                case SystemType.Prod:
                    return Settings.Default.PRODServer;
                default:
                    return Settings.Default.ITUServer;
            }
        }
    }
}
