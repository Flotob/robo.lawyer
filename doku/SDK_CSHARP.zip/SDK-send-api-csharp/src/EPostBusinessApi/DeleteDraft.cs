﻿namespace EPostBusinessApi
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net;

    using EPostBusinessApi.Properties;
    using EPostBusinessApi.Status;

    using IEPostBusinessApi.EPostException;
    using IEPostBusinessApi.JSON.Draft;
    using IEPostBusinessApi.JSON.Error;

    /// <summary>Diese Klasse dient dem Anlegen von Entwürfen.</summary>
    internal class DeleteDraft : ApiBaseRequest
    {
        #region Constants

        /// <summary>Der Name dieser Klasse zu Zwecken der Fehlerbehandlung.</summary>
        private const string ClassName = "DeleteDraft";

        #endregion

        #region Properties

        /// <summary>Gets or sets the content source.</summary>
        internal string ContentSource { get; set; }

        /// <summary>Gets or sets the Html Body of the message.</summary>
        internal string HtmlBody { get; set; }

        /// <summary>Gets or sets the x epost access token.</summary>
        internal string XEpostAccessToken { get; set; }

        /// <summary>Gets the content type.</summary>
        protected override string ContentType
        {
            get
            {
                return string.Empty;
            }
        }

        /// <summary>Gets the method.</summary>
        protected override string Method
        {
            get
            {
                return Settings.Default.Method_DELETE;
            }
        }

        /// <summary>Gets the mime type.</summary>
        protected override string MimeType
        {
            get
            {
                return string.Empty;
            }
        }

        /// <summary>Gets the ok status code.</summary>
        protected override HttpStatusCode OkStatusCode
        {
            get
            {
                return HttpStatusCode.NoContent;
            }
        }

        /// <summary>Gets the request header.</summary>
        protected override List<string> RequestHeader
        {
            get
            {
                var header = new List<string>
                                 {
                                     string.Format(
                                         Settings.Default.XEpostAccessToken, 
                                         this.XEpostAccessToken)
                                 };
                return header;
            }
        }

        /// <summary>Gets the url.</summary>
        protected override Uri Url
        {
            get
            {
                return new Uri(this.CreateUrl());
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Deletes the draft referenced by LetterId
        /// </summary>
        internal void DeleteIt()
        {
            if (this.XEpostAccessToken == null)
            {
                this.Error = CreateErrorResponse("access_token_null", "Access Token is null", null);
                throw new EPostBusinessApiException("Access Token is null", ClassName, 999, this.Error);
            }

            var result = this.DoRequest();

            if (!this.IsOk)
            {
                if (result.Key == typeof(ErrorResponse))
                {
                    this.Error = result.Value as ErrorResponse;
                }
                else if (result.Key == typeof(ErrorDetail))
                {
                    var detail = result.Value as ErrorDetail;
                    if (detail != null)
                    {
                        this.Error = new ErrorResponse
                        {
                            Error = string.Empty,
                            ErrorDescription = detail.Description,
                            ErrorDetails = new List<ErrorDetail> { detail }
                        };
                    }
                }
                else
                {
                    this.Error = CreateErrorResponse("could_not_get_result", "Could not get result", null);
                }

                throw new EPostBusinessApiException("Could not get result", ClassName, (int)this.StatusCode, this.Error);
            }
        }

        /// <summary>Liefert das Format des zurückgegebenen Bodies aus dem HttpStatusCode.</summary>
        /// <param name="statusCode">HttpStatusCode</param>
        /// <returns>BodyFormat</returns>
        protected override BodyFormat GetBodyFormat(HttpStatusCode statusCode)
        {
            switch (statusCode)
            {
                case HttpStatusCode.NoContent:
                    return BodyFormat.NothingOk;
                case HttpStatusCode.Conflict:
                case HttpStatusCode.BadRequest:
                case HttpStatusCode.Unauthorized:
                case HttpStatusCode.Forbidden:
                case HttpStatusCode.NotAcceptable:
                    return BodyFormat.JsonError;
                case HttpStatusCode.NotFound:
                case HttpStatusCode.MethodNotAllowed:
                case HttpStatusCode.RequestEntityTooLarge:
                case HttpStatusCode.UnsupportedMediaType:
                case HttpStatusCode.InternalServerError:
                    return BodyFormat.NothingUndefined;
                default:
                    return BodyFormat.NothingUndefined;
            }
        }

        /// <summary>Schreibt den Request.</summary>
        /// <param name="writer">Der writer.</param>
        protected override void WriteRequestStream(StreamWriter writer)
        {
            // Nothing to do. No HTML Body.
        }

        /// <summary>Erzeugt die URL.</summary>
        /// <returns>Die URL als <see cref="string" />.</returns>
        private string CreateUrl()
        {
            return string.Format(Settings.Default.MailboxLettersURL + "/" + ContentSource, this.GetSystem());
        }

        #endregion
    }
}