﻿namespace EPostBusinessApi
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net;

    using EPostBusinessApi.Properties;
    using EPostBusinessApi.Status;

    using IEPostBusinessApi.EPostException;
    using IEPostBusinessApi.JSON.Draft;
    using IEPostBusinessApi.JSON.Error;

    /// <summary>Diese Klasse dient dem Anlegen von Entwürfen.</summary>
    internal class Draft : ApiBaseRequest
    {
        #region Constants

        /// <summary>Der Name dieser Klasse zu Zwecken der Fehlerbehandlung.</summary>
        private const string ClassName = "Draft";

        #endregion

        #region Properties

        /// <summary>Liest oder setzt CreateDraftRequest.</summary>
        internal CreateDraftRequest CreateDraftRequest { get; set; }

        /// <summary>Liest oder setzt HtmlBody.</summary>
        internal string HtmlBody { get; set; }

        /// <summary>Liest oder setzt Files.</summary>
        internal List<FileInfo> Files { get; set; }

        /// <summary>Liest oder setzt XEpostAccessToken.</summary>
        internal string XEpostAccessToken { get; set; }

        /// <summary>Liest ContentType.</summary>
        protected override string ContentType
        {
            get
            {
                return string.Format(Settings.Default.Draft_Boundary, this.Boundary);
            }
        }

        /// <summary>Liest Method.</summary>
        protected override string Method
        {
            get
            {
                return Settings.Default.Method_POST;
            }
        }

        /// <summary>Liest MimeType.</summary>
        protected override string MimeType
        {
            get
            {
                return Settings.Default.MIME_TYPESaveDraft;
            }
        }

        /// <summary>Liest OkStatusCode.</summary>
        protected override HttpStatusCode OkStatusCode
        {
            get
            {
                return HttpStatusCode.Created;
            }
        }

        /// <summary>Liest RequestHeader.</summary>
        protected override List<string> RequestHeader
        {
            get
            {
                var header = new List<string>
                                 {
                                     string.Format(
                                         Settings.Default.XEpostAccessToken, 
                                         this.XEpostAccessToken)
                                 };
                return header;
            }
        }

        /// <summary>Liest Url.</summary>
        protected override Uri Url
        {
            get
            {
                return new Uri(this.CreateUrl());
            }
        }

        #endregion

        #region Methods

        /// <summary>Erzeugt einen Entwurf</summary>
        /// <returns>Der <see cref="CreateDraftResponse" /> beinhaltet die Rückgabewerte.</returns>
        /// <exception cref="EPostBusinessApiException">Im Fehlerfall wird eine EPostBusinessApiException geworfen.</exception>
        internal CreateDraftResponse CreateDraft()
        {
            if (this.CreateDraftRequest == null)
            {
                this.Error = CreateErrorResponse("create_draft_request_null", "CreateDraftRequest is null", null);
                throw new EPostBusinessApiException("CreateDraftRequest is null", ClassName, 999, this.Error);
            }

            if (this.XEpostAccessToken == null)
            {
                this.Error = CreateErrorResponse("access_token_null", "Access Token is null", null);
                throw new EPostBusinessApiException("Access Token is null", ClassName, 999, this.Error);
            }

            var result = this.DoRequest();
            if (result.Key == typeof(CreateDraftResponse))
            {
                return result.Value as CreateDraftResponse;
            }

            if (result.Key == typeof(ErrorResponse))
            {
                this.Error = result.Value as ErrorResponse;
            }
            else if (result.Key == typeof(ErrorDetail))
            {
                var detail = result.Value as ErrorDetail;
                if (detail != null)
                {
                    this.Error = new ErrorResponse
                                     {
                                         Error = string.Empty, 
                                         ErrorDescription = detail.Description, 
                                         ErrorDetails = new List<ErrorDetail> { detail }
                                     };
                }
            }
            else
            {
                this.Error = CreateErrorResponse("could_not_get_result", "Could not get result", null);
            }

            throw new EPostBusinessApiException("Could not get result", ClassName, (int)this.StatusCode, this.Error);
        }

        /// <summary>Liefert das Format des zurückgegebenen Bodies aus dem HttpStatusCode.</summary>
        /// <param name="statusCode">HttpStatusCode</param>
        /// <returns>BodyFormat</returns>
        protected override BodyFormat GetBodyFormat(HttpStatusCode statusCode)
        {
            switch (statusCode)
            {
                case HttpStatusCode.Created:
                    return BodyFormat.JsonSaveDraft;
                case HttpStatusCode.BadRequest:
                case HttpStatusCode.Forbidden:
                case HttpStatusCode.NotAcceptable:
                case HttpStatusCode.NotFound:
                case HttpStatusCode.MethodNotAllowed:
                case HttpStatusCode.RequestEntityTooLarge:
                case HttpStatusCode.UnsupportedMediaType:
                case HttpStatusCode.InternalServerError:
                case HttpStatusCode.Unauthorized:
                    return BodyFormat.JsonErrorOnlyDescription;
                default:
                    return BodyFormat.NothingUndefined;
            }
        }

        /// <summary>Schreibt den Request.</summary>
        /// <param name="writer">Der writer.</param>
        protected override void WriteRequestStream(StreamWriter writer)
        {
            this.WriteJsonAndFilesToRequestStream(writer, this.CreateDraftRequest, HtmlBody, this.Files);
        }

        /// <summary>Erzeugt die URL.</summary>
        /// <returns>Die URL als <see cref="string" />.</returns>
        private string CreateUrl()
        {
            return string.Format(Settings.Default.MailboxLettersURL, this.GetSystem());
        }

        #endregion
    }
}