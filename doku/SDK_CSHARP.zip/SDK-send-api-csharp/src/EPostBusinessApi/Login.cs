﻿using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace EPostBusinessApi
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Web;
    using System.Windows.Controls;
    using System.Windows.Navigation;

    using EPostBusinessApi.Properties;
    using EPostBusinessApi.Status;

    using EPostBusinessApiBrowser;

    using IEPostBusinessApi;
    using IEPostBusinessApi.EPostException;
    using IEPostBusinessApi.JSON.Access;
    using IEPostBusinessApi.JSON.Draft;
    using IEPostBusinessApi.JSON.Error;

    /// <summary>
    /// Durch das Anfordern der Login-Seite über die Login-API authentisiert sich Ihre Applikation am E‑POST System. Ihre
    /// Applikation beantragt per separatem Browser eine Authentisierung (Login oder Login mit HandyTAN). Der Browser wickelt
    /// danach den Authentisierungsprozess mit der Login-API ab.
    /// </summary>
    public class Login : ApiBaseRequest, ILogin
    {
        #region Constants

        /// <summary>
        /// Der Name dieser Klasse für die Fehlerbehandlung.
        /// </summary>
        private const string ClassName = "EPostSession";

        #endregion

        #region Public Properties

        /// <summary>
        /// Liest AccessToken.
        /// </summary>
        public AccessTokenResponse AccessToken { get; set; }

        /// <summary>
        /// Ein beliebiger String, der die Client-Applikation identifiziert. HINWEIS Die client_idergibt sich aus DevIdund AppId,
        /// die Sie bei der Registrierung für E‑POSTBUSINESS API ange-ben. Die Bildungsvorschrift der client_iderfolgt auf
        /// fol-gende Weise: ▪ clientid = devid "," appid
        /// </summary>
        public string ClientId { get; set; }

        /// <summary>
        /// Liest oder setzt CreateDraftResponse.
        /// </summary>
        public CreateDraftResponse CreateDraftResponse { get; set; }

        /// <summary>
        /// Legt fest, welchen Code-Typ der Client für den Token-Tausch anbietet.
        /// </summary>
        public GrantType GrantType { get; set; }

        /// <summary>
        /// Die zu verwendende LIF-Datei.
        /// </summary>
        public string LifContent { get; set; }

        /// <summary>
        /// Passwort des Nutzers
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// Der Scope legt fest, inwieweit der Client auf die Ressource(n)
        /// des Nutzers zugreift:
        /// <ul>
        /// 	<li>Es ist möglich, mehrere Scopes gleichzeitig anzugeben.</li>
        /// 	<li>Mehrere Scopes werden entweder mit einem maskierten Leerzeichen oder mit einem + -Zeichen voneinander getrennt.</li>
        /// 	<li>Beispiel für mehrere Scopes: scope=send_letter+read_letter.</li>
        /// 	<li>Das Authentisierungs-Niveau gibt an, ob sich der Nutzer des E‐POST Systems mit einer HandyTAN authentifizieren muss (hoch) oder nicht (normal).</li>
        /// 	<li>Folgende Scopes sind möglich:</li>
        /// 	<dl>
        ///    		<dt>send_letter</dt>
        ///    		<dd>
        /// 			<ul>
        /// 				<li>erlaubt das Versenden von elektronischen E‐POSTBRIEFEN</li>
        /// 				<li>erfordert ein hohes Authentifizierungs-Niveau</li>
        /// 			</ul>
        /// 		</dd>
        /// 		<dt>send_hybrid</dt>
        /// 		<dd>
        /// 			<ul>
        /// 				<li>erlaubt das Versenden von physischen E‐POSTBRIEFEN</li>
        /// 				<li>erfordert ein normales Authentifizierungs-Niveau</li>
        /// 			</ul>
        /// 		</dd>
        /// 		<dt>read_letter</dt>
        /// 		<dd>
        /// 			<ul>
        /// 				<li>erlaubt das Lesen von E‐POSTBRIEFEN</li>
        /// 				<li>erfordert ein normales Authentifizierungs-Niveau</li>
        /// 			</ul>
        /// 		</dd>
        /// 		<dt>create_letter</dt>
        /// 		<dd>
        /// 			<ul>
        /// 				<li>erlaubt das Erstellen von E‐POSTBRIEF Entwürfen</li>
        /// 				<li>erfordert ein normales Authentifizierungs-Niveau</li>
        /// 			</ul>
        /// 		</dd>
        /// 		<dt>delete_letter</dt>
        /// 		<dd>
        /// 			<ul>
        /// 				<li>erlaubt das Löschen von E‐POSTBRIEF Entwürfen</li>
        /// 				<li>erfordert ein normales Authentifizierungs-Niveau</li>
        /// 			</ul>
        /// 		</dd>
        /// 	</dl>
        /// </ul>
        /// </summary>
        public List<Scope> Scopes { get; set; }

        /// <summary>
        /// Ein beliebiger String von maximal 512 Zeichen Länge, der den
        /// Zustand der Applikation beschreibt. Der Wert wird der Applikation im Login-Ergebnis zurückgegeben. Hier kann z. B.
        /// eine Session-ID durchgereicht werden.
        /// </summary>
        public string State { get; set; }

        /// <summary>
        /// Nutzername
        /// </summary>
        public string Username { get; set; }

        /// <summary>Liest WorkStatus.</summary>
        public WorkStatus WorkStatus { get; internal set; }

        #endregion

        #region Properties

        /// <summary>
        /// Liest oder setzt ContentSource.
        /// </summary>
        protected string ContentSource { get; set; }

        /// <summary>
        /// Liest ContentType.
        /// </summary>
        protected override string ContentType
        {
            get { return Settings.Default.Login_ContentType; }
        }

        /// <summary>
        /// Liest Method.
        /// </summary>
        protected override string Method
        {
            get { return Settings.Default.Method_POST; }
        }

        /// <summary>
        /// Liest MimeType.
        /// </summary>
        protected override string MimeType
        {
            get { return string.Empty; }
        }

        /// <summary>
        /// Liest OkStatusCode.
        /// </summary>
        protected override HttpStatusCode OkStatusCode
        {
            get { return HttpStatusCode.OK; }
        }

        /// <summary>
        /// Liest RequestHeader.
        /// </summary>
        protected override List<string> RequestHeader
        {
            get
            {
                var header = new List<string>
                {
                    string.Format(Settings.Default.Authorization, GetBasicAuthentication())
                };
                return header;
            }
        }

        /// <summary>
        /// Liest Url.
        /// </summary>
        protected override Uri Url
        {
            get { return new Uri(CreateResourceOwnerPasswordCredentialsGrantUrl()); }
        }

        /// <summary>
        /// Liest ResponseType.
        /// </summary>
        private static string ResponseType
        {
            get { return Settings.Default.ResponseType; }
        }

        /// <summary>
        /// Liest oder setzt AuthorizationCode.
        /// </summary>
        private string AuthorizationCode { get; set; }

        /// <summary>
        /// Liest oder setzt einen Wert, der die Verwendung eines externen Browser angibt.
        /// </summary>
        private bool ExternalBrowser { get; set; }

        /// <summary>
        /// Liest oder setzt einen Wert, der den Login-Vorgang angibt.
        /// </summary>
        private bool IsLoggingIn { get; set; }

        /// <summary>
        /// Liest oder setzt LoginWindow.
        /// </summary>
        private LoginWindow LoginWindow { get; set; }

        #endregion

        #region Public Methods and Operators

        /// <summary>Der Login mit oder ohne Browser.</summary>
        /// <param name="browser">Der Browser.</param>
        /// <param name="enterPasswordInHtmlPage">The enter password in html page.</param>
        public void InternalLogin(WebBrowser browser, bool enterPasswordInHtmlPage)
        {
            this.SetScopesAndGrantType(enterPasswordInHtmlPage);
            this.PrivateLogin(browser);
        }

        /// <summary>Erhöht das Authentifizierungs-Niveau, um auch elektronische E-POSTBRIEFE versenden zu können.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die Interaktionen angezeigt werden.</param>
        public void LoginExtensionSendLetter(WebBrowser browser)
        {
            if (AccessToken == null)
            {
                Error = CreateErrorResponse("access_token_null", "Access Token is null", null);
                throw new EPostBusinessApiException("Access Token is null", "PostageInfo", 999, Error);
            }

            this.SetScopesAndGrantType(true);

            var extension = new Extension
            {
                AccessToken = AccessToken,
                ClientId = ClientId,
                RedirectUri = RedirectUri,
                State = State,
                SystemType = SystemType,
                ThirdSystemUrl = this.ThirdSystemUrl
            };

            var redirect = extension.Extend().Value as Redirect;

            if (redirect == null)
            {
                throw new EPostBusinessApiException(
                    "redirect_null",
                    ClassName,
                    302,
                    CreateErrorResponse("redirect_null", "redirect null", null));
            }

            // Dieser Wert ist true, falls der Login Prozess im Gange ist und bereits die redirection mit code stattgefunden hat.
            IsLoggingIn = false;
            LoginWithGui(browser, redirect.Uri, redirect.Cookies);
        }

        #endregion

        #region Methods

        /// <summary>The internet set cookie.</summary>
        /// <param name="url">The url.</param>
        /// <param name="cookieName">The cookie name.</param>
        /// <param name="cookieData">The cookie data.</param>
        /// <returns>The <see cref="bool"/>.</returns>
        [DllImport("wininet.dll", CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern bool InternetSetCookie(string url, string cookieName, string cookieData);

        /// <summary>Liefert das Format des zurückgegebenen Bodies aus dem HttpStatusCode.</summary>
        /// <param name="statusCode">HttpStatusCode </param>
        /// <returns>BodyFormat </returns>
        protected override BodyFormat GetBodyFormat(HttpStatusCode statusCode)
        {
            switch (statusCode)
            {
                case HttpStatusCode.OK:
                    return BodyFormat.JsonAccessToken;
                case HttpStatusCode.BadRequest:
                case HttpStatusCode.UnsupportedMediaType:
                case HttpStatusCode.Found:
                    return BodyFormat.JsonError;
                case HttpStatusCode.NotFound:
                case HttpStatusCode.MethodNotAllowed:
                case HttpStatusCode.RequestEntityTooLarge:
                case HttpStatusCode.InternalServerError:
                    return BodyFormat.NothingError;
                default:
                    return BodyFormat.NothingUndefined;
            }
        }

        /// <summary>Schreibt den Request.</summary>
        /// <param name="writer">Der writer. </param>
        protected override void WriteRequestStream(StreamWriter writer)
        {
            switch (GrantType)
            {
                case GrantType.password:
                    writer.Write(CreateResourceOwnerPasswordCredentialsGrantBody());
                    break;
                case GrantType.authorization_code:
                    writer.Write(CreateAuthorizationCodeGrantBody());
                    break;
            }
        }

        /// <summary>Diese Event wird mehrmals aufgerufen. Uns interessiert aber nur der erste Aufruf, bei dem die URL der redirect URL
        /// entspricht. Da steht alles drin was wir benötigen und die weiteren Events werden nicht mehr abgearbeitet.</summary>
        /// <param name="sender">Der Sender </param>
        /// <param name="eventArg">Die Event Argumente. </param>
        private void BrowserNavigating(object sender, NavigatingCancelEventArgs eventArg)
        {
            var url = eventArg.Uri == null ? null : eventArg.Uri.AbsoluteUri;
            if (RedirectUri != null && !IsLoggingIn && url != null && url.StartsWith(RedirectUri.AbsoluteUri))
            {
                if (!ExternalBrowser)
                {
                    CloseLoginForm();
                }

                IsLoggingIn = true;

                var parameters = HttpUtility.ParseQueryString(url);
                var code = RedirectUri.AbsoluteUri + "?code";
                if (parameters.AllKeys.Contains(code))
                {
                    AuthorizationCode = parameters[code];
                    LoginResourceOwnerPasswordCredentialsGrant();
                }
                else
                {
                    Error = new ErrorResponse
                    {
                        Error = parameters[RedirectUri + "?error"],
                        ErrorDescription = parameters["error_description"],
                        ErrorUri = parameters["error_uri"]
                    };
                    IsOk = false;
                }
            }
        }

        /// <summary>
        /// Schließt die Login-Maske.
        /// </summary>
        private void CloseLoginForm()
        {
            ExecuteInGuiThread(new Action(() => LoginWindow.Close()));
        }

        /// <summary>
        /// Erzeugt den AuthorizationGrantBody.
        /// </summary>
        /// <returns> Der Grant als <see cref="string" /> . </returns>
        private string CreateAuthorizationCodeGrantBody()
        {
            // grant_type={0}&code={1}&scope={2}&redirect_uri={3}
            if (RedirectUri != null)
            {
                var body = string.Format(
                    Settings.Default.LoginAuthenticationCodeGrantBody,
                    GrantType.ToString("f"),
                    AuthorizationCode,
                    GetScopes(),
                    RedirectUri.AbsoluteUri);
                return body;
            }

            return
                string.Format(
                    Settings.Default.LoginAuthenticationCodeGrantBody.Replace("&redirect_uri={3}", string.Empty),
                    GrantType.ToString("f"),
                    AuthorizationCode,
                    GetScopes());
        }

        /// <summary>
        /// Erzeugt den ResourceOwnerPasswordCredentialsGrantBody.
        /// </summary>
        /// <returns> Der ResourceOwnerPasswordCredentialsGrantBody als <see cref="string" /> . </returns>
        private string CreateResourceOwnerPasswordCredentialsGrantBody()
        {
            // grant_type={0}&username={1}&password={2}&scope={3}
            var body = string.Format(
                Settings.Default.LoginResourceOwnerPasswordCredentialsGrantBody,
                GrantType.ToString("f"),
                HttpUtility.UrlEncode(Username),
                HttpUtility.UrlEncode(Password),
                GetScopes());
            return body;
        }

        /// <summary>
        /// Erzeugt die ResourceOwnerPasswordCredentialsGrantUrl.
        /// </summary>
        /// <returns> Die ResourceOwnerPasswordCredentialsGrantUrl als <see cref="string" /> . </returns>
        private string CreateResourceOwnerPasswordCredentialsGrantUrl()
        {
            // https://login.{0}/oauth2/tokens
            var urlRequest = string.Format(Settings.Default.LoginResourceOwnerPasswordCredentialsGrantURL, GetSystem());
            return urlRequest;
        }

        /// <summary>
        /// Erzeugt den string zur Basi Authentication.
        /// </summary>
        /// <returns> Die Basic Authentication als <see cref="string" /> . </returns>
        private string GetBasicAuthentication()
        {
            try
            {
                var authentication = new StringBuilder("Basic ");
                var clientpass = new StringBuilder(HttpUtility.UrlEncode(ClientId));

                clientpass.Append(":").Append(HttpUtility.UrlEncode(LifContent));
                authentication.Append(Convert.ToBase64String(Encoding.ASCII.GetBytes(clientpass.ToString())));

                return authentication.ToString();
            }

                // ReSharper disable EmptyGeneralCatchClause
            catch (Exception)
            {
                // ReSharper restore EmptyGeneralCatchClause
            }

            return null;
        }

        /// <summary>
        /// Erzeugt den login string.
        /// </summary>
        /// <returns> Der login als <see cref="Uri" /> . </returns>
        private Uri GetLoginUri()
        {
            // https://login.{0}/oauth2/auth?response_type={1}&client_id={2}&state={3}&scope={4}&redirect_uri={5}
            if (RedirectUri != null)
            {
                return
                    new Uri(
                        string.Format(
                            Settings.Default.LoginURL,
                            GetSystem(),
                            ResponseType,
                            ClientId,
                            State,
                            GetScopes(),
                            RedirectUri));
            }

            return
                new Uri(
                    string.Format(
                        Settings.Default.LoginURL.Replace("&redirect_uri={5}", string.Empty),
                        this.GetSystem(),
                        ResponseType,
                        this.ClientId,
                        this.State,
                        this.GetScopes()));
        }

        /// <summary>
        /// Liefert die gewünschten Scopes.
        /// </summary>
        /// <returns> Die Scopes als <see cref="string" /> . </returns>
        private string GetScopes()
        {
            var strScopes = Array.ConvertAll(Scopes.ToArray(), scope => scope.ToString("f"));
            var retString = string.Join("+", strScopes);
            return retString;
        }

        /// <summary>
        /// Führt das Passwort basierte Login durch.
        /// </summary>
        /// <exception cref="EPostBusinessApiException">Im Fehlerfall wird eine EPostBusinessApiException geworfen.</exception>
        private void LoginResourceOwnerPasswordCredentialsGrant()
        {
            var result = DoRequest();
            if (result.Key == typeof (AccessTokenResponse))
            {
                AccessToken = result.Value as AccessTokenResponse;
                return;
            }

            if (result.Key == typeof (ErrorResponse))
            {
                Error = result.Value as ErrorResponse;
            }
            else
            {
                Error = CreateErrorResponse("could_not_get_result", "Could not get result", null);
            }
        }

        /// <summary>Führt das Login per GUI durch.</summary>
        /// <param name="browser">Der Browser, über den das Login durchgeführt werden soll. </param>
        /// <param name="uri">Die Uri zu der der Browser navigiert. </param>
        /// <param name="cookieCollection">Ggf. zu setzende Cookies. </param>
        private void LoginWithGui(WebBrowser browser, Uri uri, CookieCollection cookieCollection = null)
        {
            if (browser == null)
            {
                ExternalBrowser = false;
                ExecuteInGuiThread(new Action(() =>
                {
                    LoginWindow = new LoginWindow();
                    browser = LoginWindow.Browser;
                }));
            }
            else
            {
                ExternalBrowser = true;
            }

            ExecuteInGuiThread(new Action(() => browser.Navigating += BrowserNavigating));

            // Hier findet ein Aufruf des Browsers statt.
            // Sollte die CookieCollection nicht leer sein, so rufen wir den Browser mit den entsprechenden Cookies auf
            // Diese sind insbesondere wichtig, da dort der Cookie code drin steht, falls es um die Erhöhung des Niveaus geht.
            // Cookies setzen, falls erforderlich
            if (cookieCollection != null)
            {
                var cookieString = string.Empty;
                foreach (Cookie cook in cookieCollection)
                {
                    cookieString += cook + ";";
                    InternetSetCookie(uri.AbsoluteUri, cook.Name, cook.Value);
                }

                ExecuteInGuiThread(
                    new Action(
                        () =>
                            browser.Navigate(uri.AbsoluteUri, string.Empty, null,
                                "Cookies: " + cookieString + Environment.NewLine)));
            }
            else
            {
                ExecuteInGuiThread(new Action(() => browser.Navigate(uri)));
            }

            if (!ExternalBrowser && LoginWindow != null)
            {
                ExecuteInGuiThread(new Action(() => LoginWindow.ShowDialog()));
            }
        }

        /// <summary>
        /// Execute the given method in the GUI tread, using the given arguments.
        /// 
        /// Task related to the GUI have to be executed from the GUI thread. This methods helps
        /// executing code in the GUI thread.
        /// </summary>
        /// <param name="method">The method to execute.</param>
        /// <param name="args">The parameters for the method.</param>
        /// <returns>The execution results of the method.</returns>
        public static DispatcherOperation ExecuteInGuiThread(Delegate method, params Object[] args)
        {
            if (Thread.CurrentThread.GetApartmentState() == ApartmentState.STA)
            {
                // if we are in the GUI thread, we must not call the BeginInvoke
                // TODO Andreas: Maybe we can use the Invoke?...
                method.DynamicInvoke(args);
                return null;
            }

            // start the delegate in the GUI thread
            return Application.Current.Dispatcher.BeginInvoke(method, args);
        }

        /// <summary>Der Benutzer wird mit den hinterlegten Zugangsdaten angemeldet.</summary>
        /// <param name="browser">Der Browser, in dem ggf. die Interaktionen angezeigt werden. </param>
        private void PrivateLogin(WebBrowser browser)
        {
            switch (GrantType)
            {
                case GrantType.password:
                    LoginResourceOwnerPasswordCredentialsGrant();
                    break;
                case GrantType.authorization_code:

                    // Dieser Wert ist true, falls der Login Prozess im Gange ist und bereits die redirection mit code stattgefunden hat.
                    IsLoggingIn = false;
                    LoginWithGui(browser, this.GetLoginUri());
                    break;
            }

            if (!IsOk)
            {
                throw new EPostBusinessApiException("Login fehlgeschlagen", ClassName, (int) StatusCode, Error);
            }
        }

        /// <summary>The set scopes and grant type.</summary>
        /// <param name="enterPasswordInHtmlPage">The enter password in html page.</param>
        private void SetScopesAndGrantType(bool enterPasswordInHtmlPage)
        {
            if (enterPasswordInHtmlPage)
            {
                Scopes = new List<Scope>
                {
                    Scope.delete_letter,
                    Scope.create_letter,
                    Scope.read_letter,
                    Scope.send_hybrid,
                    Scope.send_letter,
                    Scope.safe
                };
                GrantType = GrantType.authorization_code;
            }
            else
            {
                Scopes = new List<Scope>
                {
                    Scope.delete_letter,
                    Scope.create_letter,
                    Scope.read_letter,
                    Scope.send_hybrid,
                    Scope.safe
                };
                GrantType = GrantType.password;
            }
        }

        #endregion
    }
}