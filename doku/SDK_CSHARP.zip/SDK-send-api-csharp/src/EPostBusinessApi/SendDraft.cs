﻿namespace EPostBusinessApi
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net;

    using EPostBusinessApi.Properties;
    using EPostBusinessApi.Status;

    using IEPostBusinessApi.EPostException;
    using IEPostBusinessApi.JSON.Error;
    using IEPostBusinessApi.JSON.PrintOptions;

    using Newtonsoft.Json;

    /// <summary>Diese Klasse dient dem Versenden eines E-POSTBRIEF Entwurfs.</summary>
    internal class SendDraft : ApiBaseRequest
    {
        #region Constants

        /// <summary>Der Name dieser Klasse zu Zwecken der Fehlerbehandlung.</summary>
        private const string ClassName = "SendDraft";

        #endregion

        #region Properties

        /// <summary>Liest oder setzt ContentSource.</summary>
        internal string ContentSource { get; set; }

        /// <summary>Liest oder setzt PrintOptionsRequest.</summary>
        internal PrintOptionsRequest PrintOptionsRequest { get; set; }

        /// <summary>Liest oder setzt XEpostAccessToken.</summary>
        internal string XEpostAccessToken { get; set; }

        /// <summary>Liest ContentType.</summary>
        protected override string ContentType
        {
            get
            {
                return Settings.Default.MIME_TYPESendPrintOptions;
            }
        }

        /// <summary>Liest MimeType.</summary>
        protected override string MimeType
        {
            get
            {
                return Settings.Default.MIME_TYPESendPrintOptions;
            }
        }

        /// <summary>Liest Method.</summary>
        protected override string Method
        {
            get
            {
                return Settings.Default.Method_POST;
            }
        }

        /// <summary>Liest OkStatusCode.</summary>
        protected override HttpStatusCode OkStatusCode
        {
            get
            {
                return HttpStatusCode.NoContent;
            }
        }

        /// <summary>Liest RequestHeader.</summary>
        protected override List<string> RequestHeader
        {
            get
            {
                var header = new List<string>
                                 {
                                     string.Format(
                                         Settings.Default.XEpostAccessToken, 
                                         this.XEpostAccessToken), 
                                     string.Format(Settings.Default.ContentSource, this.ContentSource)
                                 };
                return header;
            }
        }

        /// <summary>Liest Url.</summary>
        protected override Uri Url
        {
            get
            {
                return new Uri(this.CreateUrl());
            }
        }

        #endregion

        #region Methods

        /// <summary>Versendet einen E-POSTBRIEF.</summary>
        /// <param name="printOptionsRequest">Die beim Versand zu berücksichtigenden Parameter.</param>
        internal void SendIt(PrintOptionsRequest printOptionsRequest)
        {
            this.PrintOptionsRequest = printOptionsRequest;
            this.SendIt();
        }

        /// <summary>Versendet einen E-POSTBRIEF.</summary>
        /// <exception cref="EPostBusinessApiException">Im Fehlerfall wird eine EPostBusinessApiException geworfen.</exception>
        internal void SendIt()
        {
            if (this.XEpostAccessToken == null)
            {
                this.Error = CreateErrorResponse("access_token_null", "Access Token is null", null);
                throw new EPostBusinessApiException("Access Token is null", ClassName, 999, this.Error);
            }

            var result = this.DoRequest();

            if (!this.IsOk)
            {
                if (result.Key == typeof(ErrorResponse))
                {
                    this.Error = result.Value as ErrorResponse;
                }
                else if (result.Key == typeof(ErrorDetail))
                {
                    var detail = result.Value as ErrorDetail;
                    if (detail != null)
                    {
                        this.Error = new ErrorResponse
                                         {
                                             Error = string.Empty, 
                                             ErrorDescription = detail.Description, 
                                             ErrorDetails = new List<ErrorDetail> { detail }
                                         };
                    }
                }
                else
                {
                    this.Error = CreateErrorResponse("could_not_get_result", "Could not get result", null);
                }

                throw new EPostBusinessApiException("Could not get result", ClassName, (int)this.StatusCode, this.Error);
            }
        }

        /// <summary>Liefert das Format des zurückgegebenen Bodies aus dem HttpStatusCode.</summary>
        /// <param name="statusCode">HttpStatusCode</param>
        /// <returns>BodyFormat</returns>
        protected override BodyFormat GetBodyFormat(HttpStatusCode statusCode)
        {
            switch (statusCode)
            {
                case HttpStatusCode.NoContent:
                    return BodyFormat.NothingOk;
                case HttpStatusCode.Conflict:
                case HttpStatusCode.BadRequest:
                case HttpStatusCode.Unauthorized:
                case HttpStatusCode.Forbidden:
                case HttpStatusCode.NotAcceptable:
                    return BodyFormat.JsonError;
                case HttpStatusCode.NotFound:
                case HttpStatusCode.MethodNotAllowed:
                case HttpStatusCode.RequestEntityTooLarge:
                case HttpStatusCode.UnsupportedMediaType:
                case HttpStatusCode.InternalServerError:
                    return BodyFormat.NothingUndefined;
                default:
                    return BodyFormat.NothingUndefined;
            }
        }

        /// <summary>Schreibt den Request.</summary>
        /// <param name="writer">Der writer.</param>
        protected override void WriteRequestStream(StreamWriter writer)
        {
            if (this.PrintOptionsRequest != null)
            {
                writer.WriteLine(JsonConvert.SerializeObject(this.PrintOptionsRequest, Formatting.Indented));
            }
        }

        /// <summary>Erzeugt die URL.</summary>
        /// <returns>Die URL als <see cref="string" />.</returns>
        private string CreateUrl()
        {
            return string.Format(Settings.Default.SendURL, this.GetSystem());
        }

        #endregion
    }
}