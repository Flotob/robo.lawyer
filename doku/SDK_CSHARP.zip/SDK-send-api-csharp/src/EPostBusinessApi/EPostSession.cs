﻿namespace EPostBusinessApi
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    using EPostBusinessApi.LoginStateMachine;
    using EPostBusinessApi.Properties;
    using EPostBusinessApi.Timer;

    using IEPostBusinessApi;
    using IEPostBusinessApi.EPostException;
    using IEPostBusinessApi.JSON.Draft;
    using IEPostBusinessApi.JSON.Electronic;
    using IEPostBusinessApi.JSON.Error;
    using IEPostBusinessApi.JSON.Folder;
    using IEPostBusinessApi.JSON.Postage;
    using IEPostBusinessApi.JSON.Print;
    using IEPostBusinessApi.JSON.PrintOptions;
    using IEPostBusinessApi.LoginStateMachine;

    using Letter = IEPostBusinessApi.JSON.Draft.Letter;

    /// <summary>
    /// Die EPostSession ermöglicht es, die aktuelle Kommunikation mit dem API-Server zu verwalten.
    /// Sie beinhaltet die StateMachine, die den aktuellen FolderStatus des Logins kennt und ihn auch zu wechseln vermag.
    /// Weiterhin ist sie in der Lage die Login-Daten vorzuhalten.
    /// </summary>
    public class EPostSession : IEPostSession, IWorkStatusChanger
    {
        #region Fields

        /// <summary>Der Login State Machine.</summary>
        private ILoginState loginStateMachine;

        #endregion

        #region Constructors and Destructors

        /// <summary>Initialisiert eine neue Instanz der <see cref="EPostSession" /> Klasse.</summary>
        public EPostSession()
        {
            Login = new Login();
            InternalLogin.WorkStatus = WorkStatus.Nothing;
            LoginStateMachine = new NotLoggedInState(this);

            TimeFinallyLoggedOutSec = Settings.Default.TimeFinallyLoggedOutSec;
            TimeLoggedInLowSec = Settings.Default.TimeLoggedInLowSec - Settings.Default.TimeRefreshBufferSec;
            TimeLoggedInHighSec = Settings.Default.TimeLoggedInHighSec - Settings.Default.TimeRefreshBufferSec;

            // TimeRefreshLowSec = ??; -> wird nicht gesetzt, da abhaengig vom vorherigen FolderStatus
            TimeRefreshHighSec = Settings.Default.TimeRefreshHighSec;
            Mailbox = null;
        }

        #endregion

        #region Public Events

        /// <summary>Dieses Event wird ausgelöst, sobald sich der Login-FolderStatus geändert hat.</summary>
        public event LoginStatusEventHandler LoginStatusChanged;

        /// <summary>
        /// Dieses Event wird ausgelöst, sobald sich der Arbeitsstatus geändert hat.
        /// Es kann dazu genutzt werden, den Benutzer über die gerade durchgeführten Aktionen der API zu informieren.
        /// </summary>
        public event WorkStatusEventHandler WorkStatusChanged;

        #endregion

        #region Public Properties

        /// <summary>Liest oder setzt Error.</summary>
        public ErrorResponse Error { get; protected set; }

        /// <summary>Liest oder setzt einen Wert, der das OK signalisiert.</summary>
        public bool IsOk { get; protected set; }

        /// <summary>Liest oder setzt Login.</summary>
        public ILogin Login { get; set; }

        /// <summary>Liest oder setzt LoginStateMachine.</summary>
        public ILoginState LoginStateMachine
        {
            get
            {
                return this.loginStateMachine;
            }

            set
            {
                if ((this.loginStateMachine == null && value != null)
                    || (value != null && this.loginStateMachine.LoginStatus != value.LoginStatus))
                {
                    this.loginStateMachine = value;
                    DoLoginStatusChanged();
                }
            }
        }

        /// <summary>Die TimeFinallyLoggedoutSec.</summary>
        public int TimeFinallyLoggedOutSec { get; set; }

        /// <summary>Zeit im FolderStatus LoggedInHigh.</summary>
        public int TimeLoggedInHighSec { get; set; }

        /// <summary>Zeit im FolderStatus LoggedInLow.</summary>
        public int TimeLoggedInLowSec { get; set; }

        /// <summary>Zeit im FolderStatus RefreshHigh.</summary>
        public int TimeRefreshHighSec { get; set; }

        /// <summary>Zeit im FolderStatus RefreshLow.</summary>
        public int TimeRefreshLowSec { get; set; }

        #endregion

        #region Properties

        /// <summary>Liest InternalLogin.</summary>
        internal Login InternalLogin
        {
            get
            {
                return Login as Login;
            }
        }

        /// <summary>
        /// Liefert die Mailbox.
        /// </summary>
        internal Mailbox Mailbox { get; private set; }

        /// <summary>Dieser Timer gibt an, wann der Benutzer definitiv ausgeloggt wird und sich auch nicht mehr refresshen kann.</summary>
        internal BackgroundTimer TimerFinallyLoggedOut { get; set; }

        /// <summary>
        /// Dieser Timer gibt an, wie lange der FolderStatus LoggedInHigh erhalten bleibt.
        /// </summary>
        internal BackgroundTimer TimerLoggedInHigh { get; set; }

        /// <summary>
        /// Dieser Timer gibt an, wie lange der FolderStatus LoggedInLow erhalten bleibt.
        /// </summary>
        internal BackgroundTimer TimerLoggedInLow { get; set; }

        /// <summary>
        /// Dieser Timer gibt an, wie lange der FolderStatus RefreshHigh erhalten bleibt.
        /// </summary>
        internal BackgroundTimer TimerRefreshHigh { get; set; }

        /// <summary>
        /// Dieser Timer gibt an, wie lange der FolderStatus RefreshLow erhalten bleibt.
        /// </summary>
        internal BackgroundTimer TimerRefreshLow { get; set; }

        /// <summary>Liest oder setzt ContentSource.</summary>
        protected string ContentSource { get; set; }

        #endregion

        #region Public Methods and Operators

        /// <summary>Erzeugt einen Entwurf im E-POST Postfach des Nutzers.</summary>
        /// <param name="createDraftRequest">Der CreateDraftRequest beinhaltet alle Parameter, die für das Anlegen des Entwurfs
        /// benötigt werden.</param>
        /// <param name="htmlBody">Der Body des E-POSTBRIEFS, also das Anschreiben, als HTML-Text.</param>
        /// <param name="files">Eine Liste von Dateien, die als Anhang an den Entwurf angelegt werden sollen.</param>
        /// <returns>Die Rückmeldung auf das Anlegen des Entwurfs als <see cref="CreateDraftResponse"/>.</returns>
        public CreateDraftResponse CreateDraft(
            CreateDraftRequest createDraftRequest, 
            string htmlBody, 
            List<string> files)
        {
            DoWorkStatusChanged(WorkStatus.CreateDraftBegin);
            try
            {
                if (InternalLogin.AccessToken == null)
                {
                    Error = ApiBaseRequest.CreateErrorResponse("access_token_null", "Access Token is null", null);
                    throw new EPostBusinessApiException("Access Token is null", "Draft", 999, Error);
                }

                var fileInfos = files.Select(file => new FileInfo(file)).ToList();

                var draft = new Draft
                                {
                                    SystemType = Login.SystemType, 
                                    XEpostAccessToken = InternalLogin.AccessToken.AccessToken, 
                                    Files = fileInfos, 
                                    CreateDraftRequest = createDraftRequest, 
                                    HtmlBody = htmlBody,
                                    ThirdSystemUrl = Login.ThirdSystemUrl
                                };

                Login.CreateDraftResponse = draft.CreateDraft();
                ContentSource = Login.CreateDraftResponse.Links.Self.Href;

                return Login.CreateDraftResponse;
            }
            finally
            {
                DoWorkStatusChanged(WorkStatus.CreateDraftEnd);
            }
        }

        /// <summary>Erzeugt einen Entwurf für den elektronischen Versand.</summary>
        /// <param name="ePostAddressSender">Die E-POSTBRIEF Adresse des Absenders.</param>
        /// <param name="subject">Der Betreff des E-POSTBRIEFS.</param>
        /// <param name="body">Der Text des E-POSTBRIEFS.</param>
        /// <param name="ePostAddressRecipient">Die E-POSTBRIEF Adresse des Empfängers.</param>
        /// <param name="files">Eine Liste von Dateien, die als Anhang an den Entwurf angelegt werden sollen.</param>
        public void CreateElectronicalDraft(
            string ePostAddressSender, 
            string subject, 
            string body, 
            string ePostAddressRecipient, 
            List<string> files)
        {
            var id = Guid.NewGuid().ToString();
            var draftRequest = new CreateDraftRequest
                                   {
                                       Envelope =
                                           new Envelope
                                               {
                                                   LetterId = id, 
                                                   Sender =
                                                       new Sender
                                                           {
                                                               DisplayName =
                                                                   ePostAddressSender, 
                                                               EpostAddress =
                                                                   ePostAddressSender
                                                           }, 
                                                   Recipients =
                                                       new List<Recipient>
                                                           {
                                                               new Recipient
                                                                   {
                                                                       DisplayName
                                                                           =
                                                                           ePostAddressRecipient, 
                                                                       EpostAddress
                                                                           =
                                                                           ePostAddressRecipient
                                                                   }
                                                           }, 
                                                   SentDate =
                                                       ApiBaseRequest.GetDateTimeObject(
                                                           DateTime.Now), 
                                                   LetterType =
                                                       new LetterType
                                                           {
                                                               SystemMessageType =
                                                                   SystemMessageTypeEnum
                                                                   .normal, 
                                                               SenderType =
                                                                   "private"
                                                           }, 
                                                   Subject = subject, 
                                                   Read = false, 
                                                   LetterLinks =
                                                       new LetterLinks
                                                           {
                                                               Letter =
                                                                   new Letter
                                                                       {
                                                                           Href
                                                                               =
                                                                               id
                                                                       }
                                                           }
                                               }
                                   };

            Login.CreateDraftResponse = CreateDraft(draftRequest, body, files);
        }

        /// <summary>Erzeugt einen Entwurf für den physischen Versand.
        /// Es muss entweder ein Postfach oder eine Straße angegeben werden.</summary>
        /// <param name="ePostAddressSender">Die E-POSTBRIEF-Adresse des Absenders.</param>
        /// <param name="subject">Der Betreff des E-POSTBRIEFS.</param>
        /// <param name="body">Der Text des E-POSTBRIEFS.</param>
        /// <param name="company">Der Firmenname.</param>
        /// <param name="salutation">Die Anrede.</param>
        /// <param name="title">Der Titel der Person.</param>
        /// <param name="firstName">Der Vorname.</param>
        /// <param name="lastName">Der Nachname.</param>
        /// <param name="postOfficeBox">Das Postfach.</param>
        /// <param name="streetName">Die Straße.</param>
        /// <param name="houseNumber">Die Hausnummer.</param>
        /// <param name="addressAddon">Zusatzinformation zur Adresse, z. B. Erdgeschoss.</param>
        /// <param name="zipCode">Die Postleitzahl.</param>
        /// <param name="city">Der Ort.</param>
        /// <param name="files">Eine Liste von Dateien, die als Anhang an den Entwurf angelegt werden sollen.</param>
        public void CreatePrintDraft(
            string ePostAddressSender, 
            string subject, 
            string body, 
            string company, 
            string salutation, 
            string title, 
            string firstName, 
            string lastName, 
            string postOfficeBox, 
            string streetName, 
            string houseNumber, 
            string addressAddon, 
            string zipCode, 
            string city, 
            List<string> files)
        {
            var id = Guid.NewGuid().ToString();
            var hasAttachments = files != null && files.Count > 0;
            var draftRequest = new CreateDraftRequest
                                   {
                                       Envelope =
                                           new Envelope
                                               {
                                                   LetterId = id, 
                                                   HasAttachments = hasAttachments, 
                                                   Sender =
                                                       new Sender
                                                           {
                                                               DisplayName =
                                                                   ePostAddressSender, 
                                                               EpostAddress =
                                                                   ePostAddressSender
                                                           }, 
                                                   RecipientsPrinted =
                                                       new List<RecipientsPrinted>
                                                           {
                                                               new RecipientsPrinted
                                                                   {
                                                                       Company
                                                                           =
                                                                           company, 
                                                                       Salutation
                                                                           =
                                                                           salutation, 
                                                                       Title
                                                                           =
                                                                           title, 
                                                                       FirstName
                                                                           =
                                                                           firstName, 
                                                                       LastName
                                                                           =
                                                                           lastName, 
                                                                       PostOfficeBox
                                                                           =
                                                                           postOfficeBox, 
                                                                       StreetName
                                                                           =
                                                                           streetName, 
                                                                       HouseNumber
                                                                           =
                                                                           houseNumber, 
                                                                       AddressAddOn
                                                                           =
                                                                           addressAddon, 
                                                                       ZipCode
                                                                           =
                                                                           zipCode, 
                                                                       City
                                                                           =
                                                                           city
                                                                   }
                                                           }, 
                                                   SentDate =
                                                       ApiBaseRequest.GetDateTimeObject(
                                                           DateTime.Now), 
                                                   LetterType =
                                                       new LetterType
                                                           {
                                                               SystemMessageType =
                                                                   SystemMessageTypeEnum
                                                                   .hybrid, 
                                                               SenderType =
                                                                   "private"
                                                           }, 
                                                   Subject = subject, 
                                                   Read = false, 
                                                   LetterLinks =
                                                       new LetterLinks
                                                           {
                                                               Letter =
                                                                   new Letter
                                                                       {
                                                                           Href
                                                                               =
                                                                               id
                                                                       }
                                                           }
                                               }
                                   };

            Login.CreateDraftResponse = CreateDraft(draftRequest, body, files);
        }

        /// <summary>
        /// Löscht den zuvor angelegten Entwurf. Sollte kein Entwurf angelegt worden sein
        /// oder der Entwurf bereits versendet worden sein, führt der Aufruf dieser Methode zu einem Fehler.
        /// </summary>
        public void DeleteActualDraft()
        {
            DoWorkStatusChanged(WorkStatus.DeleteDraftBegin);
            try
            {
                var deleteDraft = new DeleteDraft
                                      {
                                          SystemType = Login.SystemType, 
                                          ContentSource = Login.CreateDraftResponse.Id, 
                                          XEpostAccessToken = Login.AccessToken.AccessToken,
                                          ThirdSystemUrl = Login.ThirdSystemUrl
                                      };

                deleteDraft.DeleteIt();
            }
            finally
            {
                DoWorkStatusChanged(WorkStatus.DeleteDraftEnd);
            }
        }

        /// <summary>Löst das WorkStatusChangedEvent aus.</summary>
        /// <param name="workStatus">Der Work FolderStatus.</param>
        public void DoWorkStatusChanged(WorkStatus workStatus)
        {
            if (WorkStatusChanged == null || Login.WorkStatus == workStatus)
            {
                return;
            }

            InternalLogin.WorkStatus = workStatus;
            WorkStatusChanged(this, new WorkStatusEventArgs(Login.WorkStatus));
        }

        /// <summary>Liefert das Attachment als Byte Array.</summary>
        /// <param name="letterId">Id des Briefs.</param>
        /// <param name="attachmentId">Id des Attachments.</param>
        /// <returns>Attachment als Byte Array.</returns>
        public byte[] GetAttachment(string letterId, string attachmentId)
        {
            EnsureMailboxIsInitialized();
            return Mailbox.GetAttachment(letterId, attachmentId);
        }

        /// <summary>Liefert das Anschreiben in text oder html-Format.</summary>
        /// <param name="id">Id des Anschreibens.</param>
        /// <returns>Anschreiben in text oder html-Format.</returns>
        public string GetCoverLetter(string id)
        {
            EnsureMailboxIsInitialized();
            return Mailbox.GetCoverLetter(id);
        }

        /// <summary>
        /// Gibt den Status und Inhalt des Ordners Drafts zurück.
        /// </summary>
        /// <returns>Folder</returns>
        public Folder GetDrafts()
        {
            EnsureMailboxIsInitialized();
            return GetFolder(MainFolderTypes.drafts);
        }

        /// <summary>Gibt den Status und Inhalt des Ordners Draft zurück.</summary>
        /// <param name="offset">Der Parameter legt fest, welche Stelle der Ergebnisliste, die über limit eingeschränkt ist,
        /// zurückgegeben wird. Wenn der Parameter nicht angegeben wird, wird der Standardwert 0
        /// verwendet.</param>
        /// <param name="limit">Die Anzahl an E‑POSTBRIEFEN, die bei der Anfrage zurückgegeben werden. Wenn der
        /// Parameter nicht angegeben wird, wird der Standardwert 500 (Maximalwert) verwendet.</param>
        /// <returns>Folder</returns>
        public Folder GetDrafts(int offset, int limit)
        {
            EnsureMailboxIsInitialized();
            return GetFolder(MainFolderTypes.drafts, offset, limit);
        }

        /// <summary>
        /// Gibt den Status und Inhalt des Ordners Inbox zurück.
        /// </summary>
        /// <returns>Folder</returns>
        public Folder GetInbox()
        {
            EnsureMailboxIsInitialized();
            return GetFolder(MainFolderTypes.inbox);
        }

        /// <summary>Gibt den Status und Inhalt des Ordners Inbox zurück.</summary>
        /// <param name="offset">Der Parameter legt fest, welche Stelle der Ergebnisliste, die über limit eingeschränkt ist,
        /// zurückgegeben wird. Wenn der Parameter nicht angegeben wird, wird der Standardwert 0
        /// verwendet.</param>
        /// <param name="limit">Die Anzahl an E‑POSTBRIEFEN, die bei der Anfrage zurückgegeben werden. Wenn der
        /// Parameter nicht angegeben wird, wird der Standardwert 500 (Maximalwert) verwendet.</param>
        /// <returns>Folder</returns>
        public Folder GetInbox(int offset, int limit)
        {
            EnsureMailboxIsInitialized();
            return GetFolder(MainFolderTypes.inbox, offset, limit);
        }

        /// <summary>Liefert das JSON Objekt zum Brief.</summary>
        /// <param name="id">Id des Briefs.</param>
        /// <returns>GetLetterResponse</returns>
        public GetLetterResponse GetLetter(string id)
        {
            EnsureMailboxIsInitialized();
            return Mailbox.GetLetter(id);
        }

        /// <summary>Fragt die Preisinformationen für einen referenzierten Entwurf ab.</summary>
        /// <param name="contentSource">Die Referenz auf den Entwurf.</param>
        /// <returns>Die Rückmeldung mit den entsprechenden Preisinformationen als <see cref="PostageInfoResponse"/>.</returns>
        public PostageInfoResponse GetPostageInfo(string contentSource)
        {
            return GetPostageInfo(contentSource, null);
        }

        /// <summary>Fragt die Preisinformationen für einen referenzierten Entwurf ab.</summary>
        /// <param name="contentSource">Die Referenz auf den Entwurf.</param>
        /// <param name="printOptionsRequest">Die Parameter, die zur Abfrage des Preises benötigt werden.</param>
        /// <returns>Die Rückmeldung mit den entsprechenden Preisinformationen als <see cref="PostageInfoResponse"/>.</returns>
        public PostageInfoResponse GetPostageInfo(string contentSource, PrintOptionsRequest printOptionsRequest)
        {
            DoWorkStatusChanged(WorkStatus.PostageInfoBegin);
            try
            {
                if (InternalLogin.AccessToken == null)
                {
                    Error = ApiBaseRequest.CreateErrorResponse("access_token_null", "Access Token is null", null);
                    throw new EPostBusinessApiException("Access Token is null", "PostageInfo", 999, Error);
                }

                var postage = new Postage
                                  {
                                      SystemType = Login.SystemType, 
                                      XEpostAccessToken = InternalLogin.AccessToken.AccessToken, 
                                      PrintOptionsRequest = printOptionsRequest, 
                                      ContentSource = contentSource,
                                      ThirdSystemUrl = Login.ThirdSystemUrl
                                  };

                return postage.GetPostageInfo();
            }
            finally
            {
                DoWorkStatusChanged(WorkStatus.PostageInfoEnd);
            }
        }

        /// <summary>Fragt die Preisinformationen aufgrund der angegebenen Metadaten ab, ohne auf einen Entwurf zu referenzieren.</summary>
        /// <param name="printOptionsRequest">Die Parameter, die zur Abfrage des Preises benötigt werden.</param>
        /// <returns>Die Preisinformation als <see cref="TotalPrice"/>.</returns>
        public TotalPrice GetPostageInfo(PrintOptionsRequest printOptionsRequest)
        {
            var pir = GetPostageInfo(null, printOptionsRequest);
            return pir.TotalPrice;
        }

        /// <summary>Fragt die Preisinformationen für den aktuellen Entwurf ab.</summary>
        /// <param name="printOptionsRequest">Die Parameter, die zur Abfrage des Preises benötigt werden.</param>
        /// <returns>Die Preisinformation als <see cref="TotalPrice"/>.</returns>
        public TotalPrice GetPostageInfoForActualDraft(PrintOptionsRequest printOptionsRequest)
        {
            var pir = GetPostageInfo(ContentSource, printOptionsRequest);
            return pir.TotalPrice;
        }

        /// <summary>Fragt die Preisinformationen für den aktuellen Entwurf ab.</summary>
        /// <returns>Die Preisinformation als <see cref="TotalPrice" />.</returns>
        public TotalPrice GetPostageInfoForActualDraft()
        {
            var pir = GetPostageInfo(ContentSource);
            return pir.TotalPrice;
        }

        /// <summary>
        /// Gibt den Status und Inhalt des Ordners Sent zurück.
        /// </summary>
        /// <returns>Folder</returns>
        public Folder GetSent()
        {
            return GetFolder(MainFolderTypes.sent);
        }

        /// <summary>Gibt den Status und Inhalt des Ordners Sent zurück.</summary>
        /// <param name="offset">Der Parameter legt fest, welche Stelle der Ergebnisliste, die über limit eingeschränkt ist,
        /// zurückgegeben wird. Wenn der Parameter nicht angegeben wird, wird der Standardwert 0
        /// verwendet.</param>
        /// <param name="limit">Die Anzahl an E‑POSTBRIEFEN, die bei der Anfrage zurückgegeben werden. Wenn der
        /// Parameter nicht angegeben wird, wird der Standardwert 500 (Maximalwert) verwendet.</param>
        /// <returns>Folder</returns>
        public Folder GetSent(int offset, int limit)
        {
            return GetFolder(MainFolderTypes.sent, offset, limit);
        }

        /// <summary>
        /// Gibt den Status und Inhalt des Ordners Trash zurück.
        /// </summary>
        /// <returns>Folder</returns>
        public Folder GetTrash()
        {
            return GetFolder(MainFolderTypes.trash);
        }

        /// <summary>Gibt den Status und Inhalt des Ordners Trash zurück.</summary>
        /// <param name="offset">Der Parameter legt fest, welche Stelle der Ergebnisliste, die über limit eingeschränkt ist,
        /// zurückgegeben wird. Wenn der Parameter nicht angegeben wird, wird der Standardwert 0
        /// verwendet.</param>
        /// <param name="limit">Die Anzahl an E‑POSTBRIEFEN, die bei der Anfrage zurückgegeben werden. Wenn der
        /// Parameter nicht angegeben wird, wird der Standardwert 500 (Maximalwert) verwendet.</param>
        /// <returns>Folder</returns>
        public Folder GetTrash(int offset, int limit)
        {
            return GetFolder(MainFolderTypes.trash, offset, limit);
        }

        /// <summary>Versendet den aktuellen Entwurf.</summary>
        public void SendDraft()
        {
            SendDraft(null);
        }

        /// <summary>Versendet den aktuellen Entwurf.</summary>
        /// <param name="printOptionsRequest">Die beim Versand zu berücksichtigenden Parameter.</param>
        public void SendDraft(PrintOptionsRequest printOptionsRequest)
        {
            DoWorkStatusChanged(WorkStatus.SendDraftBegin);
            try
            {
                // FIXME #998: Login.CreateDraftResponse can be null -> NullReferenceException
                var sendDraft = new SendDraft
                                    {
                                        SystemType = Login.SystemType, 
                                        ContentSource = Login.CreateDraftResponse.Links.Self.Href, 
                                        PrintOptionsRequest = printOptionsRequest, 
                                        XEpostAccessToken = Login.AccessToken.AccessToken,
                                        ThirdSystemUrl = Login.ThirdSystemUrl
                                    };

                sendDraft.SendIt();
            }
            finally
            {
                DoWorkStatusChanged(WorkStatus.SendDraftEnd);
            }
        }

        /// <summary>Versendet einen elektronischen E-POSTBRIEF.</summary>
        /// <param name="electronic">Die Parameter zum elektronischen Versand.</param>
        /// <param name="htmlBody">Der Body als HTML.</param>
        /// <param name="files">Die Anhänge.</param>
        public void SendElectronically(ElectronicRequest electronic, string htmlBody, List<string> files)
        {
            Send(electronic, htmlBody, files);
        }

        /// <summary>Versendet einen physischen E-POSTBRIEF.</summary>
        /// <param name="print">Die Parameter zum physischen Versand.</param>
        /// <param name="htmlBody">Der Body als HTML.</param>
        /// <param name="files">Die Anhänge.</param>
        public void SendPhysically(PrintRequest print, string htmlBody, List<string> files)
        {
            Send(print, htmlBody, files);
        }

        #endregion

        #region Methods

        /// <summary>Liefert den Status und den Inhalt des angegebenen Hauptordners zurück.</summary>
        /// <param name="folderType">MainFolderTypes der Typ des Ordners</param>
        /// <returns>Folder</returns>
        internal Folder GetFolder(MainFolderTypes folderType)
        {
            EnsureMailboxIsInitialized();
            return Mailbox.GetFolder(folderType);
        }

        /// <summary>Liefert den Status und den Inhalt des angegebenen Hauptordners zurück.</summary>
        /// <param name="folderType">MainFolderTypes der Typ des Ordners</param>
        /// <param name="offset">Der Parameter legt fest, welche Stelle der Ergebnisliste, die über limit eingeschränkt ist,
        /// zurückgegeben wird. Wenn der Parameter nicht angegeben wird, wird der Standardwert 0
        /// verwendet.</param>
        /// <param name="limit">Die Anzahl an E‑POSTBRIEFEN, die bei der Anfrage zurückgegeben werden. Wenn der
        /// Parameter nicht angegeben wird, wird der Standardwert 500 (Maximalwert) verwendet.</param>
        /// <returns>Folder</returns>
        internal Folder GetFolder(MainFolderTypes folderType, int offset, int limit)
        {
            EnsureMailboxIsInitialized();
            return Mailbox.GetFolder(folderType, offset, limit);
        }

        /// <summary>Versendet einen E-POSTBRIEF driekt ohne vorher einen Entwurf anzulegen.</summary>
        /// <param name="jsonObject">Das JSON-Objekt.</param>
        /// <param name="htmlBody">Der Body als HTML.</param>
        /// <param name="files">Die Anhänge.</param>
        /// <exception cref="EPostBusinessApiException">Im Fehlerfall wird eine EPostBusinessApiException geworfen.</exception>
        internal void Send(object jsonObject, string htmlBody, List<string> files)
        {
            if (InternalLogin.AccessToken == null)
            {
                Error = ApiBaseRequest.CreateErrorResponse("access_token_null", "Access Token is null", null);
                throw new EPostBusinessApiException("Access Token is null", "Draft", 999, Error);
            }

            var fileInfos = files.Select(file => new FileInfo(file)).ToList();

            var send = new Send
                           {
                               JsonObject = jsonObject, 
                               Files = fileInfos, 
                               SystemType = Login.SystemType, 
                               XEpostAccessToken = Login.AccessToken.AccessToken, 
                               HtmlBody = htmlBody,
                               ThirdSystemUrl = Login.ThirdSystemUrl
                           };

            send.SendIt();
        }

        /// <summary>
        /// Startet den TimerFinallyLoggedOut.
        /// </summary>
        internal void StartTimerFinallyLoggedOut()
        {
            if (TimerFinallyLoggedOut == null)
            {
                TimerFinallyLoggedOut = StartTimer(
                    TimeFinallyLoggedOutSec, 
                    this.TimerFinallyLoggedOutTick, 
                    TimerFinallyLoggedOut);
            }
        }

        /// <summary>
        /// Starte den TimerRefreshHigh.
        /// </summary>
        internal void StartTimerLoggedInHigh()
        {
            TimerLoggedInHigh = StartTimer(TimeLoggedInHighSec, this.TimerLoggedInHighTick, TimerRefreshHigh);
        }

        /// <summary>
        /// Starte den TimerRefreshHigh.
        /// </summary>
        internal void StartTimerLoggedInLow()
        {
            TimerLoggedInLow = StartTimer(TimeLoggedInLowSec, this.TimerLoggedInLowTick, TimerRefreshLow);
        }

        /// <summary>
        /// Starte den TimerRefreshHigh.
        /// </summary>
        internal void StartTimerRefreshHigh()
        {
            TimerRefreshHigh = StartTimer(TimeRefreshHighSec, this.TimerRefreshHighTick, TimerLoggedInHigh);
        }

        /// <summary>
        /// Startet den TimerRefreshLow.
        /// </summary>
        internal void StartTimerRefreshLow()
        {
            TimerRefreshLow = StartTimer(TimeRefreshLowSec, this.TimerRefreshlowTick, TimerLoggedInLow);
        }

        /// <summary>
        /// Stoppt den Timer RefreshHigh.
        /// </summary>
        internal void StopTimerFinallyLoggedOut()
        {
            StopTimer(TimerFinallyLoggedOut);
            TimerFinallyLoggedOut = null;
        }

        /// <summary>
        /// Stoppt den Timer RefreshHigh.
        /// </summary>
        internal void StopTimerLoggedInHigh()
        {
            StopTimer(TimerLoggedInHigh);
            TimerLoggedInHigh = null;
        }

        /// <summary>
        /// Stoppt den Timer RefreshHigh.
        /// </summary>
        internal void StopTimerLoggedInLow()
        {
            StopTimer(TimerLoggedInLow);
            TimerLoggedInLow = null;
        }

        /// <summary>
        /// Stoppt den Timer RefreshHigh.
        /// </summary>
        internal void StopTimerRefreshHigh()
        {
            StopTimer(TimerRefreshHigh);
            TimerRefreshHigh = null;
        }

        /// <summary>
        /// Stoppt den Timer RefreshLow.
        /// </summary>
        internal void StopTimerRefreshLow()
        {
            StopTimer(TimerRefreshLow);
            TimerRefreshLow = null;
        }

        /// <summary>Der Do Login FolderStatus Changed.</summary>
        private void DoLoginStatusChanged()
        {
            if (LoginStatusChanged != null)
            {
                LoginStatusChanged(this, new LoginStatusEventArgs(LoginStateMachine.LoginStatus));
            }
        }

        /// <summary>TODO The ensure mailbox is initialized.</summary>
        /// <exception cref="EPostBusinessApiException"></exception>
        private void EnsureMailboxIsInitialized()
        {
            if (InternalLogin.AccessToken == null)
            {
                throw new EPostBusinessApiException("Access Token is null", "Draft", 999, Error);
            }

            if (Mailbox == null)
            {
                Mailbox = new Mailbox(Login.AccessToken, Login.SystemType);
            }
        }

        /// <summary>Startet einen Timer.</summary>
        /// <param name="timeInSeconds">Zeit in Minuten.</param>
        /// <param name="elapsed">Die aufzurufende Funktion.</param>
        /// <param name="oldTimer">Der alte Timer.</param>
        /// <returns>The <see cref="BackgroundTimer"/>.</returns>
        private BackgroundTimer StartTimer(int timeInSeconds, EventHandler elapsed, BackgroundTimer oldTimer)
        {
            StopTimer(oldTimer);

            var timer = new BackgroundTimer { Seconds = timeInSeconds };

            timer.Elapsed += elapsed;

            timer.Start();

            return timer;
        }

        /// <summary>Stoppt den angegebenen Timer.</summary>
        /// <param name="oldTimer">Der zu stoppende Timer.</param>
        private void StopTimer(BackgroundTimer oldTimer)
        {
            // Erst mal den alten stoppen:
            if (oldTimer != null)
            {
                oldTimer.Dispose();
            }
        }

        /// <summary>Tritt auf, wenn der TimerFinallyLoggedOut abgelaufen ist.</summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        private void TimerFinallyLoggedOutTick(object sender, EventArgs e)
        {
            LoginStateMachine = new LoggedOutState(LoginStateMachine);
        }

        /// <summary>Tritt auf, wenn der TimerLoggedInHigh abgelaufen ist.</summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        private void TimerLoggedInHighTick(object sender, EventArgs e)
        {
            LoginStateMachine = new RefreshableHighState(LoginStateMachine);
        }

        /// <summary>Tritt auf, wenn der TimerLoggedInHigh abgelaufen ist.</summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        private void TimerLoggedInLowTick(object sender, EventArgs e)
        {
            TimeRefreshLowSec = Settings.Default.TimeRefreshLowSec;
            LoginStateMachine = new RefreshableLowState(LoginStateMachine);
        }

        /// <summary>Tritt auf, wenn der TimerRefreshHigh abgelaufen ist.</summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        private void TimerRefreshHighTick(object sender, EventArgs e)
        {
            TimeRefreshLowSec = Settings.Default.TimeRefreshLowFromHighSec;
            LoginStateMachine = new RefreshableLowState(LoginStateMachine);
        }

        /// <summary>Tritt auf, wenn der TimerRefreshLow abgelaufen ist.</summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        private void TimerRefreshlowTick(object sender, EventArgs e)
        {
            LoginStateMachine = new LoggedOutState(LoginStateMachine);
        }

        #endregion
    }
}