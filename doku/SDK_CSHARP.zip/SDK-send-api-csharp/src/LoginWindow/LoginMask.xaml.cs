﻿namespace LoginWindow
{
    using System.Windows;

    using LoginControl.ViewModel;

    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class LoginMask : Window
    {
        public LoginControlViewModel ViewModel;

        public LoginMask()
        {
            InitializeComponent();
            //  We have declared the view model instance declaratively in the xaml.
            //  Get the reference to it here, so we can use it in the button click event.
            ViewModel = (LoginControlViewModel)base.DataContext;
        }

        private void loginControl1_LoginButtonClicked(object sender, RoutedEventArgs e)
        {
            if (ViewModel.SaveCredentials)
            {
                ViewModel.SaveActualCredentials();
            }

            this.Close();
        }

        private void loginControl1_Loaded(object sender, RoutedEventArgs e)
        {
            ViewModel.LoadCredentials();
        }

        private void LoginControl1_OnClearCredentialsClicked(object sender, RoutedEventArgs e)
        {
            ViewModel.ClearActualCredentials();
        }

        private void LoginControl1_OnCancelButtonClicked(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
