package de.deutschepost.api.client.java;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.LoggingFilter;

import javax.ws.rs.core.MediaType;

/**
 * This class handles the actual dispatch operation.
 * Before actually sending a letter, you must upload a draft to the mailbox service
 * (see MailboxServiceClient). After a successful upload, you have to provide the letter urn when calling
 * the send service to tell hin to dispatch that draft.
 */
public class SendServiceClient {

    // constants
    public static final String SEND_SERVICE_URL = "https://send.api.epost-gka.de"; // ITU
//    public static final String SEND_SERVICE_URL = "https://send.api.epost.de"; // LIVE
    private final static String SEND_SERVICE_DELIVERIES_RESOURCE_PATH = "/deliveries";
    private static final MediaType DISPATCH_OPTIONS_MEDIA_TYPE = new MediaType("application", "vnd.epost-dispatch-options+json");

    /**
     * Dispatch a draft, which was previously created, using the mailbox service (see MailboxServiceClient)
     * This method calls the send service.
     * @param userAccessTicket - String
     * @param contentSource - urn to draft
     * @throws Exception
     */
    public ClientResponse sendHybridDraft(String userAccessTicket, String contentSource) throws Exception {
        // TODO replace this with a real SSL-Client in production code!
        Client client = Client.create(TolerantSSLClient.configureClient());

        // add logging filter in order to sysout all requests for later analysis
        client.addFilter(new LoggingFilter());
        final WebResource service = client.resource(SEND_SERVICE_URL).path(SEND_SERVICE_DELIVERIES_RESOURCE_PATH);

        // Set headers and media type
        final WebResource.Builder builder = service
                .header("x-epost-access-token", userAccessTicket)
                .header("Content-Source", contentSource)
                .type(DISPATCH_OPTIONS_MEDIA_TYPE);

        // post request to service
        final ClientResponse response = builder.post(ClientResponse.class, getDraftSendOptions());

        if (response.getStatus() != 204) {
            throw new Exception("Could not execute call to " + service.getURI() + " HTTP " + response.getStatus() +
                    " -> " + response.getEntity(String.class));
        }

        return response;
    }

    private String getDraftSendOptions() {
        return "{" +
            "\"options\": {" +
            "   \"color\": \"colored\"," +
            "   \"coverLetter\": \"generate\"," +
            "   \"usePrs\": false" +
            "}}";
    }
}
