package de.deutschepost.api.client.java;

import com.google.gson.Gson;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.LoggingFilter;
import org.apache.commons.codec.binary.Base64;

import javax.ws.rs.core.MediaType;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;

/**
 * Use this class to authenticate.
 * For reasons of simplicity and because we do not have a web frontend in this code example,
 * the password grant flow is used to log in.
 */
public class LoginServiceClient {

    // TODO move this data to some config file or similar
    public static final String DEVELOPER_ID = "YOUR DEV_ID";

    public static final String APPLICATION_ID = "YOUR APP_ID";

    // LIF for api01 on devint08
    public static final String LIF = "ENTER YOUR LIF HERE";


    // constants
    public static final String LOGIN_SERVICE_URL = "https://login.epost-gka.de"; // ITU
//    public static final String LOGIN_SERVICE_URL = "https://login.epost.de"; // LIVE

    public static final String OAUTH2_LOGIN_PATH = "/oauth2/tokens";

    public static final String OAUTH2_LOGOUT_PATH = "/oauth2/tokens/logout";

    public static final String SCOPE_HYBRID = "send_hybrid";

    public static final String SCOPE_CREATE = "create_letter";

    /**
     * Method authenticates a user, using password grant.
     * You have to use an active EPOST account (private person OR company) in order to log in.
     *
     * This method calls the login service and returns a userAccessTicket, if authentication was successful.
     * This ticket can be used for 15 minutes before it needs to be refreshed. See documentation for details.
     * @param username - string
     * @param password - string
     * @param scope - See documentation for different scopes
     * @return userAccessTicket as a string
     * @throws Exception
     */
    public String login(String username, String password, String scope) throws Exception {
        // TODO replace this with a real SSL-Client in production code!
        Client client = Client.create(TolerantSSLClient.configureClient());

        // add logging filter in order to sysout all requests for later analysis
        client.addFilter(new LoggingFilter());
        WebResource loginServiceResource = client.resource(LOGIN_SERVICE_URL + OAUTH2_LOGIN_PATH);

        // Set header (Authorization, Content-Type) and media type
        final WebResource.Builder builder = loginServiceResource
                .header("Authorization", createAuthorisationString())
                .header("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8")
                .type(MediaType.APPLICATION_FORM_URLENCODED_TYPE);

        // Post request
        final ClientResponse response = builder.post(ClientResponse.class, getGrantTypeParameters(username, password, scope));

        // Parse access_token from response body
        if (response.getStatus() == 200) {
            final String entity = response.getEntity(String.class);

            final Gson gson = new Gson();
            final Map<String, String> map = gson.fromJson(entity, Map.class);

            return map.get("access_token");
        } else {
            throw new Exception("Could not get access_token! " + response.getEntity(String.class));
        }
    }

    /**
     * Method invalidates a user access ticket, so it cannot be used any more
     *
     * This method calls the login service.
     * @param userAccessTicket - string
     * @throws Exception
     */
    public void logout(final String userAccessTicket) throws Exception {
        // TODO replace this with a real SSL-Client in production code!
        Client client = Client.create(TolerantSSLClient.configureClient());

        // add logging filter in order to sysout all requests for later analysis
        client.addFilter(new LoggingFilter());
        WebResource loginServiceResource = client.resource(LOGIN_SERVICE_URL + OAUTH2_LOGOUT_PATH);

        // Set header (Content-Type) and media type
        final WebResource.Builder builder = loginServiceResource
                .header("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8")
                .type(MediaType.APPLICATION_FORM_URLENCODED_TYPE);

        // Post request
        final ClientResponse response = builder.post(ClientResponse.class, "access_token=" + userAccessTicket);

        if (response.getStatus() != 204) {
            throw new Exception("Could not log out! " + response.getEntity(String.class));
        }
    }

    private String createAuthorisationString() throws UnsupportedEncodingException {
        final String clientId = DEVELOPER_ID + "," + APPLICATION_ID;

        String tmp = URLEncoder.encode(clientId, "UTF8") + ':' + URLEncoder.encode(LIF, "UTF8");
        return "Basic " + Base64.encodeBase64String(tmp.getBytes());
    }

    private String getGrantTypeParameters(String username, String password, String scope)
            throws UnsupportedEncodingException {
        // Concatenate required parameter (grant_type, username, password, scope)
        StringBuilder parameters = new StringBuilder();
        parameters.append("grant_type=password");
        // You have to URL-encode your username and password in order to safely transfer special characters
        parameters.append("&username=").append(URLEncoder.encode(username, "UTF-8"));
        parameters.append("&password=").append(URLEncoder.encode(password, "UTF-8"));
        parameters.append("&scope=").append(scope);
        return parameters.toString();
    }
}
