package de.deutschepost.api.client.java;

import com.google.gson.Gson;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.LoggingFilter;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.BodyPart;
import com.sun.jersey.multipart.MultiPart;
import com.sun.jersey.multipart.MultiPartMediaTypes;
import org.apache.commons.io.IOUtils;

import javax.ws.rs.core.MediaType;

import java.io.InputStream;
import java.util.Map;

/**
 * Use this class to upload your letter to the EPOST server.
 */
public class MailboxServiceClient {

    // constants
    final static String MAILBOX_SERVICE_URL = "https://mailbox.api.epost-gka.de"; // ITU
//    final static String MAILBOX_SERVICE_URL = "https://mailbox.api.epost.de"; // LIVE

    private static final String LETTERS_PATH = "/letters";

    private static final MediaType JSON_MEDIA_TYPE = new MediaType("application", "vnd.epost-letter+json");

    private static final MediaType PDF_MEDIA_TYPE = new MediaType("application", "pdf");

    private static final String TEST_PDF_ATTACHMENT = "TestPDF-attachment.pdf";

    /**
     * Create draft letter and attachments with one request.
     *
     * Calling this function uploads the entire Letter to the EPOST server, by calling the
     * mailbox service. After a successful upload, you can dispatch your draft, using
     * the send service (see SendServiceClient.java)
     * @param userAccessTicket - String
     * @return draft urn - String
     * @throws Exception
     */
    public String uploadCompleteLetter(String userAccessTicket) throws Exception {
        // TODO replace this with a real SSL-Client in production code!
        Client client = Client.create(TolerantSSLClient.configureClient());

        // add logging filter in order to sysout all requests for later analysis
        client.addFilter(new LoggingFilter());
        final WebResource service = client.resource(MAILBOX_SERVICE_URL).path(LETTERS_PATH);

        String json = "" +
                "{\"envelope\": {\n" +
                "     \"subject\": \"from integration test\",\n" +
                "     \"recipientsPrinted\": [\n" +
                "         {\n" +
                "             \"company\": \"Epostbrief\",\n" +
                "             \"salutation\": \"Herr\",\n" +
                "             \"title\": \"Prof.\",\n" +
                "             \"firstName\": \"Team\",\n" +
                "             \"lastName\": \"Tesla\",\n" +
                "             \"streetName\": \"Ehrenbergstraße\",\n" +
                "             \"houseNumber\": \"11-14\",\n" +
                "             \"addressAddOn\": \"keine\",\n" +
//                "             \"postOfficeBox\": \"6004\",\n" + // alternative for street+houseNumber
                "             \"zipCode\": \"10245\",\n" +
                "             \"city\": \"Berlin\"\n" +
                "         }\n" +
                "     ],\n" +
                "     \"letterType\": {\n" +
                "         \"systemMessageType\": \"hybrid\",\n" +
                "         \"messageType\": \"EPB\"\n" +
                "     }\n" +
                " }\n" +
                " }";

        // Read pdf attachment to byte array
        InputStream is = this.getClass().getResourceAsStream(TEST_PDF_ATTACHMENT);
        byte[] bytes = IOUtils.toByteArray(is);


        // Create multipart with json and pdf
        MultiPart multiPart = new MultiPart();
        multiPart.bodyPart(new BodyPart(json, JSON_MEDIA_TYPE));
        final BodyPart bodyPart = new BodyPart(bytes, PDF_MEDIA_TYPE);
        // set header - Content-Disposition: form-data; filename="TestPDF-attachment.jpeg"; name="file"
        bodyPart.setContentDisposition(FormDataContentDisposition.name("file").fileName(TEST_PDF_ATTACHMENT).build());

        multiPart.bodyPart(bodyPart);

        // Set header and media type
        WebResource.Builder builder = service
                .header("x-epost-access-token", userAccessTicket)
                .type(MultiPartMediaTypes.MULTIPART_MIXED);

        ClientResponse response = builder.post(ClientResponse.class, multiPart);

        if (response.getStatus() != 201) {
            throw new Exception("Could not upload a complete draft. " + response.getEntity(String.class));
        }

        return getCreatedDraftUrl(response);
    }

    /**
     * Parse response body (json) and return link to uploaded letter
     * @param response
     * @return
     */
    private String getCreatedDraftUrl(ClientResponse response) {
        final Gson gson = new Gson();
        final Map map = gson.fromJson(response.getEntity(String.class), Map.class);
        return (String) ((Map) ((Map) map.get("_links")).get("self")).get("href");
    }
}
