package de.deutschepost.api.client.java;

import org.junit.Before;
import org.junit.Test;

public class SampleIntegrationTest {

    // for partner
    protected static final String USERNAME = "your user's epb-address";// e.g. "john.doe@yourcompany.epost.de"
    protected static final String PASSWORD = "your user's password";

    private LoginServiceClient loginServiceClient;
    private SendServiceClient sendServiceClient;
    private MailboxServiceClient mailboxClient;

    @Before
    public void setup() {
        loginServiceClient = new LoginServiceClient();
        sendServiceClient = new SendServiceClient();
        mailboxClient = new MailboxServiceClient();
    }

    @Test
    public void sendHybridDraft() throws Exception {
        final String userAccessTicket = loginAndGetUserAccessTicket();

        String createdDraftUrl = mailboxClient.uploadCompleteLetter(userAccessTicket);
        sendServiceClient.sendHybridDraft(userAccessTicket, createdDraftUrl);
        loginServiceClient.logout(userAccessTicket);
    }

    private String loginAndGetUserAccessTicket() throws Exception {
        return loginServiceClient.login(USERNAME, PASSWORD,
                LoginServiceClient.SCOPE_HYBRID + " " + LoginServiceClient.SCOPE_CREATE);
    }
}
